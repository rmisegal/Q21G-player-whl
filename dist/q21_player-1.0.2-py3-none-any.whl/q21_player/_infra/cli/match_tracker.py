"""Match Tracker for creating and managing Q21 match entries."""

from typing import Any

from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository
from q21_player._infra.repository.orm_models import GameSessionModel
from q21_player._infra.shared.logging.logger import get_logger


class MatchTracker:
    """Tracks match creation and state for Q21 games."""

    def __init__(
        self,
        session_repo: GameRepository | None = None,
        state_repo: GameStateRepository | None = None,
    ):
        self._logger = get_logger("match_tracker")
        self._session_repo = session_repo or GameRepository()
        self._state_repo = state_repo or GameStateRepository()

    def create_from_warmup_call(self, payload: dict[str, Any], player_email: str) -> dict[str, Any]:
        """Create match entries from Q21_WARMUP_CALL payload.

        Args:
            payload: Warmup call payload with match_id, referee_email, etc.
            player_email: Player's email address

        Returns:
            dict with match_id, phase, and optionally season_id
        """
        match_id = payload.get("match_id", "")
        season_id = payload.get("season_id")
        round_number = payload.get("round_number")

        # Check for duplicate (idempotent)
        existing = self._session_repo.get_by_game_id(match_id)
        if existing:
            state = self._state_repo.get_by_match_id(match_id)
            self._logger.info(f"Match {match_id} already exists, returning existing state")
            return {
                "match_id": match_id,
                "phase": state.current_phase if state else "UNKNOWN",
                "season_id": season_id,
                "is_duplicate": True,
            }

        # Create game session
        self._session_repo.create_session(
            game_id=match_id,
            player_email=player_email,
            book_name="TBD",  # Will be updated in ROUND_START
            season_id=season_id,
            round_number=round_number,
        )

        # Create game state
        state = self._state_repo.create_state(match_id)

        self._logger.info(f"Created match {match_id} with phase {state.current_phase}")
        return {
            "match_id": match_id,
            "phase": state.current_phase,
            "season_id": season_id,
            "is_duplicate": False,
        }
