"""
Domain services for GmailAsPlayer.

Business logic and orchestration:
- State machine for player lifecycle
- Message parsing and routing
- Response building
"""

from q21_player._infra.domain.services.connectivity_handler import ConnectivityHandler
from q21_player._infra.domain.services.game_service import GameService, GameSession
from q21_player._infra.domain.services.message_parser import MessageParser
from q21_player._infra.domain.services.message_router import MessageRouter, create_default_router
from q21_player._infra.domain.services.message_service import MessageService
from q21_player._infra.domain.services.player_service import PlayerService
from q21_player._infra.domain.services.registration_service import (
    RegistrationResult,
    RegistrationService,
)
from q21_player._infra.domain.services.response_builder import ResponseBuilder
from q21_player._infra.domain.services.state_handlers import StateHandler, get_handler
from q21_player._infra.domain.services.state_machine import PlayerStateMachine
from q21_player._infra.domain.services.state_transitions import (
    VALID_TRANSITIONS,
    StateTransition,
    TransitionEvent,
)
from q21_player._infra.domain.services.strategy_service import StrategyService
from q21_player._infra.domain.services.timeout_manager import TimeoutManager

__all__ = [
    "PlayerStateMachine",
    "StateTransition",
    "TransitionEvent",
    "VALID_TRANSITIONS",
    "StateHandler",
    "get_handler",
    "TimeoutManager",
    "MessageParser",
    "MessageRouter",
    "create_default_router",
    "ResponseBuilder",
    "ConnectivityHandler",
    "MessageService",
    "StrategyService",
    "PlayerService",
    "RegistrationService",
    "RegistrationResult",
    "GameService",
    "GameSession",
]
