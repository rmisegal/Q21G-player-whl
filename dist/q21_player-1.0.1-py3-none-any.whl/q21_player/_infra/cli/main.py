"""Main entry point for GmailAsPlayer."""
import argparse
import signal
import sys

from q21_player._infra.cli.orchestrator import PlayerOrchestrator
from q21_player._infra.shared.config.constants import (
    CONFIG_DIR,
    CONFIG_FILE,
    DEFAULT_POLL_INTERVAL_SEC,
)
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.logging.logger import get_logger, setup_logging


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(prog="q21-player",
        description="Autonomous player agent for 21-Questions game league")
    parser.add_argument("--config", "-c", type=str, default=f"{CONFIG_DIR}/{CONFIG_FILE}",
        help="Path to configuration file")
    parser.add_argument("--email", "-e", type=str, help="Player email address (overrides config)")
    parser.add_argument("--name", "-n", type=str, help="Player name (overrides config)")
    parser.add_argument("--strategy", "-s", type=str, choices=["llm", "keyword", "random"],
        default="llm", help="Strategy to use for questions/guesses")
    parser.add_argument("--poll-interval", "-p", type=int, default=DEFAULT_POLL_INTERVAL_SEC,
        help="Email polling interval in seconds")
    parser.add_argument("--debug", "-d", action="store_true", help="Enable debug logging")
    parser.add_argument("--dry-run", action="store_true", help="Run without sending emails")
    parser.add_argument("--scan", action="store_true",
        help="Run single scan: process messages once and exit")
    parser.add_argument("--watch", action="store_true",
        help="Run continuous scan: process messages in a loop")
    parser.add_argument("--test-connectivity", action="store_true",
        help="Test Gmail and database connectivity, then exit")
    return parser.parse_args()


def test_connectivity() -> int:
    """Test Gmail and database connectivity."""
    logger = get_logger("connectivity")
    results = {"gmail": False, "database": False}
    print("Testing Gmail connectivity...")
    try:
        from q21_player._infra.gmail.client import GmailClient
        client = GmailClient()
        client.authenticate()
        if profile := client.get_profile():
            print(f"  Gmail: OK - Connected as {profile.get('emailAddress', 'unknown')}")
            results["gmail"] = True
        else:
            print("  Gmail: FAIL - Could not get profile")
    except Exception as e:
        print(f"  Gmail: FAIL - {e}")
        logger.exception("Gmail connectivity test failed")
    print("Testing database connectivity...")
    try:
        from q21_player._infra.database.pool import ConnectionPool
        pool = ConnectionPool()
        if pool.test_connection():
            print("  Database: OK - Connection successful")
            results["database"] = True
        else:
            print("  Database: FAIL - Connection test failed")
    except Exception as e:
        print(f"  Database: FAIL - {e}")
        logger.exception("Database connectivity test failed")
    print("\n--- Summary ---")
    all_ok = all(results.values())
    for name, ok in results.items():
        print(f"  {name}: {'PASS' if ok else 'FAIL'}")
    return 0 if all_ok else 1


def main() -> int:
    """Main entry point."""
    args = parse_args()
    setup_logging(debug=args.debug)
    logger = get_logger("main")
    if args.test_connectivity:
        return test_connectivity()
    config = Config()
    player_email = args.email or config.gmail.account
    player_name = args.name or config.get("player.display_name", "GmailPlayer")
    if not player_email:
        logger.error("Player email is required. Use --email or set in config.")
        return 1

    # Scan mode: process messages once and exit
    if args.scan:
        from q21_player._infra.cli.scan_handler import run_scan
        logger.info(f"Running scan for: {player_name} <{player_email}>")
        result = run_scan(player_email, player_name, dry_run=args.dry_run)
        return 0 if result.status in ("COMPLETED", "COMPLETED_WITH_ERRORS") else 1

    # Watch mode: continuous scanning at intervals
    if args.watch:
        from q21_player._infra.cli.scan_handler import run_scan
        from q21_player._infra.heartbeat.writer import HeartbeatWriter
        import time
        watch_writer = HeartbeatWriter(heartbeat_dir="heartbeats", process_key="gmail_as_player")
        logger.info(f"Starting watch mode for: {player_name} <{player_email}>")
        logger.info(f"Poll interval: {args.poll_interval}s (Ctrl+C to stop)")
        try:
            while True:
                result = run_scan(player_email, player_name, dry_run=args.dry_run)
                status = "error" if result.errors else "running"
                watch_writer.beat(status=status)
                logger.info(f"Next scan in {args.poll_interval}s...")
                time.sleep(args.poll_interval)
        except KeyboardInterrupt:
            watch_writer.stop()
            logger.info("Watch mode stopped")
            return 0

    logger.info(f"Starting q21-player: {player_name} <{player_email}>")
    orchestrator = PlayerOrchestrator(player_email=player_email, player_name=player_name,
        strategy_type=args.strategy, poll_interval=args.poll_interval, dry_run=args.dry_run)

    def signal_handler(sig, frame):
        logger.info("Shutdown signal received")
        orchestrator.stop()

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    try:
        orchestrator.start()
        return 0
    except KeyboardInterrupt:
        logger.info("Keyboard interrupt")
        orchestrator.stop()
        return 0
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
