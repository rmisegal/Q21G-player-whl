"""
Envelope builder for outgoing messages.

Builds protocol-compliant message envelopes for Q21 responses.
"""

import uuid
from datetime import datetime, timezone


class EnvelopeBuilder:
    """Builds message envelopes for Q21 protocol responses."""

    def __init__(self, player_id: str, player_email: str):
        """
        Initialize the envelope builder.

        Args:
            player_id: The player's logical identifier
            player_email: The player's email address
        """
        self.player_id = player_id
        self.player_email = player_email

    def _generate_message_id(self) -> str:
        """Generate a unique message ID."""
        return str(uuid.uuid4())

    def _build_envelope(
        self,
        message_type: str,
        payload: dict,
        correlation_id: str,
        recipient_id: str,
        game_id: str,
    ) -> dict:
        """Build a protocol-compliant flat envelope structure."""
        return {
            "protocol": "Q21G.v1",
            "message_type": message_type,
            "message_id": self._generate_message_id(),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "sender": {
                "email": self.player_email,
                "role": "PLAYER",
                "logical_id": self.player_id,
            },
            "recipient_id": recipient_id,
            "correlation_id": correlation_id,
            "game_id": game_id,
            "payload": payload,
        }

    def build_warmup_response(
        self,
        answer: str,
        correlation_id: str,
        recipient_id: str,
        game_id: str,
        match_id: str,
        auth_token: str,
    ) -> dict:
        """Build a Q21WARMUPRESPONSE envelope."""
        return self._build_envelope(
            message_type="Q21WARMUPRESPONSE",
            payload={
                "match_id": match_id,
                "answer": answer,
                "auth_token": auth_token,
            },
            correlation_id=correlation_id,
            recipient_id=recipient_id,
            game_id=game_id,
        )

    def build_questions_batch(
        self,
        questions: list,
        correlation_id: str,
        recipient_id: str,
        game_id: str,
        match_id: str,
        auth_token: str,
    ) -> dict:
        """Build a Q21QUESTIONSBATCH envelope."""
        return self._build_envelope(
            message_type="Q21QUESTIONSBATCH",
            payload={
                "match_id": match_id,
                "questions": questions,
                "total_questions": len(questions),
                "auth_token": auth_token,
            },
            correlation_id=correlation_id,
            recipient_id=recipient_id,
            game_id=game_id,
        )

    def build_guess_submission(
        self,
        opening_sentence: str,
        sentence_justification: str,
        associative_word: str,
        word_justification: str,
        confidence: float,
        correlation_id: str,
        recipient_id: str,
        game_id: str,
        match_id: str,
        auth_token: str,
    ) -> dict:
        """Build a Q21GUESSSUBMISSION envelope."""
        return self._build_envelope(
            message_type="Q21GUESSSUBMISSION",
            payload={
                "match_id": match_id,
                "opening_sentence": opening_sentence,
                "sentence_justification": sentence_justification,
                "associative_word": associative_word,
                "word_justification": word_justification,
                "confidence": confidence,
                "auth_token": auth_token,
            },
            correlation_id=correlation_id,
            recipient_id=recipient_id,
            game_id=game_id,
        )
