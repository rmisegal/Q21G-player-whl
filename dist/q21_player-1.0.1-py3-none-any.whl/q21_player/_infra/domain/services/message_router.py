"""Message router for GmailAsPlayer - routes messages by type."""
from __future__ import annotations
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.domain.models.messages import IncomingMessage
from q21_player._infra.shared.config.constants import MessageType
from q21_player._infra.shared.exceptions.protocol import UnknownMessageTypeError
from q21_player._infra.shared.logging.logger import get_logger

if TYPE_CHECKING:
    from q21_player._infra.shared.config.protocol_registry import ProtocolRegistry

MessageHandler = Callable[[IncomingMessage, GameContext | None], dict[str, Any]]


class MessageRouter:
    def __init__(self, registry: ProtocolRegistry | None = None):
        self._logger = get_logger("message_router")
        self._handlers: dict[MessageType, MessageHandler] = {}
        self._raw_handlers: dict[str, MessageHandler] = {}
        self._default_handler: MessageHandler | None = None
        self._registry = registry

    def register_handler(self, message_type: MessageType, handler: MessageHandler) -> None:
        self._handlers[message_type] = handler

    def register_raw_handler(self, raw_type: str, handler: MessageHandler) -> None:
        self._raw_handlers[raw_type] = handler

    def set_default_handler(self, handler: MessageHandler) -> None:
        self._default_handler = handler

    def route(self, message: IncomingMessage, context: GameContext | None = None) -> dict[str, Any]:
        raw_type = getattr(message.envelope, "raw_message_type", None)
        if raw_type and raw_type in self._raw_handlers:
            self._logger.info(f"Routing raw type {raw_type} to handler")
            return self._raw_handlers[raw_type](message, context)
        msg_type = message.message_type
        if isinstance(msg_type, str):
            try:
                msg_type = MessageType(msg_type)
            except ValueError:
                if self._default_handler:
                    return self._default_handler(message, context)
                raise UnknownMessageTypeError(msg_type) from None
        if handler := self._handlers.get(msg_type):
            self._logger.info(f"Routing {msg_type.value} to handler")
            return handler(message, context)
        if self._default_handler:
            self._logger.warning(f"No handler for {msg_type}, using default")
            return self._default_handler(message, context)
        raise UnknownMessageTypeError(str(msg_type))

    def has_handler(self, message_type: MessageType) -> bool:
        return message_type in self._handlers

    def get_registered_types(self) -> list[MessageType]:
        return list(self._handlers.keys())


def create_default_router(registry: ProtocolRegistry | None = None) -> MessageRouter:
    from q21_player._infra.domain.services.router_handlers import (
        handle_registration_response, handle_game_invitation, handle_round_start, handle_warmup_call,
        handle_questions_call, handle_answers_batch, handle_game_result,
        handle_hints, handle_score_feedback, handle_connectivity_test, handle_standings_response,
        handle_league_error, handle_game_error, handle_round_announcement, handle_broadcast,
        handle_assignment_table, handle_unknown,
    )
    router = MessageRouter(registry=registry)
    router.register_handler(MessageType.LEAGUE_REGISTER_RESPONSE, handle_registration_response)
    handlers = [(MessageType.GAME_INVITATION, handle_game_invitation), (MessageType.Q21_ROUND_START, handle_round_start),
        (MessageType.Q21_WARMUP_CALL, handle_warmup_call), (MessageType.Q21_QUESTIONS_CALL, handle_questions_call),
        (MessageType.Q21_ANSWERS_BATCH, handle_answers_batch),
        (MessageType.GAME_OVER, handle_game_result), (MessageType.Q21_GUESS_RESULT, handle_game_result),
        (MessageType.Q21_HINTS, handle_hints), (MessageType.Q21_SCORE_FEEDBACK, handle_score_feedback),
        (MessageType.CONNECTIVITY_TEST_CALL, handle_connectivity_test), (MessageType.CONNECTIVITYTESTCALL, handle_connectivity_test),
        (MessageType.QUERY_STANDINGS_RESPONSE, handle_standings_response), (MessageType.ROUND_ANNOUNCEMENT, handle_round_announcement),
        (MessageType.LEAGUE_ERROR, handle_league_error), (MessageType.GAME_ERROR, handle_game_error)]
    for mt, h in handlers:
        router.register_handler(mt, h)
    bcasts = [MessageType.BROADCAST_KEEP_ALIVE, MessageType.BROADCAST_FREE_TEXT, MessageType.BROADCAST_CRITICAL_RESET,
        MessageType.BROADCAST_CRITICAL_PAUSE, MessageType.BROADCAST_CRITICAL_CONTINUE, MessageType.BROADCAST_NEW_LEAGUE_ROUND,
        MessageType.BROADCAST_END_LEAGUE_ROUND, MessageType.BROADCAST_END_GROUP_ASSIGNMENT, MessageType.BROADCAST_START_SEASON,
        MessageType.BROADCAST_END_SEASON, MessageType.BROADCAST_ROUND_RESULTS]
    for b in bcasts:
        router.register_handler(b, handle_broadcast)
    router.register_handler(MessageType.BROADCAST_ASSIGNMENT_TABLE, handle_assignment_table)
    # Q21G raw message types
    q21g = [("Q21WARMUPCALL", handle_warmup_call), ("Q21ROUNDSTART", handle_round_start),
        ("Q21QUESTIONSCALL", handle_questions_call), ("Q21ANSWERSBATCH", handle_answers_batch),
        ("Q21HINTS", handle_hints), ("Q21SCOREFEEDBACK", handle_score_feedback)]
    for raw, h in q21g:
        router.register_raw_handler(raw, h)
    router.set_default_handler(handle_unknown)
    return router
