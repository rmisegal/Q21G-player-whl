"""Factory for creating protocol envelopes."""

from q21_player._infra.domain.models.envelope import Envelope
from q21_player._infra.domain.models.message_context import MessageContext
from q21_player._infra.shared.config.constants import PROTOCOL_VERSION, MessageType, UserRole
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.utils.helpers import generate_transaction_id


class EnvelopeFactory:
    """Factory for creating Envelope instances with consistent defaults."""

    def __init__(self, config: Config | None = None):
        """Initialize factory with config.

        Args:
            config: Config instance. If None, creates new Config().
        """
        self._config = config or Config()

    def create(
        self,
        msg_type: MessageType,
        recipient: str | None = None,
        txn_id: str | None = None,
        reply_to: str | None = None,
        context: MessageContext | None = None,
    ) -> Envelope:
        """Create an envelope with the given parameters.

        Args:
            msg_type: Message type for the envelope
            recipient: Recipient email. Defaults to league manager.
            txn_id: Transaction ID. Generated if not provided.
            reply_to: Transaction ID this message replies to.
            context: Optional message context with league/round/game IDs.

        Returns:
            Configured Envelope instance.
        """
        return Envelope(
            protocol_version=PROTOCOL_VERSION,
            sender_role=UserRole.PLAYER,
            sender_email=self._config.gmail.account,
            recipient_email=recipient or self._config.get("league.manager_email"),
            transaction_id=txn_id or generate_transaction_id("tx"),
            message_type=msg_type,
            reply_to_txid=reply_to,
            context=context,
        )
