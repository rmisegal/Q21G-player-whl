"""
Database integration module for GmailAsPlayer.

Provides:
- ConnectionPool: PostgreSQL connection pooling
- DatabaseManager: Schema initialization and management
"""

from q21_player._infra.database.manager import DatabaseManager
from q21_player._infra.database.pool import ConnectionPool

__all__ = [
    "ConnectionPool",
    "DatabaseManager",
]
