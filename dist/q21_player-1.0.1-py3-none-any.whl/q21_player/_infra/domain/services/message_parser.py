"""Message parser for GmailAsPlayer - parses JSON from emails."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from q21_player._infra.domain.models.answer import AnswerBatch
from q21_player._infra.domain.models.envelope import Envelope
from q21_player._infra.domain.models.messages import IncomingMessage
from q21_player._infra.shared.config.constants import MessageType
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.exceptions.protocol import (
    InvalidEnvelopeError,
    MessageParseError,
)
from q21_player._infra.shared.logging.logger import get_logger

if TYPE_CHECKING:
    from q21_player._infra.shared.config.protocol_registry import ProtocolRegistry


class MessageParser:
    """Parses incoming Gmail messages into domain objects."""

    def __init__(self, registry: ProtocolRegistry | None = None):
        self._logger = get_logger("message_parser")
        self._config = Config()
        self._registry = registry

    def parse_gmail_message(self, gmail_msg: dict[str, Any], payload: dict[str, Any]) -> IncomingMessage:
        """Parse a Gmail API message into IncomingMessage."""
        gmail_id = gmail_msg.get("id", "")
        thread_id = gmail_msg.get("threadId", "")

        # Extract subject from headers
        headers = gmail_msg.get("payload", {}).get("headers", [])
        subject = self._get_header(headers, "Subject")

        if not subject:
            raise MessageParseError("Missing subject line")

        # Parse envelope from subject - use registry if available for multi-protocol support
        recipient = self._config.gmail.account
        envelope = None
        if self._registry:
            envelope = Envelope.from_subject_line_with_registry(subject, recipient, self._registry)
        if envelope is None:
            # Fall back to legacy parsing for backward compat
            envelope = Envelope.from_subject_line(subject, recipient)

        if envelope is None:
            raise InvalidEnvelopeError(f"Invalid subject format: {subject}")

        return IncomingMessage(
            gmail_id=gmail_id,
            thread_id=thread_id,
            envelope=envelope,
            payload=payload,
            raw_subject=subject,
        )

    def _get_header(self, headers: list, name: str) -> str:
        """Extract header value by name."""
        for h in headers:
            if h.get("name", "").lower() == name.lower():
                return h.get("value", "")
        return ""

    def parse_game_invitation(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Parse GAME_INVITATION payload (supports both match_id and game_id)."""
        # Per UNIFIED_PROTOCOL.md, payload uses match_id, but support legacy game_id too
        match_id = payload.get("match_id") or payload.get("game_id")
        if not match_id:
            raise MessageParseError("Missing match_id/game_id in invitation")
        required = ["book_name", "general_description", "associative_domain"]
        # Also try book_description for UNIFIED_PROTOCOL.md Q21_ROUND_START
        book_desc = payload.get("general_description") or payload.get("book_description")
        missing = [f for f in required if f not in payload and f != "general_description"]
        if not book_desc:
            missing.append("book_description/general_description")
        if missing:
            raise MessageParseError(f"Missing fields in invitation: {missing}")

        return {
            "match_id": match_id,
            "game_id": match_id,  # Alias for backwards compatibility
            "book_name": payload["book_name"],
            "general_description": book_desc,
            "book_description": book_desc,  # Alias
            "associative_domain": payload["associative_domain"],
            "referee_email": payload.get("referee_email", ""),
            "transaction_id": payload.get("transaction_id", ""),
        }

    def parse_answers_batch(self, payload: dict[str, Any], game_id: str) -> AnswerBatch:
        """Parse Q21_ANSWERS_BATCH payload."""
        if "answers" not in payload:
            raise MessageParseError("Missing 'answers' in payload")
        return AnswerBatch.from_protocol_payload(payload, game_id)

    def parse_game_result(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Parse GAME_OVER or Q21_GUESS_RESULT payload."""
        return {
            "total_score": payload.get("total_score", 0),
            "scores": payload.get("scores", {}),
            "feedback": payload.get("feedback", ""),
            "correct_opening": payload.get("correct_opening"),
            "correct_word": payload.get("correct_word"),
        }

    def parse_registration_response(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Parse LEAGUE_REGISTER_RESPONSE payload."""
        return {
            "success": payload.get("success", False),
            "player_id": payload.get("player_id"),
            "message": payload.get("message", ""),
        }

    def parse_connectivity_test(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Parse CONNECTIVITY_TEST_CALL payload."""
        return {
            "ping_id": payload.get("ping_id", ""),
            "timestamp": payload.get("timestamp", ""),
        }

    def validate_message_type(self, message: IncomingMessage) -> bool:
        """Check if message type is recognized (enum or registry-based)."""
        msg_type = message.envelope.message_type
        # Check if it's a valid enum type
        try:
            MessageType(msg_type)
            return True
        except ValueError:
            pass
        # Check if it's a valid type in the protocol registry
        if self._registry and message.envelope.raw_message_type:
            protocol_id = message.envelope.protocol_version
            config = self._registry.get_protocol_config(protocol_id)
            if config:
                return message.envelope.raw_message_type in config.get_all_message_types()
        return False
