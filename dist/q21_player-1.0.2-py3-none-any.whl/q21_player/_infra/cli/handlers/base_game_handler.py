"""Base handler for Q21 game phase processing."""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Any

from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository
from q21_player._infra.shared.logging.logger import get_logger


class BaseGameHandler(ABC):
    """Base class for Q21 game phase handlers."""

    def __init__(
        self,
        state_repo: GameStateRepository | None = None,
        game_repo: GameRepository | None = None,
    ):
        """Initialize handler with repositories.

        Args:
            state_repo: Game state repository (creates new if None)
            game_repo: Game repository (creates new if None)
        """
        self._logger = get_logger(self.__class__.__name__.lower())
        self._state_repo = state_repo or GameStateRepository()
        self._game_repo = game_repo or GameRepository()

    @abstractmethod
    def process(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Process a game phase message. Implement in subclasses."""
        pass

    def _parse_deadline(self, deadline_str: str | None) -> datetime | None:
        """Parse deadline string handling Z suffix.

        Args:
            deadline_str: ISO format datetime string or None

        Returns:
            Parsed datetime or None if input is empty/None
        """
        if not deadline_str:
            return None
        return datetime.fromisoformat(deadline_str.replace("Z", "+00:00"))

    def _get_game_context(self, match_id: str) -> GameContext:
        """Get game context from state repository.

        Args:
            match_id: Match identifier

        Returns:
            GameContext with book info from state (empty if not found)
        """
        state = self._state_repo.get_by_match_id(match_id)
        return GameContext(
            game_id=match_id,
            match_id=match_id,
            book_name=(state.book_name if state else None) or "",
            general_description=(state.book_description if state else None) or "",
            associative_domain=(state.associative_domain if state else None) or "",
        )
