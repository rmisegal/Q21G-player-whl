"""Strategy factory for selecting appropriate strategy based on config."""

import importlib

from q21_player.api.callbacks import PlayerAI
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.logging.logger import get_logger
from q21_player._infra.strategy.base_strategy import IGameStrategy
from q21_player._infra.strategy.sdk_strategy import SDKStrategy

logger = get_logger("strategy_factory")

# Module-level storage for programmatically-set PlayerAI
_registered_player_ai: PlayerAI | None = None


def set_player_ai(ai: PlayerAI) -> None:
    """Register a PlayerAI instance for use by get_strategy().

    This allows programmatic injection of PlayerAI without config.
    """
    global _registered_player_ai
    _registered_player_ai = ai
    logger.info(f"Registered PlayerAI: {ai.__class__.__name__}")


def get_strategy() -> IGameStrategy:
    """Get the appropriate strategy based on configuration.

    Priority: 1) Registered AI, 2) demo_mode, 3) config-loaded AI.
    """
    global _registered_player_ai
    config = Config()

    # First check for programmatically registered AI
    if _registered_player_ai is not None:
        logger.info(f"Using registered PlayerAI: {_registered_player_ai.__class__.__name__}")
        return SDKStrategy(_registered_player_ai)

    if config.get("app.demo_mode", False):
        from q21_player.api.demo_player_ai import DemoPlayerAI
        logger.info("Using DemoPlayerAI (demo_mode=true)")
        return SDKStrategy(DemoPlayerAI())

    player_ai = _load_student_player_ai(config)
    if player_ai is None:
        raise RuntimeError(
            "No PlayerAI implementation found.\n\n"
            "To fix this, either:\n"
            "1. Set \"app.demo_mode\": true in config.json to use the demo AI\n"
            "2. Create a class that extends PlayerAI and configure it:\n"
            "   - Set \"app.player_ai_module\": \"your_module\"\n"
            "   - Set \"app.player_ai_class\": \"YourPlayerAI\""
        )

    logger.info(f"Using student PlayerAI: {player_ai.__class__.__name__}")
    return SDKStrategy(player_ai)


def _load_student_player_ai(config: Config) -> PlayerAI | None:
    """Load student's PlayerAI from config-specified module and class."""
    module_name = config.get("app.player_ai_module")
    class_name = config.get("app.player_ai_class")

    if not module_name or not class_name:
        return None

    try:
        module = importlib.import_module(module_name)
        player_ai_class = getattr(module, class_name)
        return player_ai_class()
    except (ImportError, AttributeError) as e:
        logger.error(f"Failed to load PlayerAI from {module_name}.{class_name}: {e}")
        raise RuntimeError(
            f"Failed to load PlayerAI: {e}\n\n"
            f"Make sure the module '{module_name}' exists and contains class '{class_name}'."
        ) from e
