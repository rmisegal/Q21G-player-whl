"""Connectivity handler for testing Gmail and SDK connections."""

from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.gmail.scanner import GmailScanner
from q21_player._infra.gmail.sender import GmailSender
from q21_player._infra.shared.config.constants import SINGLE_SCAN_RESULTS
from q21_player._infra.shared.logging.logger import get_logger


class ConnectivityHandler:
    """Handler for testing connectivity to services."""

    def __init__(self):
        self._logger = get_logger("connectivity_handler")
        self._gmail_client: GmailClient | None = None

    def test_gmail(self) -> dict:
        """Test Gmail API connectivity."""
        result = {"service": "gmail", "success": False, "details": {}}
        try:
            self._gmail_client = GmailClient()
            if self._gmail_client.authenticate():
                result["success"] = True
                result["details"]["auth"] = "authenticated"
                scanner = GmailScanner(self._gmail_client)
                messages = scanner.scan(max_results=SINGLE_SCAN_RESULTS)
                result["details"]["scan"] = f"found {len(messages)} messages"
                _sender = GmailSender(self._gmail_client)  # noqa: F841
                result["details"]["sender"] = "initialized"
            else:
                result["details"]["error"] = "authentication failed"
        except Exception as e:
            result["details"]["error"] = str(e)
            self._logger.error(f"Gmail connectivity test failed: {e}")
        return result

    def test_llm(self, provider: str | None = None) -> dict:
        """Test SDK LLM connectivity."""
        result = {"service": "llm", "success": False, "details": {}}
        try:
            from q21_player.api.llm import LLMClient
            # Test with specified provider or mock (always available)
            test_provider = provider or "mock"
            client = LLMClient(provider=test_provider)
            result["details"]["provider"] = test_provider
            result["details"]["model"] = client.model
            # Mock is always available; real providers need API keys
            if test_provider == "mock":
                result["success"] = True
                result["details"]["status"] = "mock provider ready"
            else:
                # Try a simple test call
                response = client.send("test")
                result["success"] = response.success
                result["details"]["status"] = "connected" if response.success else "failed"
        except Exception as e:
            result["details"]["error"] = str(e)
            self._logger.error(f"LLM connectivity test failed: {e}")
        return result

    def test_all(self, provider: str | None = None) -> dict:
        """Run all connectivity tests."""
        results = {
            "gmail": self.test_gmail(),
            "llm": self.test_llm(provider),
        }
        results["all_passed"] = all(r["success"] for r in results.values())
        return results

    def get_gmail_profile(self) -> dict:
        """Get Gmail user profile information."""
        result = {"success": False, "profile": {}}
        try:
            if not self._gmail_client:
                self._gmail_client = GmailClient()
                if not self._gmail_client.authenticate():
                    result["error"] = "authentication failed"
                    return result
            profile = self._gmail_client.service.users().getProfile(
                userId="me"
            ).execute()
            result["profile"] = {
                "email": profile.get("emailAddress", ""),
                "messages_total": profile.get("messagesTotal", 0),
                "threads_total": profile.get("threadsTotal", 0),
            }
            result["success"] = True
        except Exception as e:
            result["error"] = str(e)
            self._logger.error(f"Failed to get profile: {e}")
        return result

    def list_providers(self) -> dict:
        """List available LLM providers from SDK."""
        result = {"success": False, "providers": []}
        try:
            from q21_player.api.llm.client import DEFAULT_MODELS
            for provider, model in DEFAULT_MODELS.items():
                result["providers"].append({
                    "provider": provider,
                    "model": model,
                    "available": provider == "mock",  # Mock always available
                })
            result["success"] = True
        except Exception as e:
            result["error"] = str(e)
            self._logger.error(f"Failed to list providers: {e}")
        return result
