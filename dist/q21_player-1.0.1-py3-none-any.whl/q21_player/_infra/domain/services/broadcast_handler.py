"""Broadcast handler for GmailAsPlayer - handles League Manager broadcasts."""
from typing import Any

from q21_player._infra.domain.models.broadcast import BroadcastMessage
from q21_player._infra.domain.models.messages import IncomingMessage
from q21_player._infra.repository.assignment_repository import AssignmentRepository
from q21_player._infra.repository.broadcast_repository import BroadcastRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository
from q21_player._infra.repository.pause_state_repository import PauseStateRepository
from q21_player._infra.repository.standings_repository import StandingsRepository
from q21_player._infra.shared.config.constants import MessageType, PlayerState
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.logging.logger import get_logger

BROADCAST_TYPES = {MessageType.BROADCAST_KEEP_ALIVE, MessageType.BROADCAST_FREE_TEXT, MessageType.BROADCAST_CRITICAL_RESET,
    MessageType.BROADCAST_CRITICAL_PAUSE, MessageType.BROADCAST_CRITICAL_CONTINUE, MessageType.BROADCAST_NEW_LEAGUE_ROUND,
    MessageType.BROADCAST_END_LEAGUE_ROUND, MessageType.BROADCAST_END_GROUP_ASSIGNMENT, MessageType.BROADCAST_START_SEASON,
    MessageType.BROADCAST_END_SEASON, MessageType.BROADCAST_ROUND_RESULTS, MessageType.BROADCAST_START_SEASON_REGISTRATION,
    MessageType.BROADCAST_ASSIGNMENT_TABLE}


class BroadcastHandler:
    def __init__(self, broadcast_repo: BroadcastRepository | None = None, pause_repo: PauseStateRepository | None = None,
                 assignment_repo: AssignmentRepository | None = None, game_state_repo: GameStateRepository | None = None,
                 standings_repo: StandingsRepository | None = None):
        self._logger = get_logger("broadcast_handler")
        self._config = Config()
        self._broadcast_repo = broadcast_repo or BroadcastRepository()
        self._pause_repo = pause_repo or PauseStateRepository()
        self._assignment_repo = assignment_repo or AssignmentRepository()
        self._game_state_repo = game_state_repo or GameStateRepository()
        self._standings_repo = standings_repo or StandingsRepository()

    def is_broadcast(self, message_type: MessageType) -> bool:
        return message_type in BROADCAST_TYPES

    def handle(self, message: IncomingMessage, current_state: PlayerState, current_match_id: str | None = None) -> dict[str, Any]:
        broadcast = BroadcastMessage.from_payload(message.payload, message.message_type)
        if self._broadcast_repo.broadcast_exists(broadcast.broadcast_id):
            self._logger.warning(f"Duplicate broadcast ignored: {broadcast.broadcast_id}")
            return {"action": "ignore", "reason": "duplicate"}
        if self._config.get("broadcast.log_all_broadcasts", True):
            self._broadcast_repo.save_broadcast(broadcast_id=broadcast.broadcast_id, message_type=broadcast.message_type.value,
                league_id=broadcast.league_id, round_id=broadcast.round_id, payload=broadcast.payload,
                message_text=broadcast.message_text, response_required=broadcast.response_required)
        handler_map = {MessageType.BROADCAST_KEEP_ALIVE: self._handle_keep_alive, MessageType.BROADCAST_FREE_TEXT: self._handle_free_text,
            MessageType.BROADCAST_CRITICAL_RESET: self._handle_reset, MessageType.BROADCAST_CRITICAL_PAUSE: self._handle_pause,
            MessageType.BROADCAST_CRITICAL_CONTINUE: self._handle_continue, MessageType.BROADCAST_END_GROUP_ASSIGNMENT: self._handle_end_assignment,
            MessageType.BROADCAST_START_SEASON: self._handle_start_season, MessageType.BROADCAST_END_LEAGUE_ROUND: self._handle_end_round,
            MessageType.BROADCAST_END_SEASON: self._handle_end_season, MessageType.BROADCAST_START_SEASON_REGISTRATION: self._handle_registration_open,
            MessageType.BROADCAST_ASSIGNMENT_TABLE: self._handle_assignment_table, MessageType.BROADCAST_ROUND_RESULTS: self._handle_round_results,
            MessageType.BROADCAST_NEW_LEAGUE_ROUND: self._handle_new_league_round}
        handler = handler_map.get(message.message_type)
        return handler(broadcast, current_state, current_match_id) if handler else self._handle_lifecycle(broadcast)

    def _handle_keep_alive(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.info(f"Keep-alive received: {broadcast.broadcast_id}")
        state_val = state.value if hasattr(state, 'value') else state
        return {"action": "respond", "broadcast_id": broadcast.broadcast_id, "response_type": MessageType.RESPONSE_KEEP_ALIVE,
            "machine_state": state_val, "match_id": match_id}

    def _handle_free_text(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.info(f"Free text received: {broadcast.message_text}")
        return {"action": "respond", "broadcast_id": broadcast.broadcast_id, "response_type": MessageType.RESPONSE_FREE_TEXT}

    def _handle_reset(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.warning(f"Critical RESET received: {broadcast.broadcast_id}")
        return {"action": "reset", "broadcast_id": broadcast.broadcast_id, "response_type": MessageType.RESPONSE_CRITICAL_RESET, "reset_scope": broadcast.payload.get("reset_scope", "FULL")}

    def _handle_pause(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.warning(f"Critical PAUSE received: {broadcast.broadcast_id}")
        state_val = state.value if hasattr(state, 'value') else state
        self._pause_repo.save_pause(broadcast_id=broadcast.broadcast_id, previous_state=state_val,
            previous_match_id=match_id, saved_context={"paused_from": state_val})
        return {"action": "pause", "broadcast_id": broadcast.broadcast_id, "response_type": MessageType.RESPONSE_CRITICAL_PAUSE,
            "previous_state": state_val, "match_id": match_id}

    def _handle_continue(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.info(f"Critical CONTINUE received: {broadcast.broadcast_id}")
        active_pause = self._pause_repo.get_active_pause()
        restored_state = active_pause.previous_state if active_pause else "REGISTERED"
        restored_match = active_pause.previous_match_id if active_pause else None
        if active_pause:
            self._pause_repo.mark_resumed(active_pause.broadcast_id, broadcast.broadcast_id)
        return {"action": "continue", "broadcast_id": broadcast.broadcast_id, "response_type": MessageType.RESPONSE_CRITICAL_CONTINUE,
            "restored_state": restored_state, "restored_match_id": restored_match}

    def _handle_end_assignment(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.info(f"End assignment check: {broadcast.round_id}")
        return {"action": "check_assignment", "broadcast_id": broadcast.broadcast_id, "round_id": broadcast.round_id, "round_number": broadcast.payload.get("round_number")}

    def _handle_start_season(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.info(f"Season start: {broadcast.payload.get('season_name', 'unknown')}")
        return {"action": "season_start", "broadcast_id": broadcast.broadcast_id, "season_id": broadcast.payload.get("season_id"), "season_name": broadcast.payload.get("season_name"), "response_type": MessageType.RESPONSE_START_SEASON}

    def _handle_end_round(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.info(f"Round ended: {broadcast.payload.get('round_number', 'unknown')}")
        return {"action": "end_round", "broadcast_id": broadcast.broadcast_id, "round_id": broadcast.round_id, "round_number": broadcast.payload.get("round_number")}

    def _handle_round_results(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        """Handle BROADCAST_ROUND_RESULTS - store standings."""
        season_id, round_number = broadcast.payload.get("season_id", ""), broadcast.payload.get("round_number", 0)
        standings = broadcast.payload.get("standings", [])
        if standings:
            self._standings_repo.save_standings(season_id, round_number, standings)
            self._logger.info(f"Stored {len(standings)} standings for {season_id} round {round_number}")
        return {"action": "results_stored", "broadcast_id": broadcast.broadcast_id, "season_id": season_id,
            "round_number": round_number, "standings_count": len(standings)}

    def _handle_new_league_round(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        """Handle BROADCAST_NEW_LEAGUE_ROUND - check assignments and enter AWAITING_WARMUP if assigned."""
        round_starting = broadcast.payload.get("round_starting", 0)
        season_id = broadcast.payload.get("season_id") or broadcast.league_id
        self._logger.info(f"New league round: round={round_starting}, season={season_id}")

        # Look up assignments for this round
        assignments = self._assignment_repo.get_by_round(season_id, round_starting) if season_id else []
        my_games = [a for a in assignments if a.role in ("PLAYER_A", "PLAYER_B", "QUESTIONER")]

        if not my_games:
            self._logger.info(f"Not assigned for round {round_starting}, staying idle")
            return {"action": "idle", "broadcast_id": broadcast.broadcast_id, "round_starting": round_starting, "assigned": False}

        # Create game_state entries for each assignment with AWAITING_WARMUP phase
        game_ids = []
        for assignment in my_games:
            game_id = assignment.match_id or assignment.game_id or f"{season_id}_R{round_starting}_G{assignment.game_number}"
            self._game_state_repo.create_state(game_id)  # Idempotent - returns existing if found
            self._game_state_repo.update_phase(game_id, "AWAITING_WARMUP")
            game_ids.append(game_id)
            self._logger.info(f"Entered AWAITING_WARMUP for game {game_id}")

        return {"action": "awaiting_warmup", "broadcast_id": broadcast.broadcast_id, "round_starting": round_starting,
            "assigned": True, "game_count": len(my_games), "game_ids": game_ids}

    def _handle_end_season(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.info(f"Season ended: {broadcast.payload.get('season_name', 'unknown')}")
        return {"action": "end_season", "broadcast_id": broadcast.broadcast_id, "season_id": broadcast.payload.get("season_id"), "season_name": broadcast.payload.get("season_name")}

    def _handle_registration_open(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.info(f"Registration open: {broadcast.payload.get('season_name', 'unknown')}")
        return {"action": "registration_open", "broadcast_id": broadcast.broadcast_id, "season_id": broadcast.payload.get("season_id"), "league_id": broadcast.payload.get("league_id"), "season_name": broadcast.payload.get("season_name"), "registration_end": broadcast.payload.get("registration_end")}

    def _handle_assignment_table(self, broadcast: BroadcastMessage, state: PlayerState, match_id: str | None) -> dict[str, Any]:
        self._logger.info(f"Assignment table: season={broadcast.payload.get('season_id')} round={broadcast.payload.get('round_number')}")
        return {"action": "process_assignments", "broadcast_id": broadcast.broadcast_id, "season_id": broadcast.payload.get("season_id"), "round_number": broadcast.payload.get("round_number"), "assignments": broadcast.payload.get("assignments", []), "response_type": MessageType.RESPONSE_GROUP_ASSIGNMENT}

    def _handle_lifecycle(self, broadcast: BroadcastMessage) -> dict[str, Any]:
        self._logger.info(f"Lifecycle broadcast: {broadcast.message_type.value}")
        return {"action": "log_only", "broadcast_id": broadcast.broadcast_id}
