"""
Polling watchdog for GmailAsPlayer.

Monitors polling operations with heartbeat mechanism.
"""

import threading
import time
from collections.abc import Callable
from datetime import datetime

from q21_player._infra.shared.config.constants import (
    THREAD_JOIN_TIMEOUT_SEC,
    WATCHDOG_CHECK_INTERVAL_SEC,
    WATCHDOG_TIMEOUT_SEC,
)
from q21_player._infra.shared.logging.logger import get_logger


class PollingWatchdog:
    """
    Watchdog for monitoring polling operations.

    Detects stalled polling and triggers recovery actions.
    """

    def __init__(
        self,
        timeout_seconds: float = WATCHDOG_TIMEOUT_SEC,
        on_timeout: Callable[[], None] | None = None,
    ) -> None:
        """
        Initialize watchdog.

        Args:
            timeout_seconds: Maximum time between heartbeats
            on_timeout: Callback function when timeout occurs
        """
        self._timeout = timeout_seconds
        self._on_timeout = on_timeout
        self._last_heartbeat: float | None = None
        self._running = False
        self._thread: threading.Thread | None = None
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._logger = get_logger("watchdog")

    def start(self) -> None:
        """Start the watchdog monitor."""
        if self._running:
            return

        self._running = True
        self._stop_event.clear()
        self._last_heartbeat = time.monotonic()
        self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self._thread.start()
        self._logger.info("Watchdog started")

    def stop(self) -> None:
        """Stop the watchdog monitor."""
        self._running = False
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=float(THREAD_JOIN_TIMEOUT_SEC))
            self._thread = None
        self._logger.info("Watchdog stopped")

    def heartbeat(self) -> None:
        """Signal that the monitored operation is still alive."""
        with self._lock:
            self._last_heartbeat = time.monotonic()

    def _monitor_loop(self) -> None:
        """Background monitoring loop."""
        while not self._stop_event.wait(timeout=float(WATCHDOG_CHECK_INTERVAL_SEC)):
            with self._lock:
                if self._last_heartbeat is None:
                    continue

                elapsed = time.monotonic() - self._last_heartbeat

            if elapsed > self._timeout:
                self._logger.warning(
                    f"Watchdog timeout: no heartbeat for {elapsed:.1f}s"
                )
                if self._on_timeout:
                    try:
                        self._on_timeout()
                    except Exception as e:
                        self._logger.error(f"Timeout callback failed: {e}")
                # Reset heartbeat after timeout to avoid repeated triggers
                with self._lock:
                    self._last_heartbeat = time.monotonic()

    @property
    def is_running(self) -> bool:
        """Check if watchdog is running."""
        return self._running

    @property
    def last_heartbeat_time(self) -> datetime | None:
        """Get last heartbeat timestamp."""
        with self._lock:
            if self._last_heartbeat is None:
                return None
            # Convert monotonic time to datetime (approximate)
            elapsed = time.monotonic() - self._last_heartbeat
            return datetime.now().replace(
                microsecond=0
            ) - __import__("datetime").timedelta(seconds=elapsed)

    @property
    def seconds_since_heartbeat(self) -> float | None:
        """Get seconds since last heartbeat."""
        with self._lock:
            if self._last_heartbeat is None:
                return None
            return time.monotonic() - self._last_heartbeat
