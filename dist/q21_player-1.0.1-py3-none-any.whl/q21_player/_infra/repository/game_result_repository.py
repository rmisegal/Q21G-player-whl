"""Game Result repository for storing Q21 match scores and feedback."""

from decimal import Decimal
from typing import Any

from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import GameResultModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class GameResultRepository(BaseRepository[GameResultModel]):
    """Repository for game result operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(GameResultModel, pool)

    def save_result(
        self,
        match_id: str,
        total_score: Decimal,
        breakdown: dict[str, Any] | None = None,
        feedback: dict[str, str] | None = None,
        actuals: dict[str, str] | None = None,
        season_id: str | None = None,
    ) -> GameResultModel:
        """Save or update game result with scores, feedback, and actual answers."""
        session = self._get_session()
        breakdown = breakdown or {}
        feedback = feedback or {}
        actuals = actuals or {}
        try:
            # Check for existing result (idempotent upsert)
            existing = session.query(GameResultModel).filter_by(match_id=match_id).first()
            if existing:
                self._logger.info(f"Updating existing result for match {match_id}")
                existing.total_score = total_score
                if season_id:
                    existing.season_id = season_id
                if breakdown.get("opening_sentence_score") is not None:
                    existing.opening_sentence_score = breakdown["opening_sentence_score"]
                if breakdown.get("sentence_justification_score") is not None:
                    existing.sentence_justification_score = breakdown["sentence_justification_score"]
                if breakdown.get("associative_word_score") is not None:
                    existing.associative_word_score = breakdown["associative_word_score"]
                if breakdown.get("word_justification_score") is not None:
                    existing.word_justification_score = breakdown["word_justification_score"]
                if feedback.get("opening_sentence_feedback"):
                    existing.opening_sentence_feedback = feedback["opening_sentence_feedback"]
                if feedback.get("word_feedback"):
                    existing.word_feedback = feedback["word_feedback"]
                if actuals.get("actual_opening_sentence"):
                    existing.actual_opening_sentence = actuals["actual_opening_sentence"]
                if actuals.get("actual_associative_word"):
                    existing.actual_associative_word = actuals["actual_associative_word"]
                session.commit()
                session.refresh(existing)
                return existing
            model = GameResultModel(
                match_id=match_id,
                season_id=season_id,
                total_score=total_score,
                opening_sentence_score=breakdown.get("opening_sentence_score"),
                sentence_justification_score=breakdown.get("sentence_justification_score"),
                associative_word_score=breakdown.get("associative_word_score"),
                word_justification_score=breakdown.get("word_justification_score"),
                opening_sentence_feedback=feedback.get("opening_sentence_feedback"),
                word_feedback=feedback.get("word_feedback"),
                actual_opening_sentence=actuals.get("actual_opening_sentence"),
                actual_associative_word=actuals.get("actual_associative_word"),
            )
            session.add(model)
            session.commit()
            session.refresh(model)
            return model
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Save result failed: {e}")
            raise RepositoryError(f"Failed to save result: {e}") from e

    def get_by_match_id(self, match_id: str) -> GameResultModel | None:
        """Get game result by match ID."""
        session = self._get_session()
        try:
            return session.query(GameResultModel).filter_by(match_id=match_id).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by match_id failed: {e}")
            raise RepositoryError(f"Failed to get result: {e}") from e

    def get_by_season(self, season_id: str) -> list[GameResultModel]:
        """Get all results for a season."""
        session = self._get_session()
        try:
            return session.query(GameResultModel).filter_by(season_id=season_id).order_by(
                GameResultModel.received_at
            ).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by season failed: {e}")
            raise RepositoryError(f"Failed to get results: {e}") from e
