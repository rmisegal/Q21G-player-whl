"""
Standard logger implementation for GmailAsPlayer.

Provides centralized logging with JSON configuration support.
"""

import json
import logging
import logging.config
import os
from pathlib import Path
from typing import Optional

from q21_player._infra.shared.config.constants import CONFIG_DIR, LOGGING_CONFIG_FILE
from q21_player._infra.shared.logging.sensitive_filter import SensitiveFilter


class StandardLogger:
    """
    Centralized logger with JSON configuration support.

    Supports multiple handlers: console, file_general, file_error.
    """

    _instance: Optional["StandardLogger"] = None
    _initialized: bool = False

    def __new__(cls) -> "StandardLogger":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if StandardLogger._initialized:
            return
        StandardLogger._initialized = True
        self._setup_logging()

    def _get_project_root(self) -> Path:
        """Find project root by looking for pyproject.toml."""
        current = Path(__file__).resolve()
        for parent in current.parents:
            if (parent / "pyproject.toml").exists():
                return parent
        return Path.cwd()

    def _setup_logging(self) -> None:
        """Configure logging from JSON config file."""
        project_root = self._get_project_root()
        config_path = project_root / CONFIG_DIR / LOGGING_CONFIG_FILE

        # Ensure logs directory exists
        logs_dir = project_root / "logs"
        logs_dir.mkdir(exist_ok=True)
        (logs_dir / "game_history").mkdir(exist_ok=True)
        (logs_dir / "debug").mkdir(exist_ok=True)

        if config_path.exists():
            with open(config_path, encoding="utf-8") as f:
                config = json.load(f)

            # Update file paths to absolute paths
            for handler in config.get("handlers", {}).values():
                if "filename" in handler:
                    handler["filename"] = str(logs_dir / handler["filename"])

            logging.config.dictConfig(config)
        else:
            self._setup_default_logging(logs_dir)

        # Add sensitive filter to all handlers
        sensitive_filter = SensitiveFilter()
        for handler in logging.root.handlers:
            handler.addFilter(sensitive_filter)

    def _setup_default_logging(self, logs_dir: Path) -> None:
        """Setup default logging if no config file exists."""
        log_level = os.getenv("LOG_LEVEL", "INFO")

        logging.basicConfig(
            level=getattr(logging, log_level),
            format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
            handlers=[
                logging.StreamHandler(),
                logging.FileHandler(logs_dir / "app.log", encoding="utf-8"),
            ],
        )

    def get_logger(self, name: str) -> logging.Logger:
        """Get a named logger instance."""
        return logging.getLogger(name)


def get_logger(name: str) -> logging.Logger:
    """
    Convenience function to get a logger instance.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Configured logger instance
    """
    StandardLogger()  # Ensure logging is configured
    return logging.getLogger(name)


def setup_logging(debug: bool = False) -> None:
    """
    Setup logging configuration.

    Args:
        debug: If True, set log level to DEBUG
    """
    StandardLogger()  # Ensure logging is configured
    if debug:
        logging.getLogger().setLevel(logging.DEBUG)
        for handler in logging.getLogger().handlers:
            handler.setLevel(logging.DEBUG)
