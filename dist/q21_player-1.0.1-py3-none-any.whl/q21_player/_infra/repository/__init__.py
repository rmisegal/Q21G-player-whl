"""
Repository layer for data persistence.

Provides:
- ORM models for database entities
- Repository interfaces and implementations
- Transaction management
"""

from q21_player._infra.repository.attachment_repository import AttachmentRepository
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.factory import (
    RepositoryFactory,
    TransactionContext,
    get_repository_factory,
)
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.message_log_repository import MessageLogRepository
from q21_player._infra.repository.orm_models import (
    AnswerModel,
    AttachmentModel,
    Base,
    GameSessionModel,
    GuessModel,
    MessageLogModel,
    PlayerStateModel,
    QuestionModel,
)
from q21_player._infra.repository.state_repository import StateRepository

__all__ = [
    "Base",
    "PlayerStateModel",
    "GameSessionModel",
    "QuestionModel",
    "AnswerModel",
    "GuessModel",
    "AttachmentModel",
    "MessageLogModel",
    "BaseRepository",
    "GameRepository",
    "StateRepository",
    "AttachmentRepository",
    "MessageLogRepository",
    "RepositoryFactory",
    "TransactionContext",
    "get_repository_factory",
]
