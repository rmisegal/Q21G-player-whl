"""State repository for player state persistence."""
from datetime import UTC, datetime

from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.domain.models.player_state import PlayerStateDTO
from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import (
    PlayerStateModel,
    StateTransitionModel,
)
from q21_player._infra.shared.config.constants import PlayerState
from q21_player._infra.shared.exceptions.repository import RepositoryError


class StateRepository(BaseRepository[PlayerStateModel]):
    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(PlayerStateModel, pool)

    def get_by_email(self, player_email: str) -> PlayerStateModel | None:
        try:
            return self._get_session().query(PlayerStateModel).filter_by(player_email=player_email).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by email failed: {e}")
            raise RepositoryError(f"Failed to get player state: {e}") from e

    def save_state(self, state: PlayerStateDTO) -> PlayerStateModel:
        current_state_val = state.current_state.value if hasattr(state.current_state, 'value') else state.current_state
        now = datetime.now(UTC)
        if existing := self.get_by_email(state.player_email):
            existing.player_name, existing.current_state = state.player_name, current_state_val
            existing.current_game_id, existing.current_book = state.current_game_id, state.current_book
            existing.current_description, existing.current_domain = state.current_description, state.current_domain
            existing.last_activity, existing.updated_at = state.last_activity or now, now
            return self.update(existing)
        return self.create(PlayerStateModel(player_email=state.player_email, player_name=state.player_name,
            current_state=current_state_val, current_game_id=state.current_game_id, current_book=state.current_book,
            current_description=state.current_description, current_domain=state.current_domain,
            last_activity=state.last_activity or now))

    def load_state(self, player_email: str) -> PlayerStateDTO | None:
        if not (model := self.get_by_email(player_email)):
            return None
        return PlayerStateDTO(player_email=model.player_email, player_name=model.player_name,
            current_state=PlayerState(model.current_state), current_game_id=model.current_game_id,
            current_book=model.current_book, current_description=model.current_description,
            current_domain=model.current_domain, last_activity=model.last_activity)

    def update_state_only(self, player_email: str, new_state: PlayerState) -> bool:
        if not (model := self.get_by_email(player_email)):
            return False
        model.current_state, model.last_activity, model.updated_at = new_state.value, datetime.now(UTC), datetime.now(UTC)
        self.update(model)
        return True

    def update_game_context(self, player_email: str, game_id: str, book: str, description: str, domain: str) -> bool:
        if not (model := self.get_by_email(player_email)):
            return False
        model.current_game_id, model.current_book = game_id, book
        model.current_description, model.current_domain, model.updated_at = description, domain, datetime.now(UTC)
        self.update(model)
        return True

    def clear_game_context(self, player_email: str) -> bool:
        if not (model := self.get_by_email(player_email)):
            return False
        model.current_game_id = model.current_book = model.current_description = model.current_domain = None
        model.current_state, model.updated_at = PlayerState.INIT_START_STATE.value, datetime.now(UTC)
        self.update(model)
        return True

    def delete_by_email(self, player_email: str) -> bool:
        return self.delete(model) if (model := self.get_by_email(player_email)) else False

    def save_transition(self, player_email: str, from_state: str, to_state: str, event: str, metadata: dict = None) -> StateTransitionModel:
        session = self._get_session()
        try:
            model = StateTransitionModel(player_email=player_email, from_state=from_state, to_state=to_state, event=event, transition_metadata=metadata)
            session.add(model)
            session.commit()
            return model
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Save transition failed: {e}")
            raise RepositoryError(f"Failed to save transition: {e}") from e

    def get_transition_history(self, player_email: str, limit: int = 100) -> list[StateTransitionModel]:
        try:
            return self._get_session().query(StateTransitionModel).filter_by(player_email=player_email).order_by(StateTransitionModel.created_at.desc()).limit(limit).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get transition history failed: {e}")
            raise RepositoryError(f"Failed to get transition history: {e}") from e

    def save_registration(self, player_email: str, registration_id: str, registered_at: datetime) -> bool:
        if not (model := self.get_by_email(player_email)):
            return False
        model.registration_id, model.registered_at, model.updated_at = registration_id, registered_at, datetime.now(UTC)
        self.update(model)
        return True

    def update_season_context(
        self, player_email: str, league_id: str | None, season_id: str | None, round_id: str | None = None
    ) -> bool:
        """Update player state with season/league/round context."""
        if not (model := self.get_by_email(player_email)):
            return False
        model.current_league_id, model.current_season_id, model.current_round_id = league_id, season_id, round_id
        model.updated_at = datetime.now(UTC)
        self.update(model)
        return True

    def clear_registration(self, player_email: str) -> bool:
        if not (model := self.get_by_email(player_email)):
            return False
        model.registration_id = model.registered_at = None
        model.updated_at = datetime.now(UTC)
        self.update(model)
        return True

    def get_registration(self, player_email: str) -> tuple[str | None, datetime | None]:
        model = self.get_by_email(player_email)
        return (model.registration_id, model.registered_at) if model else (None, None)
