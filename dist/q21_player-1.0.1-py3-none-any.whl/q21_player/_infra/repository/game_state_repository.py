"""Game State repository for tracking Q21 match phases and data."""
from datetime import datetime
from sqlalchemy.exc import SQLAlchemyError
from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import GameStateModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class GameStateRepository(BaseRepository[GameStateModel]):
    """Repository for game state operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(GameStateModel, pool)

    def _update(self, match_id: str, updates: dict, op: str) -> bool:
        """Generic update helper."""
        session = self._get_session()
        try:
            result = session.query(GameStateModel).filter_by(match_id=match_id).update(updates)
            session.commit()
            return result > 0
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"{op} failed: {e}")
            raise RepositoryError(f"Failed to {op}: {e}") from e

    def create_state(self, match_id: str) -> GameStateModel:
        """Create or get existing game state entry for a match (idempotent)."""
        session = self._get_session()
        try:
            existing = session.query(GameStateModel).filter_by(match_id=match_id).first()
            if existing:
                self._logger.info(f"Game state already exists for match {match_id}")
                return existing
            model = GameStateModel(match_id=match_id, current_phase="AWAITING_WARMUP")
            session.add(model)
            session.commit()
            session.refresh(model)
            return model
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Create state failed: {e}")
            raise RepositoryError(f"Failed to create game state: {e}") from e

    def get_by_match_id(self, match_id: str) -> GameStateModel | None:
        """Get game state by match ID."""
        session = self._get_session()
        try:
            return session.query(GameStateModel).filter_by(match_id=match_id).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by match_id failed: {e}")
            raise RepositoryError(f"Failed to get game state: {e}") from e

    def update_phase(self, match_id: str, phase: str) -> bool:
        """Update the current phase for a match."""
        return self._update(match_id, {"current_phase": phase}, "update phase")

    def store_book_info(self, match_id: str, book_name: str, description: str, domain: str) -> bool:
        """Store book information for a match."""
        return self._update(match_id, {
            "book_name": book_name, "book_description": description, "associative_domain": domain
        }, "store book info")

    def store_warmup(self, match_id: str, question: str, answer: str) -> bool:
        """Store warmup question and answer."""
        return self._update(match_id, {"warmup_question": question, "warmup_answer": answer}, "store warmup")

    def set_questions_deadline(self, match_id: str, deadline: datetime) -> bool:
        """Set the questions response deadline."""
        return self._update(match_id, {"questions_deadline": deadline}, "set questions deadline")

    def set_guess_deadline(self, match_id: str, deadline: datetime) -> bool:
        """Set the guess response deadline."""
        return self._update(match_id, {"guess_deadline": deadline}, "set guess deadline")

    def store_hints(self, match_id: str, description: str, association_topic: str) -> bool:
        """Store hints (description and association topic) for a match."""
        return self._update(match_id, {
            "book_description": description, "associative_domain": association_topic
        }, "store hints")

    def set_warmup_deadline(self, match_id: str, deadline: datetime) -> bool:
        """Set the warmup response deadline."""
        return self._update(match_id, {"warmup_deadline": deadline}, "set warmup deadline")

    def set_warmup_retry_count(self, match_id: str, count: int) -> bool:
        """Set the warmup retry count for a match."""
        return self._update(match_id, {"warmup_retry_count": count}, "set warmup retry count")

    def get_warmup_retry_count(self, match_id: str) -> int:
        """Get the warmup retry count for a match."""
        session = self._get_session()
        try:
            state = session.query(GameStateModel).filter_by(match_id=match_id).first()
            return state.warmup_retry_count if state else 0
        except SQLAlchemyError as e:
            self._logger.error(f"Get warmup retry count failed: {e}")
            raise RepositoryError(f"Failed to get warmup retry count: {e}") from e

    def store_player_role(self, match_id: str, role: str) -> bool:
        """Store the player role (QUESTIONER/ANSWERER) for a match."""
        return self._update(match_id, {"player_role": role}, "store player role")

    def store_questions_required(self, match_id: str, count: int) -> bool:
        """Store the number of questions required for a match."""
        return self._update(match_id, {"questions_required": count}, "store questions required")

    def store_time_limit(self, match_id: str, seconds: int) -> bool:
        """Store the time limit in seconds for a match."""
        return self._update(match_id, {"time_limit_seconds": seconds}, "store time limit")
