"""
Guess model for Q21 game.

Represents the final guess submission.
"""

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field, field_validator

from q21_player._infra.shared.config.constants import (
    MAX_OPENING_JUSTIFICATION_WORDS,
    MAX_WORD_JUSTIFICATION_WORDS,
    MIN_OPENING_JUSTIFICATION_WORDS,
    MIN_WORD_JUSTIFICATION_WORDS,
)


class Guess(BaseModel):
    """Final guess submission for Q21 game."""

    game_id: str = Field(..., description="Associated game ID")
    opening_sentence: str = Field(..., min_length=10, description="Guessed opening sentence")
    sentence_justification: str = Field(
        ...,
        description=f"Justification ({MIN_OPENING_JUSTIFICATION_WORDS}-{MAX_OPENING_JUSTIFICATION_WORDS} words)"
    )
    associative_word: str = Field(..., min_length=1, description="Guessed associative word")
    word_variations: list[str] = Field(
        default_factory=list,
        description="Alternative forms (singular/plural, synonyms)"
    )
    word_justification: str = Field(
        ...,
        description=f"Word justification ({MIN_WORD_JUSTIFICATION_WORDS}-{MAX_WORD_JUSTIFICATION_WORDS} words)"
    )
    confidence: float = Field(default=0.5, ge=0.0, le=1.0, description="Confidence level")
    strategy_used: str = Field(default="unknown", description="Strategy that generated guess")
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @field_validator("sentence_justification")
    @classmethod
    def validate_sentence_justification(cls, v: str) -> str:
        """Validate sentence justification word count (min only, max is soft limit with penalty)."""
        word_count = len(v.split())
        if word_count < MIN_OPENING_JUSTIFICATION_WORDS:
            raise ValueError(
                f"Sentence justification too short: {word_count} words "
                f"(min: {MIN_OPENING_JUSTIFICATION_WORDS})"
            )
        return v

    @field_validator("word_justification")
    @classmethod
    def validate_word_justification(cls, v: str) -> str:
        """Validate word justification word count (min only, max is soft limit with penalty)."""
        word_count = len(v.split())
        if word_count < MIN_WORD_JUSTIFICATION_WORDS:
            raise ValueError(
                f"Word justification too short: {word_count} words "
                f"(min: {MIN_WORD_JUSTIFICATION_WORDS})"
            )
        return v

    def to_protocol_payload(self) -> dict[str, Any]:
        """Convert to protocol payload format per UNIFIED_PROTOCOL.md (flat fields)."""
        return {
            "match_id": self.game_id,
            "opening_sentence": self.opening_sentence,
            "sentence_justification": self.sentence_justification,
            "associative_word": self.associative_word,
            "word_justification": self.word_justification,
            "confidence": self.confidence,
        }

    @property
    def sentence_word_count(self) -> int:
        return len(self.sentence_justification.split())

    @property
    def word_justification_count(self) -> int:
        return len(self.word_justification.split())

    @property
    def sentence_over_limit(self) -> bool:
        """Check if sentence justification exceeds recommended max."""
        return self.sentence_word_count > MAX_OPENING_JUSTIFICATION_WORDS

    @property
    def word_over_limit(self) -> bool:
        """Check if word justification exceeds recommended max."""
        return self.word_justification_count > MAX_WORD_JUSTIFICATION_WORDS

    @property
    def length_penalty(self) -> float:
        """Calculate 5% penalty for each justification over limit."""
        penalty = 0.0
        if self.sentence_over_limit:
            penalty += 0.05
        if self.word_over_limit:
            penalty += 0.05
        return penalty


class GuessResult(BaseModel):
    """Result of a guess evaluation."""

    game_id: str
    total_score: float = Field(..., ge=0.0, le=100.0)
    opening_score: float = Field(..., ge=0.0, le=50.0, description="50% weight")
    sentence_justification_score: float = Field(..., ge=0.0, le=20.0, description="20% weight")
    word_score: float = Field(..., ge=0.0, le=20.0, description="20% weight")
    word_justification_score: float = Field(..., ge=0.0, le=10.0, description="10% weight")
    feedback: str | None = Field(default=None)
    correct_opening: str | None = Field(default=None)
    correct_word: str | None = Field(default=None)

    @classmethod
    def from_protocol_payload(cls, payload: dict, game_id: str) -> "GuessResult":
        """Parse from protocol payload."""
        scores = payload.get("scores", {})
        return cls(
            game_id=game_id,
            total_score=payload.get("total_score", 0),
            opening_score=scores.get("opening_sentence", 0),
            sentence_justification_score=scores.get("sentence_justification", 0),
            word_score=scores.get("associative_word", 0),
            word_justification_score=scores.get("word_justification", 0),
            feedback=payload.get("feedback"),
            correct_opening=payload.get("correct_opening"),
            correct_word=payload.get("correct_word"),
        )
