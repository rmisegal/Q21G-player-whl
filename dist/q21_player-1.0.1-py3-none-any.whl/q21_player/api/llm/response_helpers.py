"""
Helper functions for LLMPlayerAI responses.

Provides fallback generators and response extractors.
"""


def validate_questions(questions: list) -> bool:
    """Validate questions list has correct structure."""
    if not isinstance(questions, list) or len(questions) != 20:
        return False
    for q in questions:
        if not all(k in q for k in ["question_number", "question_text", "options"]):
            return False
    return True


def fallback_questions(book_name: str) -> list[dict]:
    """Generate fallback questions if LLM fails."""
    questions = []
    for i in range(1, 21):
        questions.append({
            "question_number": i,
            "question_text": f"Is question {i} about {book_name} relevant?",
            "options": {"A": "Yes", "B": "No", "C": "Partially", "D": "Unknown"},
        })
    return questions


def extract_guess(parsed: dict) -> dict:
    """Extract guess fields from parsed LLM response."""
    default_word_just = (
        "The association word was selected based on thematic connections "
        "observed in the answer patterns and the overall context of the book "
        "description provided at the start of the game."
    )
    default_sent_just = (
        "The opening sentence was derived from careful analysis of all twenty "
        "question responses combined with the book hint and associative domain "
        "to identify the most likely narrative beginning for this particular book."
    )
    return {
        "opening_sentence": parsed.get("opening_sentence", "Unknown opening."),
        "sentence_justification": parsed.get("sentence_justification", default_sent_just),
        "associative_word": parsed.get("associative_word", "unknown"),
        "word_justification": parsed.get("word_justification", default_word_just),
        "confidence": float(parsed.get("confidence", 0.5)),
    }


def fallback_guess() -> dict:
    """Return fallback guess if LLM fails."""
    return {
        "opening_sentence": "The story begins with an unknown opening.",
        "sentence_justification": (
            "Unable to determine the exact opening from the answers provided. "
            "The pattern of responses did not provide sufficiently clear direction "
            "to identify the specific book. Making a general guess based on "
            "typical book openings and common literary conventions."
        ),
        "associative_word": "beginning",
        "word_justification": (
            "Choosing a general word that relates to story openings and "
            "narrative structure since the answer pattern was inconclusive. "
            "This word captures the essence of starting a new story."
        ),
        "confidence": 0.3,
    }
