"""ORM models for season, assignments, standings, and game state."""
from datetime import UTC, datetime
from sqlalchemy import Column, DateTime, Integer, Numeric, String, Text, UniqueConstraint

from q21_player._infra.repository.orm_core_models import Base

def _now() -> datetime: return datetime.now(UTC)


class SeasonRegistrationModel(Base):
    __tablename__ = "season_registrations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    season_id = Column(String(50), nullable=False, unique=True, index=True)
    league_id = Column(String(50), nullable=True, index=True)
    season_name = Column(String(100), nullable=True)
    registration_status = Column(String(20), default="PENDING")  # PENDING, CONFIRMED, REJECTED, WITHDRAWN
    registered_at = Column(DateTime, default=_now)
    confirmed_at = Column(DateTime, nullable=True)
    rejection_reason = Column(String(255), nullable=True)


class AssignmentModel(Base):
    __tablename__ = "my_assignments"
    id = Column(Integer, primary_key=True, autoincrement=True)
    season_id = Column(String(50), nullable=False, index=True)
    round_number = Column(Integer, nullable=False)
    game_number = Column(Integer, nullable=False)
    role = Column(String(20), nullable=False)  # PLAYER_A, PLAYER_B (legacy)
    my_role = Column(String(10), nullable=True)  # PLAYER1, PLAYER2 (PRD spec)
    opponent_group_id = Column(String(100), nullable=True)
    referee_group_id = Column(String(100), nullable=True)
    game_id = Column(String(100), nullable=True, index=True)
    match_id = Column(String(50), nullable=True, index=True)
    assignment_status = Column(String(20), default="PENDING")  # PENDING, IN_PROGRESS, COMPLETED, FAILED
    received_at = Column(DateTime, default=_now)
    started_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    __table_args__ = (UniqueConstraint("season_id", "round_number", "game_number"),)


class StandingsModel(Base):
    __tablename__ = "season_standings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    season_id = Column(String(50), nullable=False, index=True)
    round_number = Column(Integer, nullable=False, index=True)
    group_id = Column(String(100), nullable=False)
    total_score = Column(Numeric(10, 2), default=0)
    games_played = Column(Integer, default=0)
    games_won = Column(Integer, default=0)
    rank = Column(Integer, nullable=True)
    received_at = Column(DateTime, default=_now)
    __table_args__ = (UniqueConstraint("season_id", "round_number", "group_id"),)


class GameStateModel(Base):
    __tablename__ = "game_state"
    match_id = Column(String(50), primary_key=True)
    player_email = Column(String(255), nullable=True, index=True)
    game_id = Column(String(100), nullable=True, index=True)
    current_phase = Column(String(30), nullable=False, default="AWAITING_WARMUP")
    book_name = Column(String(255), nullable=True)
    book_description = Column(Text, nullable=True)
    associative_domain = Column(String(50), nullable=True)
    warmup_question = Column(Text, nullable=True)
    warmup_answer = Column(Text, nullable=True)
    warmup_deadline = Column(DateTime, nullable=True)
    warmup_retry_count = Column(Integer, default=0)
    questions_deadline = Column(DateTime, nullable=True)
    guess_deadline = Column(DateTime, nullable=True)
    player_role = Column(String(20), nullable=True)  # QUESTIONER or ANSWERER
    questions_required = Column(Integer, nullable=True)  # Number of questions required
    time_limit_seconds = Column(Integer, nullable=True)  # Time limit in seconds
    created_at = Column(DateTime, default=_now)
    updated_at = Column(DateTime, default=_now, onupdate=_now)


class GameResultModel(Base):
    __tablename__ = "game_results"
    id = Column(Integer, primary_key=True, autoincrement=True)
    match_id = Column(String(50), nullable=False, unique=True, index=True)
    game_id = Column(String(100), nullable=True, index=True)
    season_id = Column(String(50), nullable=True, index=True)
    total_score = Column(Numeric(5, 2), nullable=False)
    opening_sentence_score = Column(Numeric(5, 2), nullable=True)
    sentence_justification_score = Column(Numeric(5, 2), nullable=True)
    associative_word_score = Column(Numeric(5, 2), nullable=True)
    word_justification_score = Column(Numeric(5, 2), nullable=True)
    opening_sentence_feedback = Column(Text, nullable=True)
    word_feedback = Column(Text, nullable=True)
    actual_opening_sentence = Column(Text, nullable=True)
    actual_associative_word = Column(String(100), nullable=True)
    received_at = Column(DateTime, default=_now)


class GameInvitationModel(Base):
    __tablename__ = "game_invitations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    match_id = Column(String(50), unique=True, nullable=False, index=True)
    player_email = Column(String(255), nullable=False, index=True)
    referee_email = Column(String(255), nullable=False)
    opponent_email = Column(String(255), nullable=True)
    book_name = Column(String(255), nullable=True)
    deadline = Column(DateTime, nullable=True)
    status = Column(String(20), default="PENDING")
    received_at = Column(DateTime, default=_now)
    responded_at = Column(DateTime, nullable=True)


