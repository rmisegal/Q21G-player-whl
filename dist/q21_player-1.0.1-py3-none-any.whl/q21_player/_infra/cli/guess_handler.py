"""Guess Handler for Q21_GUESS_CALL messages."""

from typing import Any

from q21_player._infra.cli.handlers.base_game_handler import BaseGameHandler
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository
from q21_player._infra.strategy.strategy_factory import get_strategy


class GuessHandler(BaseGameHandler):
    """Handles Q21_GUESS_CALL message processing."""

    def __init__(
        self,
        state_repo: GameStateRepository | None = None,
        game_repo: GameRepository | None = None,
    ):
        super().__init__(state_repo=state_repo, game_repo=game_repo)
        self._strategy = get_strategy()

    def process(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Process Q21_GUESS_CALL message.

        Args:
            payload: Guess call payload with match_id and deadline

        Returns:
            dict with match_id and generated guess
        """
        match_id = payload.get("match_id", "")
        deadline_str = payload.get("deadline", "")

        # Store deadline using helper
        deadline = self._parse_deadline(deadline_str)
        if deadline:
            self._state_repo.set_guess_deadline(match_id, deadline)

        # Get game context using helper
        context = self._get_game_context(match_id)

        # Generate guess using strategy
        result = self._strategy.formulate_guess(context)
        if not result.success:
            self._logger.error(f"Guess generation failed: {result.error}")
            return {"match_id": match_id, "error": result.error}

        guess = result.data

        # Store guess
        guess_data = {
            "opening_sentence": guess.opening_sentence,
            "sentence_justification": guess.sentence_justification,
            "associative_word": guess.associative_word,
            "word_justification": guess.word_justification,
            "confidence": guess.confidence,
            "strategy_used": guess.strategy_used,
        }
        self._game_repo.save_guess(match_id, guess_data)

        # Update phase
        self._state_repo.update_phase(match_id, "GUESS_SENT")

        self._logger.info(f"Generated guess for match {match_id}: word={guess.associative_word}")
        return {"match_id": match_id, "guess": guess_data}
