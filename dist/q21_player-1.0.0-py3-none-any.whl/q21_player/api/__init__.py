"""
q21_player - Student-facing package for Q21 game player role.

Students implement 4 AI callback methods; package handles infrastructure.
"""

__version__ = "0.2.0"

# Core classes
from .callbacks import PlayerAI
from .config import PlayerConfig, ConfigError
from .validator import SchemaValidator, ValidationError

# LLM integration
from .llm import LLMClient, LLMPlayerAI, LLMResponse

# Demo implementation
from .demo_player_ai import DemoPlayerAI

# State management (for advanced users)
from .state import GameState, GamePhase

# Errors
from .message_parser import MessageParseError

__all__ = [
    # Core
    "PlayerAI",
    "PlayerConfig",
    "SchemaValidator",
    "ValidationError",
    # LLM
    "LLMClient",
    "LLMPlayerAI",
    "LLMResponse",
    # Demo
    "DemoPlayerAI",
    # State
    "GameState",
    "GamePhase",
    # Errors
    "ConfigError",
    "MessageParseError",
    # Meta
    "__version__",
]
