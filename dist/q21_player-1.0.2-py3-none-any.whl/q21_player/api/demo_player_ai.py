"""
Demo PlayerAI implementation for testing.

Uses LLMPlayerAI with mock provider for predictable test responses.
"""

from .callbacks import PlayerAI
from .llm.llm_player_ai import LLMPlayerAI


class DemoPlayerAI(PlayerAI):
    """
    Demo implementation using LLMPlayerAI with mock provider.

    Provides predictable responses for testing the SDK integration
    without requiring actual LLM API calls.
    """

    def __init__(self):
        """Initialize with LLMPlayerAI using mock provider."""
        self._llm_ai = LLMPlayerAI(provider="mock")

    def get_warmup_answer(self, ctx: dict) -> dict:
        """Delegate warmup answer to LLMPlayerAI with mock provider."""
        return self._llm_ai.get_warmup_answer(ctx)

    def get_questions(self, ctx: dict) -> dict:
        """Delegate questions generation to LLMPlayerAI with mock provider."""
        return self._llm_ai.get_questions(ctx)

    def get_guess(self, ctx: dict) -> dict:
        """Delegate guess formulation to LLMPlayerAI with mock provider."""
        return self._llm_ai.get_guess(ctx)

    def on_score_received(self, ctx: dict) -> None:
        """Delegate score handling to LLMPlayerAI with mock provider."""
        self._llm_ai.on_score_received(ctx)
