"""Main player service coordinating all player operations."""
from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.domain.models.messages import IncomingMessage, OutgoingMessage
from q21_player._infra.domain.models.player_state import PlayerStateDTO
from q21_player._infra.domain.services.message_service import MessageService
from q21_player._infra.domain.services.state_machine import PlayerStateMachine
from q21_player._infra.domain.services.state_transitions import TransitionEvent
from q21_player._infra.domain.services.strategy_service import StrategyService
from q21_player._infra.shared.config.constants import PlayerState, UserRole
from q21_player._infra.shared.logging.logger import get_logger

if TYPE_CHECKING:
    from q21_player._infra.repository.state_repository import StateRepository


class PlayerService:
    def __init__(self, state_machine: PlayerStateMachine, message_service: MessageService,
                 strategy_service: StrategyService, state_repository: StateRepository | None = None):
        self._logger = get_logger("player_service")
        self._state_machine, self._message_service = state_machine, message_service
        self._strategy_service, self._state_repository = strategy_service, state_repository
        self._player_state: PlayerStateDTO | None = None
        self._on_state_change: Callable[[PlayerState], None] | None = None

    def initialize(self, player_email: str, player_name: str) -> PlayerStateDTO:
        if self._state_repository and (existing := self._state_repository.load_state(player_email)):
            self._player_state = existing
            self._logger.info(f"Loaded existing state for: {player_email}")
            return self._player_state
        self._player_state = PlayerStateDTO(player_email=player_email, player_name=player_name, current_state=PlayerState.INIT_START_STATE)
        if self._state_repository:
            self._state_repository.save_state(self._player_state)
        self._logger.info(f"Player initialized: {player_name} <{player_email}>")
        return self._player_state

    @property
    def state(self) -> PlayerStateDTO | None: return self._player_state
    @property
    def current_state(self) -> PlayerState: return self._player_state.current_state if self._player_state else PlayerState.INIT_START_STATE

    def set_state_change_callback(self, callback: Callable[[PlayerState], None]) -> None:
        self._on_state_change = callback

    def process_message(self, message: IncomingMessage) -> OutgoingMessage | None:
        if not self._player_state:
            self._logger.error("Player not initialized")
            return None
        if self._player_state.current_state == PlayerState.PAUSED and not self._is_from_manager(message):
            self._logger.warning("Ignoring non-manager message while PAUSED")
            return None
        if self._message_service.is_broadcast(message):
            return self._handle_broadcast(message)
        context = self._build_context(message)
        result = self._message_service.process_message(message, context)
        if result.state_changed and result.new_state:
            self._update_state(result.new_state)
        return result.response

    def _is_from_manager(self, message: IncomingMessage) -> bool:
        return message.envelope and message.envelope.sender_role == UserRole.MANAGER

    def _handle_broadcast(self, message: IncomingMessage) -> OutgoingMessage | None:
        match_id = self._player_state.current_game_id if self._player_state else None
        result, response = self._message_service.handle_broadcast(message, self._player_state.current_state, match_id)
        action = result.get("action")
        if action == "pause":
            self._transition_state(TransitionEvent.PAUSE_RECEIVED, result)
        elif action == "continue":
            self._update_state(PlayerState(result.get("restored_state", "REGISTERED")))
        elif action == "reset":
            self.reset()
        elif action == "season_start":
            self._transition_state(TransitionEvent.SEASON_START_RECEIVED, result)
        elif action in ("end_round", "end_season"):
            self._update_state(PlayerState.INIT_START_STATE)
            self._logger.info(f"State set to IDLE due to {action}")
        return response

    def _transition_state(self, event: TransitionEvent, metadata: dict = None) -> None:
        try:
            new_state = self._state_machine.transition(event, metadata)
            self._player_state.current_state, self._player_state.last_activity = new_state, datetime.now(UTC)
            if self._state_repository:
                self._state_repository.save_state(self._player_state)
            self._logger.info(f"State transitioned via {event.value} -> {new_state.value}")
            if self._on_state_change:
                self._on_state_change(new_state)
        except Exception as e:
            self._logger.error(f"State transition failed: {e}")

    def _build_context(self, message: IncomingMessage) -> GameContext:
        ps = self._player_state
        return GameContext(game_id=message.envelope.transaction_id if message.envelope else "", player_email=ps.player_email,
            player_name=ps.player_name, current_state=ps.current_state, book_name=ps.current_book or "",
            general_description=ps.current_description or "", associative_domain=ps.current_domain or "")

    def _update_state(self, new_state: PlayerState) -> None:
        old_state = self._player_state.current_state
        self._player_state.current_state, self._player_state.last_activity = new_state, datetime.now(UTC)
        if self._state_repository:
            self._state_repository.save_state(self._player_state)
        self._logger.info(f"State changed: {old_state} -> {new_state}")
        if self._on_state_change:
            self._on_state_change(new_state)

    def _make_context(self, with_history: bool = False) -> GameContext:
        ps = self._player_state
        ctx = GameContext(game_id=ps.current_game_id, player_email=ps.player_email, player_name=ps.player_name,
            current_state=ps.current_state, book_name=ps.current_book or "", general_description=ps.current_description or "",
            associative_domain=ps.current_domain or "")
        if with_history:
            ctx.question_history = ps.question_history
        return ctx

    def generate_questions(self) -> OutgoingMessage | None:
        if not self._player_state or not self._player_state.current_game_id:
            return None
        context = self._make_context()
        result = self._strategy_service.generate_questions(context)
        return self._message_service.build_question_response(result.data, context) if result.success and result.data else None

    def formulate_guess(self) -> OutgoingMessage | None:
        if not self._player_state or not self._player_state.current_game_id:
            return None
        context = self._make_context(with_history=True)
        result = self._strategy_service.formulate_guess(context)
        return self._message_service.build_guess_response(result.data, context) if result.success and result.data else None

    def reset(self) -> None:
        if self._player_state:
            self._player_state.current_state, self._player_state.current_game_id, self._player_state.current_book = PlayerState.INIT_START_STATE, None, None
            if self._state_repository:
                self._state_repository.clear_game_context(self._player_state.player_email)
            self._logger.info("Player reset to IDLE")
