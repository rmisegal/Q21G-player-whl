"""
Performance logger for metrics and timing.

Tracks operation durations and performance metrics.
"""

import time
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from q21_player._infra.shared.logging.logger import get_logger


@dataclass
class PerformanceMetric:
    """Single performance measurement."""

    operation: str
    duration_ms: float
    timestamp: str
    metadata: dict[str, Any] = field(default_factory=dict)


class PerformanceLogger:
    """
    Logger for tracking performance metrics.

    Provides timing decorators and context managers.
    """

    def __init__(self, component: str) -> None:
        self._logger = get_logger(f"perf.{component}")
        self._component = component
        self._metrics: list[PerformanceMetric] = []

    @contextmanager
    def measure(
        self, operation: str, metadata: dict[str, Any] | None = None
    ) -> Generator[None, None, None]:
        """
        Context manager to measure operation duration.

        Usage:
            with perf_logger.measure("send_email"):
                gmail_client.send(message)
        """
        start = time.perf_counter()
        try:
            yield
        finally:
            duration_ms = (time.perf_counter() - start) * 1000
            metric = PerformanceMetric(
                operation=operation,
                duration_ms=round(duration_ms, 2),
                timestamp=datetime.now(UTC).isoformat(),
                metadata=metadata or {},
            )
            self._metrics.append(metric)
            self._logger.debug(
                f"[{operation}] completed in {duration_ms:.2f}ms"
            )

    def log_metric(
        self, operation: str, duration_ms: float, metadata: dict[str, Any] | None = None
    ) -> None:
        """Manually log a performance metric."""
        metric = PerformanceMetric(
            operation=operation,
            duration_ms=round(duration_ms, 2),
            timestamp=datetime.now(UTC).isoformat(),
            metadata=metadata or {},
        )
        self._metrics.append(metric)
        self._logger.debug(f"[{operation}] {duration_ms:.2f}ms")

    def get_metrics(self) -> list[dict[str, Any]]:
        """Get all recorded metrics."""
        return [
            {
                "operation": m.operation,
                "duration_ms": m.duration_ms,
                "timestamp": m.timestamp,
                "metadata": m.metadata,
            }
            for m in self._metrics
        ]

    def get_summary(self) -> dict[str, Any]:
        """Get performance summary statistics."""
        if not self._metrics:
            return {"total_operations": 0}

        by_operation: dict[str, list[float]] = {}
        for m in self._metrics:
            if m.operation not in by_operation:
                by_operation[m.operation] = []
            by_operation[m.operation].append(m.duration_ms)

        summary = {
            "total_operations": len(self._metrics),
            "operations": {},
        }

        for op, durations in by_operation.items():
            summary["operations"][op] = {
                "count": len(durations),
                "avg_ms": round(sum(durations) / len(durations), 2),
                "min_ms": round(min(durations), 2),
                "max_ms": round(max(durations), 2),
            }

        return summary

    def clear_metrics(self) -> None:
        """Clear all recorded metrics."""
        self._metrics.clear()
