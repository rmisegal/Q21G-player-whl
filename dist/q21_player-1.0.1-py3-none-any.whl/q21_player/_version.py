"""Version information for q21-player package."""

__version__ = "1.0.0"
