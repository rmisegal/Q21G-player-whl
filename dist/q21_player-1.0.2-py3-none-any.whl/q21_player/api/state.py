"""
Game state and phase management.

Tracks the current game phase and stores round data.
"""

from enum import Enum, auto
from dataclasses import dataclass, field


class GamePhase(Enum):
    """Phases of a Q21 game."""

    WAITING_FOR_WARMUP = auto()
    WAITING_FOR_ROUND_START = auto()
    WAITING_FOR_ANSWERS = auto()
    WAITING_FOR_SCORE = auto()
    COMPLETED = auto()


@dataclass
class GameState:
    """
    Tracks the current state of a Q21 game.

    Stores game identifiers, book info, and questions/answers.
    """

    phase: GamePhase = GamePhase.WAITING_FOR_WARMUP
    game_id: str | None = None
    match_id: str | None = None
    referee_id: str | None = None
    auth_token: str | None = None
    book_name: str | None = None
    book_hint: str | None = None
    association_word: str | None = None
    questions_sent: list = field(default_factory=list)
    answers_received: list = field(default_factory=list)

    def advance_phase(self, new_phase: GamePhase) -> None:
        """Advance to a new game phase."""
        self.phase = new_phase

    def reset(self) -> None:
        """Reset state for a new game."""
        self.phase = GamePhase.WAITING_FOR_WARMUP
        self.game_id = None
        self.match_id = None
        self.referee_id = None
        self.auth_token = None
        self.book_name = None
        self.book_hint = None
        self.association_word = None
        self.questions_sent = []
        self.answers_received = []
