"""Base response builder with shared initialization and envelope creation."""
from __future__ import annotations
from typing import TYPE_CHECKING

from q21_player._infra.domain.models.envelope import Envelope
from q21_player._infra.domain.models.message_context import MessageContext
from q21_player._infra.shared.config.constants import MessageType
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.factories.envelope_factory import EnvelopeFactory
from q21_player._infra.shared.logging.logger import get_logger

if TYPE_CHECKING:
    from q21_player._infra.shared.config.protocol_registry import ProtocolRegistry


class BaseResponseBuilder:
    """Base class for response builders with shared initialization."""

    def __init__(self, registry: ProtocolRegistry | None = None):
        """Initialize with logger, config, envelope factory, and optional registry."""
        self._logger = get_logger(self.__class__.__name__.lower())
        self._config = Config()
        self._envelope_factory = EnvelopeFactory(self._config)
        self._registry = registry

    def _create_envelope(
        self,
        msg_type: MessageType,
        recipient: str | None = None,
        reply_to: str | None = None,
        context: MessageContext | None = None,
        txn_id: str | None = None,
    ) -> Envelope:
        """Create envelope using the envelope factory.

        Args:
            msg_type: Message type for the envelope
            recipient: Recipient email (uses default if None)
            reply_to: Transaction ID this message replies to
            context: Optional message context
            txn_id: Custom transaction ID (generated if None)

        Returns:
            Configured Envelope instance
        """
        return self._envelope_factory.create(
            msg_type, recipient=recipient, reply_to=reply_to, context=context, txn_id=txn_id
        )
