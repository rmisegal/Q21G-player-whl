"""
Domain layer for GmailAsPlayer.

Contains business logic, domain models, and services:
- Models: Data structures for game entities
- Services: Business logic and state management
"""

from q21_player._infra.domain.models import (
    Answer,
    AnswerBatch,
    Envelope,
    GameContext,
    Guess,
    IncomingMessage,
    OutgoingMessage,
    PlayerStateDTO,
    Question,
    QuestionBatch,
)

__all__ = [
    "PlayerStateDTO",
    "GameContext",
    "IncomingMessage",
    "OutgoingMessage",
    "Envelope",
    "Question",
    "QuestionBatch",
    "Answer",
    "AnswerBatch",
    "Guess",
]
