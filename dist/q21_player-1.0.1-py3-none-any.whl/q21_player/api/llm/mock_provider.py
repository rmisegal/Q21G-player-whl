"""
Mock LLM provider for testing.

Returns predictable responses for warmup, questions, and guess prompts.
"""

import json


def get_mock_response(prompt: str) -> str:
    """Return predictable mock response based on prompt content.

    NOTE: Order matters! Check for more specific patterns first.
    The guess prompt contains "QUESTIONS AND ANSWERS" so we must
    check for "guess" BEFORE checking for "questions".
    """
    prompt_lower = prompt.lower()

    if "warmup" in prompt_lower:
        return '{"answer": "4"}'

    # Check for guess FIRST (guess prompt contains "questions and answers")
    if "guess" in prompt_lower or "formulate" in prompt_lower:
        return json.dumps({
            "opening_sentence": "Demo opening sentence for testing.",
            "sentence_justification": (
                "The opening sentence was carefully analyzed based on the pattern "
                "of answers received during the questioning phase combined with the "
                "book hint and associative domain provided at game start to make this guess."
            ),
            "associative_word": "demo",
            "word_justification": (
                "The association word was chosen based on thematic connections "
                "observed throughout the answer patterns and the overall context "
                "of the book description provided."
            ),
            "confidence": 0.75,
        })

    # Check for questions generation (after guess check)
    if "questions" in prompt_lower or "round" in prompt_lower:
        questions = [
            {
                "question_number": i,
                "question_text": f"Demo question {i}?",
                "options": {"A": "Yes", "B": "No", "C": "Maybe", "D": "Unknown"},
            }
            for i in range(1, 21)
        ]
        return json.dumps({"questions": questions})

    return "{}"
