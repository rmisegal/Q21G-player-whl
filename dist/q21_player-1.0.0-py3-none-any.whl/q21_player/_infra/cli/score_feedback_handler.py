"""Score Feedback Handler for Q21_SCORE_FEEDBACK messages."""

from decimal import Decimal
from typing import Any

from q21_player._infra.cli.handlers.base_game_handler import BaseGameHandler
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.game_result_repository import GameResultRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository


class ScoreFeedbackHandler(BaseGameHandler):
    """Handles Q21_SCORE_FEEDBACK message processing."""

    def __init__(
        self,
        state_repo: GameStateRepository | None = None,
        game_repo: GameRepository | None = None,
        result_repo: GameResultRepository | None = None,
    ):
        super().__init__(state_repo=state_repo, game_repo=game_repo)
        self._result_repo = result_repo or GameResultRepository()

    def process(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Process Q21_SCORE_FEEDBACK message.

        Args:
            payload: Score feedback payload with scores breakdown

        Returns:
            dict with match_id, total_score, and is_correct
        """
        match_id = payload.get("match_id", "")

        # Extract fields per UNIFIED_PROTOCOL.md Section 7.8
        league_points = payload.get("league_points", 0)  # Required field
        private_score = payload.get("private_score", 0.0)  # Required field
        breakdown_data = payload.get("breakdown", {})  # Required field
        feedback_data = payload.get("feedback", {})  # Optional field

        # Extract score breakdown
        breakdown = {
            "opening_sentence_score": breakdown_data.get("opening_sentence_score"),
            "sentence_justification_score": breakdown_data.get("sentence_justification_score"),
            "associative_word_score": breakdown_data.get("associative_word_score"),
            "word_justification_score": breakdown_data.get("word_justification_score"),
        }

        # Store result
        self._result_repo.save_result(
            match_id=match_id,
            total_score=Decimal(str(private_score)),
            breakdown=breakdown,
            feedback=feedback_data,
            actuals={},
            season_id=payload.get("season_id"),
        )

        # Update phase
        self._state_repo.update_phase(match_id, "COMPLETE")

        # Mark game as completed
        is_correct = private_score >= 50.0
        self._game_repo.complete_game(match_id, is_correct=is_correct, score=private_score)

        self._logger.info(f"Score feedback for match {match_id}: league_points={league_points}, private_score={private_score}")
        return {"match_id": match_id, "league_points": league_points, "private_score": private_score, "feedback": feedback_data, "is_correct": is_correct}
