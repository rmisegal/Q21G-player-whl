"""
Dependency Injection Container for GmailAsPlayer.
Provides singleton pattern for managing service instances.
"""

import threading
from collections.abc import Callable
from typing import Any, Optional, TypeVar

T = TypeVar("T")


class DIContainer:
    """
    DI Container with singleton, factory, and type registration.
    Thread-safe singleton implementation.
    """

    _instance: Optional["DIContainer"] = None
    _lock: threading.Lock = threading.Lock()
    _initialized: bool = False

    def __new__(cls) -> "DIContainer":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if DIContainer._initialized:
            return
        with DIContainer._lock:
            if DIContainer._initialized:
                return
            self._singletons: dict[str, Any] = {}
            self._factories: dict[str, Callable[[], Any]] = {}
            self._types: dict[str, type[Any]] = {}
            DIContainer._initialized = True

    def register_singleton(self, key: str, instance: Any) -> None:
        """Register a singleton instance."""
        self._singletons[key] = instance

    def register_factory(self, key: str, factory: Callable[[], T]) -> None:
        """Register a factory function."""
        self._factories[key] = factory

    def register_type(self, key: str, type_class: type[T]) -> None:
        """Register a type for lazy instantiation."""
        self._types[key] = type_class

    def resolve(self, key: str) -> Any | None:
        """Resolve a service by key. Returns None if not found."""
        if key in self._singletons:
            return self._singletons[key]
        if key in self._factories:
            instance = self._factories[key]()
            self._singletons[key] = instance
            return instance
        if key in self._types:
            instance = self._types[key]()
            self._singletons[key] = instance
            return instance
        return None

    def resolve_required(self, key: str) -> Any:
        """Resolve a service, raising KeyError if not found."""
        instance = self.resolve(key)
        if instance is None:
            raise KeyError(f"Service not registered: {key}")
        return instance

    def has(self, key: str) -> bool:
        """Check if a service is registered."""
        return key in self._singletons or key in self._factories or key in self._types

    def unregister(self, key: str) -> None:
        """Remove a service registration."""
        self._singletons.pop(key, None)
        self._factories.pop(key, None)
        self._types.pop(key, None)

    def clear(self) -> None:
        """Clear all registrations."""
        self._singletons.clear()
        self._factories.clear()
        self._types.clear()

    @property
    def registered_keys(self) -> list[str]:
        """Get list of all registered service keys."""
        keys = set(self._singletons.keys())
        keys.update(self._factories.keys())
        keys.update(self._types.keys())
        return sorted(keys)
