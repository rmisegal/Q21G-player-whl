"""Broadcast repository for tracking League Manager broadcasts."""

from datetime import UTC, datetime

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import BroadcastReceivedModel


class BroadcastRepository(BaseRepository[BroadcastReceivedModel]):
    """Repository for broadcast message operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(BroadcastReceivedModel, pool)

    def save_broadcast(
        self, broadcast_id: str, message_type: str, league_id: str | None = None,
        round_id: str | None = None, payload: dict | None = None,
        message_text: str | None = None, response_required: bool = False,
    ) -> BroadcastReceivedModel:
        """Save a received broadcast message."""
        model = BroadcastReceivedModel(
            broadcast_id=broadcast_id, message_type=message_type, league_id=league_id,
            round_id=round_id, payload=payload, message_text=message_text,
            response_required=response_required,
        )
        return self.create(model)

    def get_by_broadcast_id(self, broadcast_id: str) -> BroadcastReceivedModel | None:
        """Get broadcast by broadcast ID."""
        return self._query_one({"broadcast_id": broadcast_id}, "get broadcast")

    def broadcast_exists(self, broadcast_id: str) -> bool:
        """Check if broadcast already exists (for duplicate detection)."""
        return self.get_by_broadcast_id(broadcast_id) is not None

    def mark_responded(self, broadcast_id: str, response_txid: str) -> bool:
        """Mark a broadcast as responded."""
        result = self._update_fields(
            {"broadcast_id": broadcast_id},
            {"response_sent": True, "response_txid": response_txid, "responded_at": datetime.now(UTC)},
            "mark responded"
        )
        if result:
            self._logger.info(f"Broadcast {broadcast_id} marked as responded")
        return result

    def get_unresponded(self, limit: int = 50) -> list[BroadcastReceivedModel]:
        """Get broadcasts that require response but haven't been responded to."""
        return self._query_many(
            {"response_required": True, "response_sent": False},
            BroadcastReceivedModel.received_at, limit
        )

    def get_by_type(self, message_type: str, limit: int = 50) -> list[BroadcastReceivedModel]:
        """Get broadcasts by message type."""
        return self._query_many(
            {"message_type": message_type},
            BroadcastReceivedModel.received_at.desc(), limit
        )

    def get_by_league_id(self, league_id: str, limit: int = 50) -> list[BroadcastReceivedModel]:
        """Get broadcasts by league ID."""
        return self._query_many(
            {"league_id": league_id},
            BroadcastReceivedModel.received_at.desc(), limit
        )

    def get_recent(self, limit: int = 50) -> list[BroadcastReceivedModel]:
        """Get recent broadcasts."""
        return self._query_many(None, BroadcastReceivedModel.received_at.desc(), limit)
