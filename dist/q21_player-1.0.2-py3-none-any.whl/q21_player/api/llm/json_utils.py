"""
JSON parsing utilities for LLM responses.

Handles extraction of JSON from various LLM output formats.
"""

import json


def parse_json_response(content: str) -> dict | None:
    """
    Extract and parse JSON from LLM response content.

    Handles multiple formats:
    - Direct JSON string
    - JSON in markdown code blocks
    - JSON object embedded in text

    Args:
        content: Raw LLM response content

    Returns:
        Parsed dict or None if parsing fails
    """
    # Try direct parse
    result = _try_direct_parse(content)
    if result is not None:
        return result

    # Try markdown code block
    result = _try_markdown_block(content)
    if result is not None:
        return result

    # Try embedded JSON object
    return _try_embedded_json(content)


def _try_direct_parse(content: str) -> dict | None:
    """Try to parse content directly as JSON."""
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return None


def _try_markdown_block(content: str) -> dict | None:
    """Try to extract JSON from markdown code block."""
    if "```json" not in content:
        return None

    start = content.find("```json") + 7
    end = content.find("```", start)
    if end <= start:
        return None

    try:
        return json.loads(content[start:end].strip())
    except json.JSONDecodeError:
        return None


def _try_embedded_json(content: str) -> dict | None:
    """Try to find and parse embedded JSON object."""
    start = content.find("{")
    end = content.rfind("}") + 1
    if start < 0 or end <= start:
        return None

    try:
        return json.loads(content[start:end])
    except json.JSONDecodeError:
        return None
