"""
Configuration module for GmailAsPlayer.

Provides:
- Config singleton with dot notation access
- Constant enums (UserRole, MessageType, PlayerState)
"""

from q21_player._infra.shared.config.constants import (
    MessageType,
    PlayerState,
    UserRole,
)
from q21_player._infra.shared.config.settings import Config

__all__ = [
    "Config",
    "MessageType",
    "PlayerState",
    "UserRole",
]
