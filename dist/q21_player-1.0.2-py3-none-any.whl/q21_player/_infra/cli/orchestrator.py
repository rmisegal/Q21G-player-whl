"""Player orchestrator coordinating all components."""
import time

from q21_player._infra.cli.periodic_handler import PeriodicHandler
from q21_player._infra.heartbeat.writer import HeartbeatWriter
from q21_player._infra.domain.models.messages import OutgoingMessage
from q21_player._infra.domain.services.game_service import GameService
from q21_player._infra.domain.services.message_parser import MessageParser
from q21_player._infra.domain.services.message_service import MessageService
from q21_player._infra.shared.config.protocol_registry import get_default_registry
from q21_player._infra.domain.services.player_service import PlayerService
from q21_player._infra.domain.services.registration_service import RegistrationService
from q21_player._infra.domain.services.state_machine import PlayerStateMachine
from q21_player._infra.domain.services.strategy_service import StrategyService
from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.gmail.attachment_handler import AttachmentHandler
from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.gmail.scanner import GmailScanner
from q21_player._infra.gmail.sender import GmailSender
from q21_player._infra.repository.state_repository import StateRepository
from q21_player._infra.shared.config.constants import DEFAULT_POLL_INTERVAL_SEC, DEFAULT_STATE_TIMEOUT_SEC, PlayerState
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.logging.logger import get_logger


class PlayerOrchestrator:
    def __init__(self, player_email: str, player_name: str, strategy_type: str = "llm",
                 poll_interval: int = DEFAULT_POLL_INTERVAL_SEC, dry_run: bool = False):
        self._logger, self._config = get_logger("orchestrator"), Config()
        self._player_email, self._player_name, self._dry_run, self._running = player_email, player_name, dry_run, False
        self._db_pool, self._state_repo = ConnectionPool(), StateRepository(ConnectionPool())
        self._gmail_client = GmailClient()
        self._scanner, self._sender = GmailScanner(self._gmail_client), GmailSender(self._gmail_client)
        self._registry = get_default_registry()
        self._attachment_handler, self._message_parser = AttachmentHandler(self._gmail_client), MessageParser(registry=self._registry)
        initial_state = self._load_persisted_state()
        self._state_machine = PlayerStateMachine(player_email, initial_state=initial_state, repository=self._state_repo)
        self._message_service, self._strategy_service = MessageService(self._state_machine), StrategyService()
        self._player_service = PlayerService(self._state_machine, self._message_service, self._strategy_service, state_repository=self._state_repo)
        self._registration_service, self._game_service = RegistrationService(player_email, player_name, repository=self._state_repo), GameService(player_email)
        self._periodic_handler = PeriodicHandler(poll_callback=self._poll_messages, poll_interval=poll_interval,
            heartbeat_callback=self._send_heartbeat, heartbeat_interval=DEFAULT_STATE_TIMEOUT_SEC)
        self._watchdog_writer = HeartbeatWriter(heartbeat_dir="heartbeats", process_key="gmail_as_player")

    def _load_persisted_state(self) -> PlayerState:
        # Check if config specifies an initial state
        if config_state := self._config.get("app.initial_state"):
            try:
                state = PlayerState(config_state)
                self._logger.info(f"Using configured initial state: {state.value}")
                return state
            except ValueError:
                self._logger.warning(f"Invalid initial_state in config: {config_state}")
        # Fall back to persisted state
        try:
            if loaded := self._state_repo.load_state(self._player_email):
                state_val = loaded.current_state.value if hasattr(loaded.current_state, 'value') else loaded.current_state
                self._logger.info(f"Loaded persisted state: {state_val}")
                return PlayerState(state_val)
        except Exception as e: self._logger.warning(f"Could not load persisted state: {e}")
        self._logger.info("Starting with IDLE state")
        return PlayerState.INIT_START_STATE

    def start(self) -> None:
        self._logger.info(f"Starting player: {self._player_name}")
        self._running = True
        try:
            self._gmail_client.authenticate()
        except Exception as e:
            self._logger.error(f"Gmail authentication failed: {e}"); return
        self._player_service.initialize(self._player_email, self._player_name)
        if self._config.get("app.auto_register", True): self._register()
        else: self._logger.info("Skipping auto-registration (disabled in config)")
        self._periodic_handler.start()
        self._logger.info("Player started successfully")
        loop_interval = self._config.get("app.loop_interval_sec", 1)
        while self._running:
            try: time.sleep(loop_interval)
            except KeyboardInterrupt: break

    def stop(self) -> None:
        self._logger.info("Stopping player")
        self._running = False
        self._periodic_handler.stop()
        self._watchdog_writer.stop()
        if self._config.get("app.auto_register", True):
            self._unregister()
        self._logger.info("Player stopped")

    def _send_message(self, message: OutgoingMessage) -> None:
        self._sender.send(to=message.envelope.recipient_email, subject=message.envelope.to_subject_line(),
            body=message.body_text, attachment=message.payload, attachment_name=message.attachment_name)

    def _register(self) -> None:
        if self._dry_run:
            self._logger.info("[DRY RUN] Would send registration"); return
        if self._state_machine.current_state == PlayerState.REGISTERED:
            self._logger.warning("Already registered - sending registration for validation only")
        self._send_message(self._registration_service.create_registration_request())
        self._logger.info("Registration request sent")

    def _unregister(self) -> None:
        if self._dry_run:
            self._logger.info("[DRY RUN] Would send unregistration"); return
        if message := self._registration_service.create_unregister_request():
            self._send_message(message)
            self._logger.info("Unregistration request sent")

    def _send_heartbeat(self) -> None:
        if not self._dry_run and (message := self._registration_service.create_heartbeat_message()):
            self._send_message(message)

    def _poll_messages(self) -> None:
        errors = []
        try:
            messages = self._scanner.scan_once()
        except Exception as e:
            self._logger.error(f"Scan failed: {e}"); errors.append(str(e)); messages = []
        self._logger.debug(f"Found {len(messages)} message(s)")
        for i, msg in enumerate(messages):
            try: self._process_message(msg)
            except Exception as e: self._logger.error(f"Failed to process message {i}: {e}"); errors.append(str(e))
        self._watchdog_writer.beat(status="error" if errors else "running")

    def _process_message(self, gmail_message: dict) -> None:
        try:
            payload = self._attachment_handler.get_payload_from_message(gmail_message)
            if payload is None: self._logger.warning("No JSON payload found in message"); return
            message = self._message_parser.parse_gmail_message(gmail_message, payload)
            self._logger.info(f"Processing: {message.message_type}")
            response = self._player_service.process_message(message)
            self._scanner.mark_as_read(gmail_message.get("id", ""))
            if response and not self._dry_run: self._send_message(response)
        except Exception as e: self._logger.error(f"Failed to process message: {e}")

    @property
    def stats(self) -> dict:
        return {"player_email": self._player_email, "player_name": self._player_name,
            "current_state": self._player_service.current_state.value, "is_registered": self._registration_service.is_registered,
            "game_stats": self._game_service.get_statistics(), "polling": self._periodic_handler.stats}
