"""Assignment Handler for processing BROADCAST_ASSIGNMENT_TABLE messages."""

from typing import Any

from q21_player._infra.repository.assignment_repository import AssignmentRepository
from q21_player._infra.shared.logging.logger import get_logger

PLAYER_ROLES = ["PLAYER1", "PLAYER2", "PLAYER_A", "PLAYER_B"]


class AssignmentHandler:
    """Handles assignment broadcast messages and stores relevant assignments."""

    def __init__(self, assignment_repo: AssignmentRepository | None = None):
        self._logger = get_logger("assignment_handler")
        self._assignment_repo = assignment_repo or AssignmentRepository()

    def process(
        self,
        payload: dict[str, Any],
        group_id: str,
        role_filter: list[str] | None = None,
    ) -> dict[str, Any]:
        """Process assignment broadcast and store assignments for this player."""
        season_id = payload.get("season_id", "")
        round_number = payload.get("round_number", 0)
        all_assignments = payload.get("assignments", [])

        # Filter by group_id
        filtered = [a for a in all_assignments if a.get("group_id") == group_id]

        # Optionally filter by role
        if role_filter:
            filtered = [a for a in filtered if a.get("role") in role_filter]

        if not filtered:
            self._logger.info(f"No assignments for {group_id} in season {season_id} round {round_number}")
            return {"count": 0, "season_id": season_id, "round_number": round_number}

        # Enrich with opponent/referee info
        enriched = self._enrich_assignments(filtered, all_assignments)

        # Store assignments
        count = self._assignment_repo.save_assignments(
            season_id=season_id, round_number=round_number, assignments=enriched
        )

        self._logger.info(f"Stored {count} assignments for {group_id} in season {season_id} round {round_number}")
        return {"count": count, "season_id": season_id, "round_number": round_number}

    def _enrich_assignments(self, mine: list[dict], all_asgn: list[dict]) -> list[dict]:
        """Enrich assignments with opponent_group_id, referee_group_id, my_role."""
        result = []
        for a in mine:
            game_id = a.get("game_id")
            my_group = a.get("group_id")
            enriched = dict(a)
            enriched["my_role"] = a.get("role") if a.get("role") in PLAYER_ROLES else None
            enriched["opponent_group_id"] = None
            enriched["referee_group_id"] = None

            # Find opponent and referee from same game_id
            for other in all_asgn:
                if other.get("game_id") != game_id or other.get("group_id") == my_group:
                    continue
                role = other.get("role", "")
                if role in PLAYER_ROLES:
                    enriched["opponent_group_id"] = other.get("group_id")
                elif role == "REFEREE":
                    enriched["referee_group_id"] = other.get("group_id")
            result.append(enriched)
        return result
