"""
Gmail integration module for GmailAsPlayer.

Provides:
- GmailClient: OAuth2 authenticated Gmail API client
- GmailScanner: Email polling and filtering
- GmailSender: Outgoing email with attachments
- AttachmentHandler: JSON attachment processing
"""

from q21_player._infra.gmail.attachment_handler import AttachmentHandler
from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.gmail.scanner import GmailScanner
from q21_player._infra.gmail.sender import GmailSender

__all__ = [
    "GmailClient",
    "GmailScanner",
    "GmailSender",
    "AttachmentHandler",
]
