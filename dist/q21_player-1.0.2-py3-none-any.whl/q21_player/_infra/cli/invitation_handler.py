"""Handler for GAME_INVITATION messages - Phase 2 of SYSTEM_INTEGRATION_PRD."""

from datetime import datetime, UTC

from q21_player._infra.cli.handlers.base_game_handler import BaseGameHandler
from q21_player._infra.repository.game_invitation_repository import GameInvitationRepository
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.state_repository import StateRepository


class InvitationHandler(BaseGameHandler):
    """Handles GAME_INVITATION messages, stores invitation, updates state."""

    def __init__(
        self,
        invitation_repo: GameInvitationRepository | None = None,
        player_state_repo: StateRepository | None = None,
        game_repo: GameRepository | None = None,
    ):
        super().__init__(state_repo=None, game_repo=game_repo)
        self._invitation_repo = invitation_repo or GameInvitationRepository()
        self._player_state_repo = player_state_repo or StateRepository()

    def process(self, payload: dict, player_email: str) -> dict:
        """Process GAME_INVITATION payload.

        Args:
            payload: The invitation payload containing match_id, referee_email, etc.
            player_email: The player's email address.

        Returns:
            dict with match_id, referee_email, accept flag, book info for response.
        """
        match_id = payload.get("match_id")
        referee_email = payload.get("referee_email", "")
        opponent_id = payload.get("opponent_id")
        role = payload.get("role")
        game_inv = payload.get("game_invitation", {})

        book_name = game_inv.get("book_name", "")
        description = game_inv.get("general_description", "")
        domain = game_inv.get("associative_domain", "")
        deadline = payload.get("deadline")

        self._logger.info(f"Processing invitation: match={match_id}, book={book_name}")

        # Store invitation in repository
        self._store_invitation(match_id, player_email, referee_email, opponent_id, book_name, deadline)

        # Update or create game session with match_id
        self._update_game_session(match_id, player_email, referee_email, opponent_id, role, book_name, description, domain)

        # Update player state
        self._update_player_state(player_email, match_id, book_name)

        return {
            "match_id": match_id,
            "referee_email": referee_email,
            "accept": True,
            "book_name": book_name,
            "description": description,
            "domain": domain,
        }

    def _store_invitation(self, match_id: str, player_email: str, referee_email: str,
                          opponent_email: str | None, book_name: str, deadline: datetime | None):
        """Store invitation in GameInvitationRepository."""
        try:
            self._invitation_repo.create(
                match_id=match_id,
                player_email=player_email,
                referee_email=referee_email,
                opponent_email=opponent_email,
                book_name=book_name,
                deadline=deadline,
            )
            self._logger.info(f"Stored invitation for match {match_id}")
        except Exception as e:
            self._logger.error(f"Failed to store invitation: {e}")

    def _update_game_session(self, match_id: str, player_email: str, referee_email: str,
                             opponent_id: str | None, role: str | None, book_name: str,
                             description: str, domain: str):
        """Update GameSessionModel with match information."""
        try:
            self._game_repo.create_or_update_by_match_id(
                match_id=match_id,
                player_email=player_email,
                referee_email=referee_email,
                opponent_email=opponent_id,
                my_role=role,
                book_name=book_name,
                description=description,
                domain=domain,
            )
            self._logger.info(f"Updated game session for match {match_id}")
        except Exception as e:
            self._logger.error(f"Failed to update game session: {e}")

    def _update_player_state(self, player_email: str, match_id: str, book_name: str):
        """Update player state with current match info."""
        try:
            self._player_state_repo.update_current_match(
                player_email=player_email,
                match_id=match_id,
                book_name=book_name,
            )
            self._logger.info(f"Updated player state for {player_email}")
        except Exception as e:
            self._logger.error(f"Failed to update player state: {e}")
