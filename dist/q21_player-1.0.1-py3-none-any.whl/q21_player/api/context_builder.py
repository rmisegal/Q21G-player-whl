"""
Context builder for callback invocations.

Builds context dictionaries passed to PlayerAI callbacks.
"""

from .state import GameState


SERVICE_DEFINITIONS = {
    "game": {
        "name": "Q21 Twenty-One Questions",
        "version": "1.0",
        "description": "Book guessing game with 20 questions",
    },
    "protocol": {
        "name": "Q21G.v1",
        "description": "Q21 Game Protocol version 1",
    },
}


def build_warmup_context(payload: dict) -> dict:
    """
    Build context for get_warmup_answer callback.

    Args:
        payload: Incoming message payload with warmup_question

    Returns:
        Context dict with dynamic and service sections
    """
    return {
        "dynamic": {
            "warmup_question": payload.get("warmup_question", ""),
        },
        "service": SERVICE_DEFINITIONS,
    }


def build_questions_context(payload: dict) -> dict:
    """
    Build context for get_questions callback.

    Args:
        payload: Incoming message payload with book info

    Returns:
        Context dict with dynamic and service sections
    """
    return {
        "dynamic": {
            "book_name": payload.get("book_name", ""),
            "book_hint": payload.get("book_hint", ""),
            "association_word": payload.get("association_word", ""),
        },
        "service": SERVICE_DEFINITIONS,
    }


def build_guess_context(payload: dict, state: GameState) -> dict:
    """
    Build context for get_guess callback.

    Args:
        payload: Incoming message payload with answers
        state: Current game state with book info

    Returns:
        Context dict with dynamic and service sections
    """
    return {
        "dynamic": {
            "answers": payload.get("answers", []),
            "book_name": state.book_name,
            "book_hint": state.book_hint,
            "association_word": state.association_word,
            "questions_sent": state.questions_sent,
        },
        "service": SERVICE_DEFINITIONS,
    }


def build_score_context(payload: dict) -> dict:
    """
    Build context for on_score_received callback.

    Args:
        payload: Incoming message payload with score info

    Returns:
        Context dict with dynamic and service sections
    """
    return {
        "dynamic": {
            "league_points": payload.get("league_points", 0),
            "private_score": payload.get("private_score", {}),
            "breakdown": payload.get("breakdown", {}),
        },
        "service": SERVICE_DEFINITIONS,
    }
