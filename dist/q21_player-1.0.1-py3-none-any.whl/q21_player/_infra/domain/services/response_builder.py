"""Response builder for GmailAsPlayer - creates outgoing messages."""

from typing import Any

from q21_player._infra.domain.models.envelope import Envelope
from q21_player._infra.domain.models.guess import Guess
from q21_player._infra.domain.models.message_context import MessageContext
from q21_player._infra.domain.models.messages import IncomingMessage, OutgoingMessage
from q21_player._infra.domain.models.question import QuestionBatch
from q21_player._infra.domain.services.base_response_builder import BaseResponseBuilder
from q21_player._infra.shared.config.constants import MessageType
from q21_player._infra.shared.utils.helpers import generate_transaction_id


class ResponseBuilder(BaseResponseBuilder):
    """Builds outgoing messages for various protocol responses."""

    def _create_envelope(
        self, recipient: str, msg_type: MessageType,
        reply_to: str | None = None,
        context: MessageContext | None = None
    ) -> Envelope:
        """Create a new envelope for outgoing message."""
        return super()._create_envelope(msg_type, recipient=recipient, reply_to=reply_to, context=context)

    def build_registration_request(self, manager_email: str) -> OutgoingMessage:
        """Build LEAGUE_REGISTER_REQUEST message per UNIFIED_PROTOCOL.md Section 5.1."""
        envelope = self._create_envelope(manager_email, MessageType.LEAGUE_REGISTER_REQUEST)
        # Flat payload per UNIFIED_PROTOCOL.md (no nested player_meta)
        payload = {
            "user_id": self._config.get("player.user_id", ""),
            "display_name": self._config.get("player.display_name", "GmailPlayer"),
            "game_types": ["Q21"],
            "contact_email": self._config.gmail.account,
        }
        return OutgoingMessage(envelope=envelope, payload=payload,
                               body_text="Registration request from GmailAsPlayer")

    def build_game_join_ack(self, invitation: IncomingMessage, accept: bool,
                            auth_token: str) -> OutgoingMessage:
        """Build GAME_JOIN_ACK response to invitation."""
        envelope = self._create_envelope(
            invitation.sender, MessageType.GAME_JOIN_ACK, invitation.transaction_id,
            context=invitation.envelope.context)
        match_id = invitation.payload.get("match_id") or invitation.payload.get("game_id")
        payload = {
            "match_id": match_id,
            "accept": accept,
            "auth_token": auth_token,
        }
        return OutgoingMessage(envelope=envelope, payload=payload,
                               body_text="Game invitation response")

    def build_questions_batch(self, referee_email: str, questions: QuestionBatch,
                              auth_token: str, match_id: str,
                              reply_to: str | None = None) -> OutgoingMessage:
        """Build Q21_QUESTIONS_BATCH message with auth_token and match_id."""
        envelope = self._create_envelope(referee_email, MessageType.Q21_QUESTIONS_BATCH, reply_to)
        payload = questions.to_protocol_payload()
        payload["match_id"] = match_id
        payload["auth_token"] = auth_token
        return OutgoingMessage(envelope=envelope, payload=payload,
                               body_text="Questions batch submission")

    def build_guess_submission(self, referee_email: str, guess: Guess,
                               auth_token: str, match_id: str,
                               reply_to: str | None = None) -> OutgoingMessage:
        """Build Q21_GUESS_SUBMISSION message with auth_token and match_id."""
        envelope = self._create_envelope(referee_email, MessageType.Q21_GUESS_SUBMISSION, reply_to)
        payload = guess.to_protocol_payload()
        payload["match_id"] = match_id
        payload["auth_token"] = auth_token
        return OutgoingMessage(envelope=envelope, payload=payload,
                               body_text="Final guess submission")

    def build_warmup_response(self, referee_email: str, match_id: str,
                              auth_token: str, answer: str,
                              reply_to: str | None = None) -> OutgoingMessage:
        """Build Q21_WARMUP_RESPONSE message."""
        envelope = self._create_envelope(referee_email, MessageType.Q21_WARMUP_RESPONSE, reply_to)
        payload = {"match_id": match_id, "auth_token": auth_token, "answer": answer}
        return OutgoingMessage(envelope=envelope, payload=payload,
                               body_text="Warmup response")

    def build_standings_request(self, manager_email: str,
                                auth_token: str) -> OutgoingMessage:
        """Build QUERY_STANDINGS_REQUEST message."""
        envelope = self._create_envelope(manager_email, MessageType.QUERY_STANDINGS_REQUEST)
        payload = {"auth_token": auth_token}
        return OutgoingMessage(envelope=envelope, payload=payload,
                               body_text="Standings query request")

    def build_connectivity_echo(self, original: IncomingMessage) -> OutgoingMessage:
        """Build CONNECTIVITY_TEST_ECHO response."""
        envelope = self._create_envelope(
            original.sender, MessageType.CONNECTIVITY_TEST_ECHO, original.transaction_id,
            context=original.envelope.context)
        payload = {
            "message_type": "CONNECTIVITY_TEST_RESPONSE",
            "ping_id": original.payload.get("ping_id"),
            "echo_from": self._config.gmail.account,
            "original_timestamp": original.payload.get("timestamp"),
        }
        return OutgoingMessage(envelope=envelope, payload=payload,
                               body_text="Connectivity test echo")

    def build_error_response(self, recipient: str, error_code: str,
                             error_message: str, reply_to: str | None = None) -> OutgoingMessage:
        """Build ERROR message."""
        envelope = self._create_envelope(recipient, MessageType.ERROR, reply_to)
        payload = {"error_code": error_code, "error_message": error_message,
                   "player_email": self._config.gmail.account}
        return OutgoingMessage(envelope=envelope, payload=payload, body_text=f"Error: {error_message}")

    def build_reply(self, original: IncomingMessage, msg_type: MessageType,
                    payload: dict[str, Any], body_text: str = "") -> OutgoingMessage:
        """Build generic reply to incoming message."""
        return OutgoingMessage.create_reply(
            original, msg_type, self._config.gmail.account,
            generate_transaction_id("tx"), payload, body_text)
