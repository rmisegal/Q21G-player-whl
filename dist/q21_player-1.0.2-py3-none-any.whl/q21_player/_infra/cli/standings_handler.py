"""Standings Handler for processing BROADCAST_ROUND_RESULTS messages."""

from typing import Any

from q21_player._infra.repository.standings_repository import StandingsRepository
from q21_player._infra.shared.logging.logger import get_logger


class StandingsHandler:
    """Handles round results broadcasts and stores standings."""

    def __init__(self, standings_repo: StandingsRepository | None = None):
        self._logger = get_logger("standings_handler")
        self._standings_repo = standings_repo or StandingsRepository()

    def process(self, payload: dict[str, Any], group_id: str) -> dict[str, Any]:
        """Process round results and store standings.

        Args:
            payload: Broadcast payload with standings array
            group_id: Player's group ID to find own standing

        Returns:
            dict with season_id, round_number, my_rank, my_score, total_participants
        """
        season_id = payload.get("season_id", "")
        round_number = payload.get("round_number", 0)
        all_standings = payload.get("standings", [])

        # Store all standings
        if all_standings:
            self._standings_repo.save_standings(
                season_id=season_id, round_number=round_number, standings=all_standings
            )
            self._logger.info(f"Stored {len(all_standings)} standings for {season_id} round {round_number}")

        # Find own standing
        my_standing = next((s for s in all_standings if s.get("group_id") == group_id), None)
        my_rank = my_standing.get("rank") if my_standing else None
        my_score = my_standing.get("total_score") if my_standing else None

        if my_standing:
            self._logger.info(f"My standing: rank={my_rank}, score={my_score}")
        else:
            self._logger.warning(f"Own standing not found for {group_id}")

        return {
            "season_id": season_id,
            "round_number": round_number,
            "my_rank": my_rank,
            "my_score": my_score,
            "total_participants": len(all_standings),
        }
