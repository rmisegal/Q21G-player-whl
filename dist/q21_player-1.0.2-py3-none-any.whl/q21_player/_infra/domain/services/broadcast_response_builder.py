"""Broadcast response builder for GmailAsPlayer - creates broadcast responses."""
import uuid
from datetime import UTC, datetime

from q21_player._infra.domain.models.envelope import Envelope
from q21_player._infra.domain.models.messages import OutgoingMessage
from q21_player._infra.domain.services.base_response_builder import BaseResponseBuilder
from q21_player._infra.shared.config.constants import DEFAULT_SENDER_ROLE, PROTOCOL_VERSION, MessageType, UserRole
from q21_player._infra.shared.utils.helpers import generate_transaction_id


class BroadcastResponseBuilder(BaseResponseBuilder):
    """Builds outgoing messages for broadcast responses."""

    def __init__(self):
        super().__init__()
        self._max_words = self._config.get("broadcast.max_response_text_words", 40)

    def _create_envelope(self, msg_type: MessageType, recipient_email: str | None = None):
        return super()._create_envelope(msg_type, recipient=recipient_email, txn_id=generate_transaction_id("resp"))

    def _truncate(self, text: str) -> str:
        w = text.split()
        return " ".join(w[:self._max_words]) if len(w) > self._max_words else text

    def _wrap(self, msg_type: MessageType, bid: str, inner: dict, recipient_id: str | None = None) -> dict:
        """Build wrapper with all required envelope fields per UNIFIED_PROTOCOL.md Section 2."""
        return {"protocol": PROTOCOL_VERSION, "message_type": msg_type.value, "message_id": str(uuid.uuid4()),
                "sender": {"email": self._config.gmail.account, "role": DEFAULT_SENDER_ROLE, "logical_id": None},
                "recipient_id": recipient_id or self._config.get("league.manager_email", "SERVER"),
                "timestamp": datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%S+00:00"),
                "correlation_id": bid, "league_id": self._config.get("league.league_id", "LEAGUE001"), "payload": inner}

    def _ts(self) -> str:
        return datetime.now(UTC).isoformat()

    def build_keep_alive_response(self, broadcast_id: str, machine_state: str, state_detail: str, message_text: str, recipient_email: str | None = None) -> OutgoingMessage:
        env = self._create_envelope(MessageType.RESPONSE_KEEP_ALIVE, recipient_email)
        inner = {"machine_state": machine_state, "state_detail": state_detail, "message_text": self._truncate(message_text),
                 "broadcast_id": broadcast_id, "response_timestamp": self._ts()}
        return OutgoingMessage(envelope=env, payload=self._wrap(MessageType.RESPONSE_KEEP_ALIVE, broadcast_id, inner), body_text="Keep-alive response")

    def build_free_text_response(self, broadcast_id: str, message_text: str) -> OutgoingMessage:
        env = self._create_envelope(MessageType.RESPONSE_FREE_TEXT)
        inner = {"broadcast_id": broadcast_id, "message_text": self._truncate(message_text), "response_timestamp": self._ts()}
        return OutgoingMessage(envelope=env, payload=self._wrap(MessageType.RESPONSE_FREE_TEXT, broadcast_id, inner), body_text="Free text response")

    def build_critical_reset_response(self, broadcast_id: str, tables_cleared: list[str], message_text: str) -> OutgoingMessage:
        env = self._create_envelope(MessageType.RESPONSE_CRITICAL_RESET)
        inner = {"broadcast_id": broadcast_id, "reset_status": "COMPLETED", "tables_cleared": tables_cleared,
                 "state_machine_reset": True, "ready_for_new_season": True, "message_text": self._truncate(message_text), "response_timestamp": self._ts()}
        return OutgoingMessage(envelope=env, payload=self._wrap(MessageType.RESPONSE_CRITICAL_RESET, broadcast_id, inner), body_text="Reset response")

    def build_critical_pause_response(self, broadcast_id: str, previous_state: str, match_id: str | None, message_text: str) -> OutgoingMessage:
        env = self._create_envelope(MessageType.RESPONSE_CRITICAL_PAUSE)
        inner = {"broadcast_id": broadcast_id, "pause_status": "PAUSED", "previous_state": previous_state,
                 "current_game_state": "SAVED" if match_id else "N/A", "match_id_paused": match_id,
                 "message_text": self._truncate(message_text), "response_timestamp": self._ts()}
        return OutgoingMessage(envelope=env, payload=self._wrap(MessageType.RESPONSE_CRITICAL_PAUSE, broadcast_id, inner), body_text="Pause response")

    def build_critical_continue_response(self, broadcast_id: str, restored_state: str, restored_match_id: str | None, message_text: str) -> OutgoingMessage:
        env = self._create_envelope(MessageType.RESPONSE_CRITICAL_CONTINUE)
        inner = {"broadcast_id": broadcast_id, "continue_status": "RESUMED", "restored_state": restored_state,
                 "restored_match_id": restored_match_id, "message_text": self._truncate(message_text), "response_timestamp": self._ts()}
        return OutgoingMessage(envelope=env, payload=self._wrap(MessageType.RESPONSE_CRITICAL_CONTINUE, broadcast_id, inner), body_text="Continue response")

    def build_assignment_response(self, broadcast_id: str, round_id: str, round_number: int, message_text: str, assignments_count: int = 0) -> OutgoingMessage:
        env = self._create_envelope(MessageType.RESPONSE_GROUP_ASSIGNMENT)
        inner = {"broadcast_id": broadcast_id, "assignment_received": assignments_count > 0, "round_id": round_id, "round_number": round_number,
                 "assignments_count": assignments_count, "message_text": self._truncate(message_text), "response_timestamp": self._ts()}
        return OutgoingMessage(envelope=env, payload=self._wrap(MessageType.RESPONSE_GROUP_ASSIGNMENT, broadcast_id, inner), body_text="Assignment response")

    def build_start_season_response(self, broadcast_id: str, season_id: str, season_name: str) -> OutgoingMessage:
        return self.build_season_registration_request(broadcast_id, season_id, season_name)

    def build_season_registration_request(self, broadcast_id: str, season_id: str, season_name: str, recipient_email: str | None = None) -> OutgoingMessage:
        env = self._create_envelope(MessageType.SEASON_REGISTRATION_REQUEST, recipient_email)
        env.transaction_id = f"sreg-player-{env.transaction_id.split('-')[-1]}"  # Format: sreg-player-XXX
        user_id = self._config.get("player.user_id", "")
        # Only required fields per COMPLETE_PROTOCOL.md Section 12
        inner = {"season_id": season_id, "user_id": user_id, "participant_role": "PLAYER", "display_name": self._config.get("player.display_name", "Player")}
        return OutgoingMessage(envelope=env, payload=self._wrap(MessageType.SEASON_REGISTRATION_REQUEST, broadcast_id, inner), body_text="Season registration request")

    def build_assignment_request(self, season_id: str, group_id: str) -> OutgoingMessage:
        env = self._create_envelope(MessageType.REQUEST_ASSIGNMENT_TABLE)
        inner = {"season_id": season_id, "group_id": group_id, "response_timestamp": self._ts()}
        return OutgoingMessage(envelope=env, payload=self._wrap(MessageType.REQUEST_ASSIGNMENT_TABLE, f"req-{season_id}", inner), body_text="Assignment table request")

    def build_extension_request(self, correlation_id: str, reason: str | None = None, requested_extension: str | None = None) -> OutgoingMessage:
        msg_id = f"ext-req-{uuid.uuid4().hex[:12]}"
        env = Envelope(protocol_version=PROTOCOL_VERSION, sender_role=UserRole.PLAYER, sender_email=self._config.gmail.account,
                       recipient_email=self._config.get("league.manager_email"), transaction_id=msg_id, message_type=MessageType.EXTENSION_REQUEST)
        inner = {"correlation_id": correlation_id}
        if reason: inner["reason"] = reason
        if requested_extension: inner["requested_extension"] = requested_extension
        return OutgoingMessage(envelope=env, payload=self._wrap(MessageType.EXTENSION_REQUEST, msg_id, inner), body_text="Extension request")
