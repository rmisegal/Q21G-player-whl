"""Database manager for schema initialization and management."""
from sqlalchemy import text
from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.shared.logging.logger import get_logger

SCHEMA_VERSION = "1.5.0"
INIT_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS player_states (id SERIAL PRIMARY KEY, player_email VARCHAR(255) NOT NULL UNIQUE,
    player_name VARCHAR(255) NOT NULL DEFAULT '', current_state VARCHAR(50) NOT NULL DEFAULT 'INIT_START_STATE',
    current_game_id VARCHAR(100), current_book VARCHAR(255), current_description TEXT, current_domain VARCHAR(255),
    current_league_id VARCHAR(100), current_season_id VARCHAR(100), current_round_id VARCHAR(100),
    registration_id VARCHAR(100), registered_at TIMESTAMP, last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_player_states_email ON player_states(player_email);
CREATE TABLE IF NOT EXISTS game_sessions (id SERIAL PRIMARY KEY, game_id VARCHAR(100) NOT NULL UNIQUE,
    player_email VARCHAR(255) NOT NULL, book_name VARCHAR(255) NOT NULL, description TEXT, domain VARCHAR(255),
    season_id VARCHAR(50), round_id VARCHAR(50), round_number INTEGER, game_number INTEGER,
    opponent_email VARCHAR(255), opponent_name VARCHAR(100), my_role VARCHAR(20), match_id VARCHAR(50) UNIQUE,
    referee_email VARCHAR(255), invitation_status VARCHAR(20) DEFAULT 'PENDING', invitation_deadline TIMESTAMP,
    invitation_received_at TIMESTAMP, started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, ended_at TIMESTAMP,
    is_completed BOOLEAN DEFAULT FALSE, is_abandoned BOOLEAN DEFAULT FALSE, result_correct BOOLEAN, result_score DECIMAL(5,2));
CREATE INDEX IF NOT EXISTS idx_gs_gid ON game_sessions(game_id); CREATE INDEX IF NOT EXISTS idx_gs_pe ON game_sessions(player_email);
CREATE INDEX IF NOT EXISTS idx_gs_sid ON game_sessions(season_id); CREATE INDEX IF NOT EXISTS idx_gs_mid ON game_sessions(match_id);
CREATE TABLE IF NOT EXISTS questions (id SERIAL PRIMARY KEY, game_id VARCHAR(100) NOT NULL REFERENCES game_sessions(game_id),
    question_number INTEGER NOT NULL, question_text TEXT NOT NULL, options JSONB, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    answer_received VARCHAR(20), answer_received_at TIMESTAMP, UNIQUE(game_id, question_number));
CREATE TABLE IF NOT EXISTS answers (id SERIAL PRIMARY KEY, game_id VARCHAR(100) NOT NULL REFERENCES game_sessions(game_id),
    question_number INTEGER NOT NULL, selected_option VARCHAR(10) NOT NULL, received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE(game_id, question_number));
CREATE TABLE IF NOT EXISTS guesses (id SERIAL PRIMARY KEY, game_id VARCHAR(100) NOT NULL UNIQUE REFERENCES game_sessions(game_id),
    opening_sentence TEXT NOT NULL, sentence_justification TEXT, associative_word VARCHAR(100), word_justification TEXT,
    confidence DECIMAL(5,2), strategy_used VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS message_logs (id SERIAL PRIMARY KEY, gmail_id VARCHAR(100) NOT NULL UNIQUE, thread_id VARCHAR(100),
    direction VARCHAR(10) NOT NULL, message_type VARCHAR(100) NOT NULL, transaction_id VARCHAR(100),
    sender_email VARCHAR(255) NOT NULL, recipient_email VARCHAR(255) NOT NULL, subject TEXT, payload JSONB,
    game_id VARCHAR(100), league_id VARCHAR(100), round_id VARCHAR(100), processed BOOLEAN DEFAULT FALSE,
    error_message TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, processed_at TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_ml_gid ON message_logs(gmail_id); CREATE INDEX IF NOT EXISTS idx_ml_tid ON message_logs(thread_id);
CREATE INDEX IF NOT EXISTS idx_ml_mt ON message_logs(message_type); CREATE INDEX IF NOT EXISTS idx_ml_txid ON message_logs(transaction_id);
CREATE TABLE IF NOT EXISTS attachments (id SERIAL PRIMARY KEY, internal_filename VARCHAR(255) NOT NULL UNIQUE,
    original_filename VARCHAR(255) NOT NULL, message_id VARCHAR(100) NOT NULL, mime_type VARCHAR(100),
    size_bytes INTEGER DEFAULT 0, checksum VARCHAR(64), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_att_int ON attachments(internal_filename); CREATE INDEX IF NOT EXISTS idx_att_msg ON attachments(message_id);
CREATE TABLE IF NOT EXISTS schema_version (version VARCHAR(20) PRIMARY KEY, applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS broadcasts_received (id SERIAL PRIMARY KEY, broadcast_id VARCHAR(100) NOT NULL UNIQUE,
    message_type VARCHAR(100) NOT NULL, league_id VARCHAR(100), round_id VARCHAR(100), payload JSONB, message_text VARCHAR(500),
    response_required BOOLEAN DEFAULT FALSE, response_sent BOOLEAN DEFAULT FALSE, response_txid VARCHAR(100),
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, responded_at TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_br_bid ON broadcasts_received(broadcast_id); CREATE INDEX IF NOT EXISTS idx_br_mt ON broadcasts_received(message_type);
CREATE TABLE IF NOT EXISTS pause_state (id SERIAL PRIMARY KEY, broadcast_id VARCHAR(100) NOT NULL, previous_state VARCHAR(50) NOT NULL,
    previous_match_id VARCHAR(100), saved_context JSONB, paused_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, resumed_at TIMESTAMP, resume_broadcast_id VARCHAR(100));
CREATE TABLE IF NOT EXISTS state_transitions (id SERIAL PRIMARY KEY, player_email VARCHAR(255) NOT NULL, from_state VARCHAR(50) NOT NULL,
    to_state VARCHAR(50) NOT NULL, event VARCHAR(50) NOT NULL, transition_metadata JSONB, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_st_pe ON state_transitions(player_email); CREATE INDEX IF NOT EXISTS idx_st_ev ON state_transitions(event);
CREATE TABLE IF NOT EXISTS message_correlations (id SERIAL PRIMARY KEY, request_type VARCHAR(100) NOT NULL, request_id VARCHAR(100) NOT NULL,
    request_gmail_id VARCHAR(100), response_type VARCHAR(100), response_id VARCHAR(100), response_gmail_id VARCHAR(100), correlated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE INDEX IF NOT EXISTS idx_mc_req ON message_correlations(request_id); CREATE INDEX IF NOT EXISTS idx_mc_res ON message_correlations(response_id);
CREATE TABLE IF NOT EXISTS error_logs (id SERIAL PRIMARY KEY, error_type VARCHAR(50) NOT NULL, error_code VARCHAR(50),
    error_message TEXT NOT NULL, context JSONB, stack_trace TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, resolved_at TIMESTAMP, resolution_notes TEXT);
CREATE TABLE IF NOT EXISTS season_registrations (id SERIAL PRIMARY KEY, season_id VARCHAR(50) NOT NULL UNIQUE, league_id VARCHAR(50),
    season_name VARCHAR(100), registration_status VARCHAR(20) DEFAULT 'PENDING', registered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, confirmed_at TIMESTAMP, rejection_reason VARCHAR(255));
CREATE TABLE IF NOT EXISTS my_assignments (id SERIAL PRIMARY KEY, season_id VARCHAR(50) NOT NULL, round_number INTEGER NOT NULL, game_number INTEGER NOT NULL,
    role VARCHAR(20) NOT NULL, my_role VARCHAR(10), opponent_group_id VARCHAR(100), referee_group_id VARCHAR(100),
    game_id VARCHAR(100), match_id VARCHAR(50), assignment_status VARCHAR(20) DEFAULT 'PENDING',
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, started_at TIMESTAMP, completed_at TIMESTAMP, UNIQUE(season_id, round_number, game_number));
CREATE TABLE IF NOT EXISTS season_standings (id SERIAL PRIMARY KEY, season_id VARCHAR(50) NOT NULL, round_number INTEGER NOT NULL, group_id VARCHAR(100) NOT NULL,
    total_score DECIMAL(10,2) DEFAULT 0, games_played INTEGER DEFAULT 0, games_won INTEGER DEFAULT 0, rank INTEGER,
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, UNIQUE(season_id, round_number, group_id));
CREATE TABLE IF NOT EXISTS game_state (match_id VARCHAR(50) PRIMARY KEY, player_email VARCHAR(255), game_id VARCHAR(100),
    current_phase VARCHAR(30) NOT NULL DEFAULT 'AWAITING_WARMUP', book_name VARCHAR(255), book_description TEXT, associative_domain VARCHAR(50),
    warmup_question TEXT, warmup_answer TEXT, warmup_deadline TIMESTAMP, warmup_retry_count INTEGER DEFAULT 0,
    questions_deadline TIMESTAMP, guess_deadline TIMESTAMP, player_role VARCHAR(20), questions_required INTEGER, time_limit_seconds INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS game_results (id SERIAL PRIMARY KEY, match_id VARCHAR(50) NOT NULL UNIQUE, game_id VARCHAR(100), season_id VARCHAR(50),
    total_score DECIMAL(5,2) NOT NULL, opening_sentence_score DECIMAL(5,2), sentence_justification_score DECIMAL(5,2),
    associative_word_score DECIMAL(5,2), word_justification_score DECIMAL(5,2), opening_sentence_feedback TEXT, word_feedback TEXT,
    actual_opening_sentence TEXT, actual_associative_word VARCHAR(100), received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS game_invitations (id SERIAL PRIMARY KEY, match_id VARCHAR(50) NOT NULL UNIQUE, player_email VARCHAR(255) NOT NULL,
    referee_email VARCHAR(255) NOT NULL, opponent_email VARCHAR(255), book_name VARCHAR(255), deadline TIMESTAMP,
    status VARCHAR(20) DEFAULT 'PENDING', received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, responded_at TIMESTAMP);"""


class DatabaseManager:
    def __init__(self, pool: ConnectionPool | None = None) -> None:
        self._pool, self._logger = pool or ConnectionPool(), get_logger("database.manager")

    def init_schema(self) -> None:
        with self._pool.session() as session:
            session.execute(text(INIT_SCHEMA_SQL))
            session.execute(text("INSERT INTO schema_version (version) VALUES (:v) ON CONFLICT DO NOTHING"), {"v": SCHEMA_VERSION})
        self._logger.info(f"Schema initialized (version {SCHEMA_VERSION})")

    def get_schema_version(self) -> str | None:
        try:
            with self._pool.session() as session:
                row = session.execute(text("SELECT version FROM schema_version ORDER BY applied_at DESC LIMIT 1")).fetchone()
                return row[0] if row else None
        except Exception: return None

    def table_exists(self, table_name: str) -> bool:
        with self._pool.session() as session:
            return session.execute(text("SELECT EXISTS(SELECT 1 FROM information_schema.tables WHERE table_name = :t)"), {"t": table_name}).scalar()

    def get_table_names(self) -> list[str]:
        with self._pool.session() as session:
            return [row[0] for row in session.execute(text("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")).fetchall()]

    def reset_schema(self) -> None:
        tables = ["game_invitations", "game_results", "game_state", "season_standings", "my_assignments", "season_registrations",
                  "error_logs", "message_correlations", "state_transitions", "pause_state", "broadcasts_received",
                  "attachments", "message_logs", "guesses", "answers", "questions", "game_sessions", "player_states", "schema_version"]
        with self._pool.session() as session:
            for t in tables: session.execute(text(f"DROP TABLE IF EXISTS {t} CASCADE"))
        self._logger.warning("Schema reset"); self.init_schema()
