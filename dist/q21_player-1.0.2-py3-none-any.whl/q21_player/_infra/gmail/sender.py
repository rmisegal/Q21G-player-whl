"""
Gmail sender for outgoing emails with attachments.
"""

import base64
import json
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any

from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.shared.config.constants import RETRY_BASE_DELAY_SEC, RETRY_MAX_ATTEMPTS, SEND_RATE_LIMIT_TIMEOUT_SEC
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.exceptions.gmail import GmailSendError
from q21_player._infra.shared.logging.logger import get_logger
from q21_player._infra.shared.threading.rate_limiter import GmailRateLimiter
from q21_player._infra.shared.utils.retry import retry_with_backoff


class GmailSender:
    """Sender for outgoing Gmail messages with JSON attachments."""

    def __init__(self, client: GmailClient) -> None:
        self._client = client
        self._config = Config()
        self._logger = get_logger("gmail.sender")
        self._rate_limiter = GmailRateLimiter()

    def create_message(
        self, to: str, subject: str, body: str = "",
        attachment: dict[str, Any] | None = None, attachment_name: str = "payload.json"
    ) -> dict[str, str]:
        """Create an email message with optional JSON attachment."""
        message = MIMEMultipart()
        message["to"] = to
        message["from"] = self._config.gmail.account
        message["subject"] = subject

        message.attach(MIMEText(body, "plain"))

        if attachment:
            json_data = json.dumps(attachment, indent=2, ensure_ascii=False)
            part = MIMEBase("application", "json")
            part.set_payload(json_data.encode("utf-8"))
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", f'attachment; filename="{attachment_name}"')
            message.attach(part)

        raw = base64.urlsafe_b64encode(message.as_bytes()).decode("utf-8")
        return {"raw": raw}

    def send(
        self, to: str, subject: str, body: str = "",
        attachment: dict[str, Any] | None = None, attachment_name: str = "payload.json"
    ) -> dict[str, Any]:
        """Send an email with optional JSON attachment."""
        if not self._rate_limiter.acquire(timeout=SEND_RATE_LIMIT_TIMEOUT_SEC):
            raise GmailSendError("Rate limit exceeded", recipient=to)

        message = self.create_message(to, subject, body, attachment, attachment_name)
        return self._send_with_retry(to, message)

    @retry_with_backoff(max_retries=RETRY_MAX_ATTEMPTS, base_delay=RETRY_BASE_DELAY_SEC)
    def _send_with_retry(self, to: str, message: dict) -> dict[str, Any]:
        """Send the prepared message with retry logic."""
        try:
            result = self._client.service.users().messages().send(
                userId="me", body=message
            ).execute()
            self._logger.info(f"Email sent to {to}, message_id: {result.get('id')}")
            return result
        except Exception as e:
            raise GmailSendError(f"Failed to send email: {e}", recipient=to) from e

    def send_reply(
        self, original_message_id: str, thread_id: str,
        to: str, subject: str, body: str = "",
        attachment: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Send a reply to an existing thread."""
        if not self._rate_limiter.acquire(timeout=SEND_RATE_LIMIT_TIMEOUT_SEC):
            raise GmailSendError("Rate limit exceeded", recipient=to)

        try:
            message = self.create_message(to, subject, body, attachment)
            message["threadId"] = thread_id
            result = self._client.service.users().messages().send(
                userId="me", body=message
            ).execute()
            self._logger.info(f"Reply sent to {to}, thread_id: {thread_id}")
            return result
        except Exception as e:
            raise GmailSendError(f"Failed to send reply: {e}", recipient=to) from e

    def test_connectivity(self, test_recipient: str | None = None) -> bool:
        """Test email sending capability."""
        try:
            profile = self._client.get_profile()
            self._logger.info(f"Connectivity test passed. Account: {profile.get('emailAddress')}")
            return True
        except Exception as e:
            self._logger.error(f"Connectivity test failed: {e}")
            return False
