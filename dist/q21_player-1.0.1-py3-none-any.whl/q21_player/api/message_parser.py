"""
Email message parser for Q21 protocol.

Extracts headers and JSON attachments from Gmail API messages.
"""

import base64
import json


class MessageParseError(Exception):
    """Raised when message parsing fails."""
    pass


def parse_email_message(raw_message: dict, fetch_attachment: callable) -> dict | None:
    """
    Parse a raw Gmail message.

    Args:
        raw_message: Raw message from Gmail API
        fetch_attachment: Callback to fetch attachment data by ID

    Returns:
        Parsed message dict with id, subject, from, payload
    """
    msg_id = raw_message.get("id", "")
    payload_data = raw_message.get("payload", {})
    headers = payload_data.get("headers", [])

    subject, from_addr = _extract_headers(headers)
    json_payload = _extract_json_attachment(payload_data, msg_id, fetch_attachment)

    return {
        "id": msg_id,
        "subject": subject,
        "from": from_addr,
        "payload": json_payload,
    }


def _extract_headers(headers: list) -> tuple[str, str]:
    """Extract subject and from address from headers."""
    subject = ""
    from_addr = ""
    for header in headers:
        if header["name"] == "Subject":
            subject = header["value"]
        elif header["name"] == "From":
            from_addr = header["value"]
    return subject, from_addr


def _extract_json_attachment(
    payload_data: dict,
    msg_id: str,
    fetch_attachment: callable,
) -> dict | None:
    """Extract JSON attachment from message parts."""
    if "parts" not in payload_data:
        return None

    for part in payload_data["parts"]:
        if not part.get("filename", "").endswith(".json"):
            continue

        att_id = part.get("body", {}).get("attachmentId")
        if not att_id:
            continue

        try:
            att_data = fetch_attachment(msg_id, att_id)
            decoded = base64.urlsafe_b64decode(att_data).decode()
            return json.loads(decoded)
        except Exception:
            pass

    return None
