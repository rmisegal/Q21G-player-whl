"""
Strategy engine for GmailAsPlayer.

Provides pluggable game strategies via SDK PlayerAI callbacks.
"""

from q21_player._infra.strategy.base_strategy import IGameStrategy, StrategyResult
from q21_player._infra.strategy.sdk_strategy import SDKStrategy
from q21_player._infra.strategy.strategy_factory import get_strategy

__all__ = [
    "IGameStrategy",
    "StrategyResult",
    "SDKStrategy",
    "get_strategy",
]
