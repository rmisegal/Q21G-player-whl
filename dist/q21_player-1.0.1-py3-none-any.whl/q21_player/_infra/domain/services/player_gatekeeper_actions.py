"""Gatekeeper action types for player message evaluation."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ActionType(Enum):
    """Types of actions the gatekeeper can return."""
    PROCESS_NORMAL = "process_normal"
    STORE_ASSIGNMENT = "store_assignment"
    LOG_INCOMING = "log_incoming"
    ADVANCE_ROUND = "advance_round"
    SKIP = "skip"
    REJECT = "reject"  # Unauthorized sender


@dataclass
class GatekeeperAction:
    """Result of gatekeeper message evaluation."""
    action_type: ActionType
    params: dict[str, Any]
    should_process: bool
    log_entry: dict[str, Any] | None = None
