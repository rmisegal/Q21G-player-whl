"""
Callback output schemas for validation.

Each schema defines:
- required: List of required field names
- types: Dict mapping field name to expected type
- constraints: Dict mapping field name to constraint rules
"""

# Schema for get_warmup_answer callback
WARMUP_SCHEMA = {
    "required": ["answer"],
    "types": {
        "answer": str,
    },
    "constraints": {},
}

# Schema for get_questions callback
QUESTIONS_SCHEMA = {
    "required": ["questions"],
    "types": {
        "questions": list,
    },
    "constraints": {
        "questions": {
            "length": 20,
            "item_required": ["question_number", "question_text", "options"],
            "item_types": {
                "question_number": int,
                "question_text": str,
                "options": dict,
            },
            "options_required_keys": ["A", "B", "C", "D"],
        },
    },
}

# Schema for get_guess callback
GUESS_SCHEMA = {
    "required": [
        "opening_sentence",
        "sentence_justification",
        "associative_word",
        "word_justification",
        "confidence",
    ],
    "types": {
        "opening_sentence": str,
        "sentence_justification": str,
        "associative_word": str,
        "word_justification": str,
        "confidence": (int, float),
    },
    "constraints": {
        "sentence_justification": {"min_words": 30, "max_words": 50},
        "word_justification": {"min_words": 20, "max_words": 30},
        "confidence": {"min": 0.0, "max": 1.0},
    },
}

# Schema for on_score_received callback (no return required)
SCORE_NOTIFICATION_SCHEMA = {
    "required": [],
    "types": {},
    "constraints": {},
}

# Registry mapping callback names to schemas
CALLBACK_SCHEMAS = {
    "warmup_answer": WARMUP_SCHEMA,
    "questions": QUESTIONS_SCHEMA,
    "guess": GUESS_SCHEMA,
    "score_notification": SCORE_NOTIFICATION_SCHEMA,
}
