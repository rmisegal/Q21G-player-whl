"""Strategy service for GmailAsPlayer - strategy selection and execution."""


from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.shared.logging.logger import get_logger
from q21_player._infra.strategy.base_strategy import IGameStrategy, StrategyResult
from q21_player._infra.strategy.strategy_factory import get_strategy


class StrategyService:
    """Service for managing and executing game strategies.

    Uses the SDK-based strategy from strategy_factory. Students implement
    PlayerAI callbacks, and this service wraps them via SDKStrategy.
    """

    def __init__(self):
        self._logger = get_logger("strategy_service")
        self._strategy: IGameStrategy = get_strategy()

    def get_strategy(self, name: str = None) -> IGameStrategy:
        """Get the configured strategy (SDK-based)."""
        return self._strategy

    def get_default_strategy(self) -> IGameStrategy:
        """Get configured default strategy."""
        return self._strategy

    def generate_questions(
        self, context: GameContext, strategy_name: str | None = None
    ) -> StrategyResult:
        """Generate questions using SDK strategy."""
        self._logger.info(f"Generating questions with {self._strategy.name}")
        try:
            result = self._strategy.generate_questions(context)
            if result.success:
                self._logger.info("Question generation succeeded")
            else:
                self._logger.warning(f"Question generation failed: {result.error}")
            return result
        except Exception as e:
            self._logger.error(f"Question generation exception: {e}")
            return StrategyResult(success=False, error=str(e))

    def formulate_guess(
        self, context: GameContext, strategy_name: str | None = None
    ) -> StrategyResult:
        """Formulate guess using SDK strategy."""
        self._logger.info(f"Formulating guess with {self._strategy.name}")
        try:
            result = self._strategy.formulate_guess(context)
            if result.success:
                self._logger.info("Guess formulation succeeded")
            else:
                self._logger.warning(f"Guess formulation failed: {result.error}")
            return result
        except Exception as e:
            self._logger.error(f"Guess formulation exception: {e}")
            return StrategyResult(success=False, error=str(e))

    @property
    def available_strategies(self) -> list[str]:
        """Get list of available strategy names."""
        return [self._strategy.name]
