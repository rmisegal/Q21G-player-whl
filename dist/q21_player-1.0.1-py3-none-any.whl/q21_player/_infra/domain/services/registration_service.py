"""Registration service for league operations."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from q21_player._infra.domain.models.envelope import Envelope
from q21_player._infra.domain.models.messages import OutgoingMessage
from q21_player._infra.shared.config.constants import PROTOCOL_VERSION, MessageType, UserRole
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.factories.envelope_factory import EnvelopeFactory
from q21_player._infra.shared.logging.logger import get_logger
from q21_player._infra.shared.utils.helpers import generate_transaction_id

if TYPE_CHECKING:
    from q21_player._infra.repository.state_repository import StateRepository


@dataclass
class RegistrationResult:
    success: bool
    transaction_id: str | None = None
    error: str | None = None
    registered_at: datetime | None = None


class RegistrationService:
    def __init__(self, player_email: str, player_name: str, repository: StateRepository | None = None):
        self._logger = get_logger("registration_service")
        self._config = Config()
        self._envelope_factory = EnvelopeFactory(self._config)
        self._player_email = player_email
        self._player_name = player_name
        self._repository = repository
        self._registration_id: str | None = None
        self._registered_at: datetime | None = None
        if self._repository:
            reg_id, reg_at = self._repository.get_registration(player_email)
            if reg_id:
                self._registration_id, self._registered_at = reg_id, reg_at
                self._logger.info(f"Loaded existing registration: {reg_id}")

    @property
    def is_registered(self) -> bool: return self._registration_id is not None
    @property
    def registration_id(self) -> str | None: return self._registration_id

    def _create_envelope(self, msg_type: MessageType, txn_id: str):
        return self._envelope_factory.create(msg_type, txn_id=txn_id)

    def _create_message(self, envelope: Envelope, payload: dict) -> OutgoingMessage:
        return OutgoingMessage(
            to_email=self._config.get("league.manager_email", ""),
            subject=envelope.to_subject_line(), envelope=envelope, payload=payload,
        )

    def create_registration_request(self) -> OutgoingMessage:
        txn_id = generate_transaction_id("reg-player")
        msg_type = MessageType.LEAGUE_REGISTER_REQUEST
        user_id = self._config.get("player.user_id", "")
        envelope = Envelope(
            protocol_version=PROTOCOL_VERSION, sender_role=UserRole.PLAYER.value,
            sender_email=self._player_email,
            recipient_email=self._config.get("league.manager_email", ""),
            transaction_id=txn_id, message_type=msg_type,
        )
        # Flat payload per UNIFIED_PROTOCOL.md Section 5.1 (no nested player_meta)
        payload = {
            "user_id": user_id,
            "display_name": self._player_name,
            "game_types": ["Q21"],
            "contact_email": self._player_email,
        }
        return OutgoingMessage(envelope=envelope, payload=payload, attachment_name=f"{msg_type.value}.json")

    def process_registration_response(self, txn_id: str, payload: dict) -> RegistrationResult:
        if payload.get("status") == "accepted":
            self._registration_id, self._registered_at = txn_id, datetime.now(UTC)
            if self._repository:
                self._repository.save_registration(self._player_email, txn_id, self._registered_at)
            self._logger.info(f"Registration accepted: {txn_id}")
            return RegistrationResult(True, txn_id, registered_at=self._registered_at)
        error = payload.get("error", "Registration rejected")
        self._logger.warning(f"Registration failed: {error}")
        return RegistrationResult(success=False, error=error)

    def create_heartbeat_message(self) -> OutgoingMessage | None:
        if not self._registration_id:
            return None
        envelope = self._create_envelope(MessageType.HEARTBEAT, self._registration_id)
        payload = {"player_email": self._player_email, "status": "active",
                   "timestamp": datetime.now(UTC).isoformat()}
        return self._create_message(envelope, payload)

    def create_unregister_request(self) -> OutgoingMessage | None:
        if not self._registration_id:
            return None
        envelope = self._create_envelope(MessageType.UNREGISTER, self._registration_id)
        payload = {"player_email": self._player_email, "reason": "player_shutdown",
                   "timestamp": datetime.now(UTC).isoformat()}
        if self._repository:
            self._repository.clear_registration(self._player_email)
        self._registration_id, self._registered_at = None, None
        return self._create_message(envelope, payload)

    def reset(self) -> None:
        if self._repository:
            self._repository.clear_registration(self._player_email)
        self._registration_id, self._registered_at = None, None
        self._logger.info("Registration state reset")
