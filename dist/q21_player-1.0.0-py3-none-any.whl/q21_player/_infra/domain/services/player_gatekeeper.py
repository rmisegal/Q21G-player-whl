"""Player Gatekeeper - evaluates incoming messages before processing."""

from typing import Any

from q21_player._infra.domain.services.player_gatekeeper_actions import ActionType, GatekeeperAction
from q21_player._infra.domain.services.player_gatekeeper_rules import DEFAULT_RULE, MESSAGE_RULES, PLAYER_ROLES, SenderType
from q21_player._infra.domain.services.sender_validator import SenderValidator
from q21_player._infra.repository.assignment_repository import AssignmentRepository
from q21_player._infra.shared.logging.logger import get_logger

logger = get_logger("player_gatekeeper")


class PlayerGatekeeper:
    """Intercepts all incoming messages and determines actions. Tracks current round."""

    def __init__(self, assignment_repo: AssignmentRepository, player_email: str, manager_emails: list[str] | None = None):
        self._assignment_repo = assignment_repo
        self._player_email = player_email
        self._sender_validator = SenderValidator(assignment_repo, manager_emails)
        self.current_season_id: str | None = None
        self.current_round: int = 0

    def evaluate(self, msg_type: str, payload: dict[str, Any], sender_email: str) -> GatekeeperAction:
        """Evaluate message and return action to execute."""
        normalized = msg_type.upper().replace("_", "")
        rule = MESSAGE_RULES.get(normalized, DEFAULT_RULE)
        action_type = rule["action"]
        should_process = rule.get("should_process", True)
        required_sender = rule.get("sender", SenderType.MANAGER)

        # Validate sender before processing
        if not self._sender_validator.validate(sender_email, required_sender, payload):
            logger.warning(f"REJECTED {msg_type} from unauthorized sender: {sender_email}")
            return GatekeeperAction(ActionType.REJECT, {"sender": sender_email, "msg_type": msg_type}, False)

        if action_type == ActionType.STORE_ASSIGNMENT:
            return self._handle_assignment_table(payload, should_process)
        if action_type == ActionType.ADVANCE_ROUND:
            return self._handle_round_results(payload, should_process)
        if action_type == ActionType.LOG_INCOMING:
            return self._handle_request_message(msg_type, payload, sender_email, should_process)
        return GatekeeperAction(ActionType.PROCESS_NORMAL, {}, should_process)

    def _handle_assignment_table(self, payload: dict, should_process: bool) -> GatekeeperAction:
        """Parse assignment table, store referee info, set current round."""
        inner = payload.get("payload", {})
        season_id = inner.get("season_id", "")
        round_number = inner.get("round_number", 0)
        all_assignments = inner.get("assignments", [])

        # Extract round from game_id (SSRRGGG) if round_number not provided
        if not round_number and all_assignments:
            round_number = self._extract_round_from_game_id(all_assignments[0].get("game_id", ""))

        # Update round tracking (both gatekeeper and sender validator)
        self.current_season_id = season_id
        self.current_round = round_number
        self._sender_validator.update_round(season_id, round_number)

        my_entries = [a for a in all_assignments
                      if a.get("email") == self._player_email or a.get("group_id") == self._player_email]
        enriched = self._enrich_with_referee(my_entries, all_assignments)

        logger.info(f"Assignment table: season={season_id}, round={round_number}, my_games={len(enriched)}")
        return GatekeeperAction(
            ActionType.STORE_ASSIGNMENT,
            {"season_id": season_id, "round_number": round_number, "assignments": enriched},
            should_process,
        )

    def _handle_round_results(self, payload: dict, should_process: bool) -> GatekeeperAction:
        """Handle end-of-round broadcast, advance to next round."""
        inner = payload.get("payload", {})
        completed_round = inner.get("round_number", self.current_round)
        self.current_round = completed_round + 1
        self._sender_validator.update_round(self.current_season_id, self.current_round)
        logger.info(f"Round {completed_round} completed, advancing to round {self.current_round}")
        return GatekeeperAction(
            ActionType.ADVANCE_ROUND,
            {"completed_round": completed_round, "new_round": self.current_round},
            should_process,
        )

    @staticmethod
    def _extract_round_from_game_id(game_id: str) -> int:
        """Extract round number from game_id format SSRRGGG."""
        try:
            return int(game_id[2:4]) if len(game_id) >= 4 else 0
        except (ValueError, IndexError):
            return 0

    @staticmethod
    def _extract_game_number_from_game_id(game_id: str) -> int | None:
        """Extract game number from game_id format SSRRGGG."""
        try:
            return int(game_id[4:7]) if len(game_id) >= 7 else None
        except (ValueError, IndexError):
            return None

    def _is_me(self, entry: dict) -> bool:
        """Check if an assignment entry belongs to this player."""
        return entry.get("email") == self._player_email or entry.get("group_id") == self._player_email

    def _enrich_with_referee(self, mine: list[dict], all_asgn: list[dict]) -> list[dict]:
        """Find referee and opponent for each of my games."""
        result = []
        for entry in mine:
            game_id = entry.get("game_id", "")
            enriched = dict(entry)
            enriched["referee_group_id"] = None
            enriched["opponent_group_id"] = None
            role = entry.get("role", "")
            enriched["my_role"] = role if role.upper() in [r.upper() for r in PLAYER_ROLES] else None
            # Extract round_number and game_number from game_id (SSRRGGG format)
            if not enriched.get("round_number"):
                enriched["round_number"] = self._extract_round_from_game_id(game_id)
            if not enriched.get("game_number"):
                enriched["game_number"] = self._extract_game_number_from_game_id(game_id)
            for other in all_asgn:
                if other.get("game_id") != game_id or self._is_me(other):
                    continue
                other_role = other.get("role", "").upper()
                if other_role == "REFEREE":
                    enriched["referee_group_id"] = other.get("email") or other.get("group_id")
                elif other_role in [r.upper() for r in PLAYER_ROLES]:
                    enriched["opponent_group_id"] = other.get("email") or other.get("group_id")
            result.append(enriched)
        return result

    def _handle_request_message(
        self, msg_type: str, payload: dict, sender_email: str, should_process: bool
    ) -> GatekeeperAction:
        """Log incoming request that requires a response."""
        match_id = payload.get("payload", {}).get("match_id", "")
        log_entry = {"msg_type": msg_type, "sender": sender_email, "match_id": match_id}
        logger.info(f"Request requiring response: {msg_type} from {sender_email}, match={match_id}")
        return GatekeeperAction(ActionType.LOG_INCOMING, {"sender_email": sender_email}, should_process, log_entry)

    def get_current_referee(self) -> str | None:
        """Get referee email for the current tracked round."""
        if not self.current_season_id or not self.current_round:
            return None
        return self._assignment_repo.get_referee_for_round(self.current_season_id, self.current_round)

    def get_referee_email(self, season_id: str, round_number: int) -> str | None:
        """Look up referee email for a specific round from stored assignments."""
        return self._assignment_repo.get_referee_for_round(season_id, round_number)
