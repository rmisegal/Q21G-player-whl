"""
Repository/persistence exceptions for GmailAsPlayer.

Covers database and data access errors.
"""

from typing import Any

from q21_player._infra.shared.exceptions.base import PlayerError


class RepositoryError(PlayerError):
    """Base exception for repository/persistence errors."""

    def __init__(
        self,
        message: str,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, code or "REPOSITORY_ERROR", details)


class RecordNotFoundError(RepositoryError):
    """Requested record not found in database."""

    def __init__(
        self,
        entity_type: str,
        entity_id: Any,
        message: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        message = message or f"{entity_type} with id '{entity_id}' not found"
        details = details or {}
        details["entity_type"] = entity_type
        details["entity_id"] = str(entity_id)
        super().__init__(message, "RECORD_NOT_FOUND", details)


class DuplicateRecordError(RepositoryError):
    """Attempted to create a duplicate record."""

    def __init__(
        self,
        entity_type: str,
        key_field: str,
        key_value: Any,
        message: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        message = message or f"{entity_type} with {key_field}='{key_value}' already exists"
        details = details or {}
        details["entity_type"] = entity_type
        details["key_field"] = key_field
        details["key_value"] = str(key_value)
        super().__init__(message, "DUPLICATE_RECORD", details)


class DatabaseConnectionError(RepositoryError):
    """Database connection error."""

    def __init__(
        self,
        message: str = "Failed to connect to database",
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, "DB_CONNECTION_ERROR", details)


class TransactionError(RepositoryError):
    """Database transaction error."""

    def __init__(
        self,
        message: str = "Transaction failed",
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, "TRANSACTION_ERROR", details)
