"""Pause state repository for tracking agent pause/resume context."""

from datetime import UTC, datetime

from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import PauseStateModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class PauseStateRepository(BaseRepository[PauseStateModel]):
    """Repository for pause state operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(PauseStateModel, pool)

    def save_pause(
        self,
        broadcast_id: str,
        previous_state: str,
        previous_match_id: str | None = None,
        saved_context: dict | None = None,
    ) -> PauseStateModel:
        """Save pause state when agent is paused."""
        model = PauseStateModel(
            broadcast_id=broadcast_id,
            previous_state=previous_state,
            previous_match_id=previous_match_id,
            saved_context=saved_context,
        )
        self._logger.info(f"Saving pause state from {previous_state}")
        return self.create(model)

    def get_active_pause(self) -> PauseStateModel | None:
        """Get the current active pause (not yet resumed)."""
        session = self._get_session()
        try:
            return (session.query(PauseStateModel)
                    .filter(PauseStateModel.resumed_at.is_(None))
                    .order_by(PauseStateModel.paused_at.desc())
                    .first())
        except SQLAlchemyError as e:
            self._logger.error(f"Get active pause failed: {e}")
            raise RepositoryError(f"Failed to get active pause: {e}") from e

    def mark_resumed(
        self, broadcast_id: str, resume_broadcast_id: str
    ) -> bool:
        """Mark a pause as resumed."""
        session = self._get_session()
        try:
            model = (session.query(PauseStateModel)
                     .filter_by(broadcast_id=broadcast_id)
                     .filter(PauseStateModel.resumed_at.is_(None))
                     .first())
            if not model:
                return False
            model.resumed_at = datetime.now(UTC)
            model.resume_broadcast_id = resume_broadcast_id
            self.update(model)
            self._logger.info(f"Pause {broadcast_id} resumed by {resume_broadcast_id}")
            return True
        except SQLAlchemyError as e:
            self._logger.error(f"Mark resumed failed: {e}")
            raise RepositoryError(f"Failed to mark pause resumed: {e}") from e

    def get_pause_history(self, limit: int = 50) -> list[PauseStateModel]:
        """Get pause history ordered by most recent."""
        session = self._get_session()
        try:
            return (session.query(PauseStateModel)
                    .order_by(PauseStateModel.paused_at.desc())
                    .limit(limit)
                    .all())
        except SQLAlchemyError as e:
            self._logger.error(f"Get pause history failed: {e}")
            raise RepositoryError(f"Failed to get pause history: {e}") from e

    def get_by_broadcast_id(self, broadcast_id: str) -> PauseStateModel | None:
        """Get pause state by broadcast ID."""
        session = self._get_session()
        try:
            return (session.query(PauseStateModel)
                    .filter_by(broadcast_id=broadcast_id)
                    .first())
        except SQLAlchemyError as e:
            self._logger.error(f"Get by broadcast_id failed: {e}")
            raise RepositoryError(f"Failed to get pause state: {e}") from e
