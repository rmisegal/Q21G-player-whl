"""
Path utilities for GmailAsPlayer.

Provides functions to locate project directories and files.
"""

from pathlib import Path


def get_project_root() -> Path:
    """
    Find the project root directory.

    Searches upward from the current file for pyproject.toml.

    Returns:
        Path to project root directory
    """
    current = Path(__file__).resolve()
    for parent in current.parents:
        if (parent / "pyproject.toml").exists():
            return parent
    return Path.cwd()


def get_data_folder(subfolder: str | None = None) -> Path:
    """
    Get the data folder path.

    Args:
        subfolder: Optional subfolder within data directory

    Returns:
        Path to data folder (creates if not exists)
    """
    data_path = get_project_root() / "data"
    if subfolder:
        data_path = data_path / subfolder
    data_path.mkdir(parents=True, exist_ok=True)
    return data_path


def get_logs_folder(subfolder: str | None = None) -> Path:
    """
    Get the logs folder path.

    Args:
        subfolder: Optional subfolder within logs directory

    Returns:
        Path to logs folder (creates if not exists)
    """
    logs_path = get_project_root() / "logs"
    if subfolder:
        logs_path = logs_path / subfolder
    logs_path.mkdir(parents=True, exist_ok=True)
    return logs_path


def get_config_folder() -> Path:
    """
    Get the config folder path.

    Returns:
        Path to config folder (js/)
    """
    return get_project_root() / "js"


def get_attachments_folder() -> Path:
    """
    Get the attachments folder path.

    Returns:
        Path to attachments folder (creates if not exists)
    """
    return get_data_folder("attachments")


def get_temp_folder() -> Path:
    """
    Get the temporary files folder path.

    Returns:
        Path to temp folder (creates if not exists)
    """
    temp_path = get_project_root() / "tmp"
    temp_path.mkdir(parents=True, exist_ok=True)
    return temp_path


def ensure_gitkeep(folder: Path) -> None:
    """
    Ensure a .gitkeep file exists in the folder.

    Args:
        folder: Path to folder
    """
    gitkeep = folder / ".gitkeep"
    if not gitkeep.exists():
        gitkeep.touch()
