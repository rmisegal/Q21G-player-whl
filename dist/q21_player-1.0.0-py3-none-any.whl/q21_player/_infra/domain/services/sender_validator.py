"""Sender validation for incoming messages."""

from q21_player._infra.domain.services.player_gatekeeper_rules import SenderType
from q21_player._infra.repository.assignment_repository import AssignmentRepository
from q21_player._infra.shared.logging.logger import get_logger

logger = get_logger("sender_validator")


class SenderValidator:
    """Validates that message senders are authorized for specific message types."""

    def __init__(
        self,
        assignment_repo: AssignmentRepository,
        manager_emails: list[str] | None = None,
    ):
        self._assignment_repo = assignment_repo
        self._manager_emails = [e.lower() for e in (manager_emails or [])]
        self._current_season_id: str | None = None
        self._current_round: int = 0

    def update_round(self, season_id: str | None, round_number: int) -> None:
        """Update current round tracking for referee validation."""
        self._current_season_id = season_id
        self._current_round = round_number
        logger.debug(f"Updated round tracking: season={season_id}, round={round_number}")

    def validate(self, sender_email: str, required_sender: str, payload: dict) -> bool:
        """
        Validate that sender is authorized for this message type.

        Args:
            sender_email: Email of the message sender
            required_sender: SenderType (REFEREE, MANAGER, ANY)
            payload: Message payload (for fallback referee extraction)

        Returns:
            True if sender is authorized, False otherwise
        """
        sender_lower = sender_email.lower()

        if required_sender == SenderType.ANY:
            return True

        if required_sender == SenderType.MANAGER:
            return self._validate_manager(sender_lower)

        if required_sender == SenderType.REFEREE:
            return self._validate_referee(sender_lower, payload)

        logger.warning(f"Unknown sender type: {required_sender}")
        return False

    def _validate_manager(self, sender_lower: str) -> bool:
        """Check if sender is a known league manager."""
        if sender_lower in self._manager_emails:
            return True
        logger.debug(f"Sender {sender_lower} not in manager list: {self._manager_emails}")
        return False

    def _validate_referee(self, sender_lower: str, payload: dict) -> bool:
        """
        Check if sender is the assigned referee for current round/game.

        Validation chain:
        1. Managers can send referee messages (fallback)
        2. Check assigned referee from database
        3. Check referee_email in payload (first-message case)
        """
        # Managers can always send referee-type messages
        if sender_lower in self._manager_emails:
            logger.debug(f"Manager {sender_lower} sending referee message - allowed")
            return True

        # Check assigned referee from database
        if self._current_season_id and self._current_round:
            assigned_referee = self._assignment_repo.get_referee_for_round(
                self._current_season_id, self._current_round
            )
            if assigned_referee and assigned_referee.lower() == sender_lower:
                logger.debug(f"Sender {sender_lower} is assigned referee for round {self._current_round}")
                return True

        # Fallback: check sender.email and sender.role in payload envelope
        sender_info = payload.get("sender", {})
        payload_sender_email = sender_info.get("email", "").lower()
        payload_sender_role = sender_info.get("role", "").upper()
        if payload_sender_email == sender_lower and payload_sender_role == "REFEREE":
            logger.debug(f"Sender {sender_lower} matches payload sender.email with role REFEREE")
            return True

        logger.warning(
            f"Referee validation failed: sender={sender_lower}, "
            f"season={self._current_season_id}, round={self._current_round}"
        )
        return False
