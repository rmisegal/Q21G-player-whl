"""
Pause context model for GmailAsPlayer.

Tracks state when agent is paused by League Manager.
"""

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

from q21_player._infra.shared.config.constants import PlayerState


class PauseContext(BaseModel):
    """Context saved when agent enters PAUSED state."""

    broadcast_id: str = Field(..., description="Broadcast ID that triggered pause")
    previous_state: PlayerState = Field(..., description="State before pause")
    previous_match_id: str | None = Field(None, description="Match ID if in game")
    saved_game_context: dict[str, Any] | None = Field(
        None,
        description="Saved game state for restoration"
    )
    paused_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When pause occurred"
    )
    pause_reason: str | None = Field(None, description="Reason for pause")

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for database storage."""
        return {
            "broadcast_id": self.broadcast_id,
            "previous_state": self.previous_state.value,
            "previous_match_id": self.previous_match_id,
            "saved_game_context": self.saved_game_context,
            "paused_at": self.paused_at.isoformat(),
            "pause_reason": self.pause_reason,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PauseContext":
        """Create from dictionary (database retrieval)."""
        return cls(
            broadcast_id=data["broadcast_id"],
            previous_state=PlayerState(data["previous_state"]),
            previous_match_id=data.get("previous_match_id"),
            saved_game_context=data.get("saved_game_context"),
            paused_at=datetime.fromisoformat(data["paused_at"]) if data.get("paused_at") else None,
            pause_reason=data.get("pause_reason"),
        )
