"""
Schema validation for callback outputs.

Validates callback return values against CALLBACK_SCHEMAS.
"""

from .schemas import CALLBACK_SCHEMAS


class ValidationError(Exception):
    """Raised when validation fails."""
    pass


class SchemaValidator:
    """Validates callback outputs against schemas."""

    def validate(self, data: dict, schema_name: str) -> list[str]:
        """
        Validate data against a named schema.

        Args:
            data: The callback output to validate
            schema_name: Name of schema (warmup_answer, questions, guess, etc.)

        Returns:
            List of error messages (empty if valid)

        Raises:
            ValidationError: If schema_name is unknown
        """
        if schema_name not in CALLBACK_SCHEMAS:
            raise ValidationError(f"Unknown schema: {schema_name}")

        schema = CALLBACK_SCHEMAS[schema_name]
        errors = []

        # Check required fields
        errors.extend(self._check_required(data, schema))

        # Check types
        errors.extend(self._check_types(data, schema))

        # Check constraints
        errors.extend(self._check_constraints(data, schema))

        return errors

    def _check_required(self, data: dict, schema: dict) -> list[str]:
        """Check all required fields are present."""
        errors = []
        for field in schema.get("required", []):
            if field not in data:
                errors.append(f"Missing required field: {field}")
        return errors

    def _check_types(self, data: dict, schema: dict) -> list[str]:
        """Check field types match expected types."""
        errors = []
        for field, expected_type in schema.get("types", {}).items():
            if field not in data:
                continue
            value = data[field]
            if not isinstance(value, expected_type):
                errors.append(
                    f"Field '{field}' has wrong type: "
                    f"expected {expected_type}, got {type(value).__name__}"
                )
        return errors

    def _check_constraints(self, data: dict, schema: dict) -> list[str]:
        """Check field constraints (word counts, ranges, lengths, etc.)."""
        errors = []
        constraints = schema.get("constraints", {})

        for field, rules in constraints.items():
            if field not in data:
                continue
            value = data[field]

            # Word count constraints
            if "min_words" in rules or "max_words" in rules:
                if isinstance(value, str):
                    word_count = len(value.split())
                    min_w = rules.get("min_words", 0)
                    max_w = rules.get("max_words", float("inf"))
                    if word_count < min_w:
                        errors.append(
                            f"Field '{field}' has {word_count} words, "
                            f"minimum is {min_w}"
                        )
                    if word_count > max_w:
                        errors.append(
                            f"Field '{field}' has {word_count} words, "
                            f"maximum is {max_w}"
                        )

            # Numeric range constraints
            if "min" in rules or "max" in rules:
                if isinstance(value, (int, float)):
                    min_v = rules.get("min", float("-inf"))
                    max_v = rules.get("max", float("inf"))
                    if value < min_v or value > max_v:
                        errors.append(
                            f"Field '{field}' value {value} out of range "
                            f"[{min_v}, {max_v}]"
                        )

            # Length constraints (for lists)
            if "length" in rules:
                if isinstance(value, list):
                    expected_len = rules["length"]
                    if len(value) != expected_len:
                        errors.append(
                            f"Field '{field}' has {len(value)} items, "
                            f"expected exactly {expected_len}"
                        )

            # Item validation for lists (questions)
            if "item_required" in rules and isinstance(value, list):
                for i, item in enumerate(value):
                    if not isinstance(item, dict):
                        errors.append(f"{field}[{i}] is not a dict")
                        continue
                    for req_field in rules["item_required"]:
                        if req_field not in item:
                            errors.append(
                                f"{field}[{i}] missing required field: {req_field}"
                            )

        return errors
