"""
Sensitive data filter for logging.

Masks authentication tokens, API keys, and passwords in log output.
"""

import logging
import re
from re import Pattern


class SensitiveFilter(logging.Filter):
    """
    Filter to mask sensitive data in log records.

    Automatically redacts:
    - OAuth tokens
    - API keys
    - Passwords
    - Email credentials
    """

    # Patterns to detect and mask sensitive data
    PATTERNS: list[Pattern[str]] = [
        # OAuth access tokens
        re.compile(r'(access_token["\s:=]+)["\']?([^"\'\s,}]+)', re.IGNORECASE),
        # Refresh tokens
        re.compile(r'(refresh_token["\s:=]+)["\']?([^"\'\s,}]+)', re.IGNORECASE),
        # API keys (various formats)
        re.compile(r'(api[_-]?key["\s:=]+)["\']?([^"\'\s,}]+)', re.IGNORECASE),
        re.compile(r'(sk-[a-zA-Z0-9]{20,})', re.IGNORECASE),  # OpenAI/Anthropic
        re.compile(r'(AIza[a-zA-Z0-9_-]{35})', re.IGNORECASE),  # Google
        # Passwords
        re.compile(r'(password["\s:=]+)["\']?([^"\'\s,}]+)', re.IGNORECASE),
        re.compile(r'(passwd["\s:=]+)["\']?([^"\'\s,}]+)', re.IGNORECASE),
        # Authorization headers
        re.compile(r'(Authorization["\s:=]+Bearer\s+)([^\s"\']+)', re.IGNORECASE),
        # Client secrets
        re.compile(r'(client[_-]?secret["\s:=]+)["\']?([^"\'\s,}]+)', re.IGNORECASE),
    ]

    MASK = "****REDACTED****"

    def filter(self, record: logging.LogRecord) -> bool:
        """
        Filter the log record, masking sensitive data.

        Args:
            record: The log record to filter

        Returns:
            True (always allows the record through after masking)
        """
        if record.msg:
            record.msg = self._mask_sensitive(str(record.msg))

        if record.args:
            record.args = tuple(
                self._mask_sensitive(str(arg)) if isinstance(arg, str) else arg
                for arg in record.args
            )

        return True

    def _mask_sensitive(self, text: str) -> str:
        """Mask sensitive data in text."""
        result = text
        for pattern in self.PATTERNS:
            # For patterns with groups, replace second group with mask
            result = pattern.sub(
                lambda m: f"{m.group(1)}{self.MASK}" if len(m.groups()) > 1 else self.MASK,
                result,
            )
        return result
