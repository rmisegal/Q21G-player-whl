"""
LLM client for Q21 Player SDK.

Supports Anthropic (Claude), OpenAI, and Google (Gemini) APIs.
"""

import os
from dataclasses import dataclass

from .json_utils import parse_json_response


@dataclass
class LLMResponse:
    """Response from LLM API call."""
    success: bool
    content: str = ""
    error: str | None = None


class LLMClient:
    """
    Multi-provider LLM client.

    Supports: anthropic, openai, gemini
    """

    DEFAULT_MODELS = {
        "anthropic": "claude-sonnet-4-20250514",
        "openai": "gpt-4o",
        "gemini": "gemini-1.5-flash",
        "mock": "mock-model",
    }

    def __init__(
        self,
        provider: str = "anthropic",
        model: str | None = None,
        api_key: str | None = None,
    ):
        """
        Initialize LLM client.

        Args:
            provider: LLM provider (anthropic, openai, gemini)
            model: Model name (uses default if not specified)
            api_key: API key (uses env var if not specified)
        """
        self.provider = provider.lower()
        self.model = model or self.DEFAULT_MODELS.get(self.provider, "")
        self._api_key = api_key
        self._client = None

    def _get_api_key(self) -> str | None:
        """Get API key from init or environment."""
        if self._api_key:
            return self._api_key
        key_map = {
            "anthropic": "ANTHROPIC_API_KEY",
            "openai": "OPENAI_API_KEY",
            "gemini": "GEMINI_API_KEY",
        }
        return os.getenv(key_map.get(self.provider, ""))

    def _init_client(self) -> bool:
        """Initialize the SDK client for the provider."""
        api_key = self._get_api_key()
        if not api_key:
            return False

        try:
            if self.provider == "anthropic":
                import anthropic
                self._client = anthropic.Anthropic(api_key=api_key)
            elif self.provider == "openai":
                import openai
                self._client = openai.OpenAI(api_key=api_key)
            elif self.provider == "gemini":
                import google.generativeai as genai
                genai.configure(api_key=api_key)
                self._client = genai.GenerativeModel(self.model)
            return True
        except Exception:
            return False

    def send(self, prompt: str, system_prompt: str | None = None) -> LLMResponse:
        """Send prompt to LLM and get response."""
        if self.provider == "mock":
            return self._send_mock(prompt, system_prompt)

        if self._client is None and not self._init_client():
            return LLMResponse(success=False, error="Failed to initialize LLM client")

        try:
            if self.provider == "anthropic":
                return self._send_anthropic(prompt, system_prompt)
            elif self.provider == "openai":
                return self._send_openai(prompt, system_prompt)
            elif self.provider == "gemini":
                return self._send_gemini(prompt, system_prompt)
            return LLMResponse(success=False, error=f"Unknown provider: {self.provider}")
        except Exception as e:
            return LLMResponse(success=False, error=str(e))

    def _send_anthropic(self, prompt: str, system_prompt: str | None) -> LLMResponse:
        """Send via Anthropic API."""
        kwargs = {
            "model": self.model,
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": prompt}],
        }
        if system_prompt:
            kwargs["system"] = system_prompt
        response = self._client.messages.create(**kwargs)
        content = response.content[0].text if response.content else ""
        return LLMResponse(success=True, content=content)

    def _send_openai(self, prompt: str, system_prompt: str | None) -> LLMResponse:
        """Send via OpenAI API."""
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        response = self._client.chat.completions.create(
            model=self.model, messages=messages, max_tokens=4096
        )
        content = response.choices[0].message.content if response.choices else ""
        return LLMResponse(success=True, content=content)

    def _send_gemini(self, prompt: str, system_prompt: str | None) -> LLMResponse:
        """Send via Gemini API."""
        full_prompt = f"{system_prompt}\n\n{prompt}" if system_prompt else prompt
        response = self._client.generate_content(full_prompt)
        return LLMResponse(success=True, content=response.text)

    def _send_mock(self, prompt: str, system_prompt: str | None) -> LLMResponse:
        """Return predictable mock responses for testing."""
        from .mock_provider import get_mock_response
        return LLMResponse(success=True, content=get_mock_response(prompt))

    def is_available(self) -> bool:
        """Check if LLM client can be initialized."""
        return self._get_api_key() is not None

    def parse_json(self, content: str) -> dict | None:
        """Extract and parse JSON from LLM response."""
        return parse_json_response(content)
