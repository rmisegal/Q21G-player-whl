"""
Utility functions for GmailAsPlayer.

Provides:
- Helper functions (ID generation, formatting)
- Validators (email, envelope, protocol)
- Path utilities (project root, data folders)
"""

from q21_player._infra.shared.utils.helpers import (
    format_subject_line,
    generate_transaction_id,
    generate_unique_key,
    parse_subject_line,
)
from q21_player._infra.shared.utils.paths import (
    get_config_folder,
    get_data_folder,
    get_logs_folder,
    get_project_root,
)
from q21_player._infra.shared.utils.validators import (
    validate_email,
    validate_envelope,
    validate_message_type,
    validate_question_batch,
)

__all__ = [
    "generate_transaction_id",
    "generate_unique_key",
    "format_subject_line",
    "parse_subject_line",
    "validate_email",
    "validate_envelope",
    "validate_message_type",
    "validate_question_batch",
    "get_project_root",
    "get_data_folder",
    "get_logs_folder",
    "get_config_folder",
]
