"""Extension response handler for processing deadline extension responses."""

from q21_player._infra.domain.services.error_logger import ErrorLogger
from q21_player._infra.shared.logging.logger import get_logger

logger = get_logger("extension_handler")


class ExtensionHandler:
    """Handles EXTENSION_RESPONSE messages from the league manager."""

    def process(self, payload: dict) -> dict:
        """
        Process an extension response payload.

        Args:
            payload: The message payload containing extension response data

        Returns:
            Dict with:
                - success: bool - True if extension was approved
                - status: str - "APPROVED" or "DENIED"
                - new_deadline: str | None - New deadline if approved
                - reason: str | None - Denial reason if denied
                - correlation_id: str | None - Original request correlation ID
        """
        inner_payload = payload.get("payload", {})
        status = inner_payload.get("status", "UNKNOWN")
        correlation_id = inner_payload.get("correlation_id")

        result = {
            "success": status == "APPROVED",
            "status": status,
            "correlation_id": correlation_id,
            "new_deadline": None,
            "reason": None,
        }

        if status == "APPROVED":
            new_deadline = inner_payload.get("new_deadline")
            result["new_deadline"] = new_deadline
            logger.info(f"Extension APPROVED - new deadline: {new_deadline}")
        elif status == "DENIED":
            reason = inner_payload.get("reason", "No reason provided")
            result["reason"] = reason
            logger.warning(f"Extension DENIED - reason: {reason}")
            ErrorLogger.log(
                error_type="EXTENSION_DENIED",
                message=f"Extension request denied: {reason}",
                context={"correlation_id": correlation_id, "reason": reason},
            )
        else:
            logger.error(f"Unknown extension status: {status}")
            ErrorLogger.log(
                error_type="EXTENSION_UNKNOWN_STATUS",
                message=f"Unknown extension status: {status}",
                context={"payload": inner_payload},
            )

        return result
