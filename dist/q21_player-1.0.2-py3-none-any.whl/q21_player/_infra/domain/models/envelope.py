"""Message envelope model for GmailAsPlayer - protocol envelope for messages."""
from __future__ import annotations
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Optional

import uuid

from pydantic import BaseModel, ConfigDict, Field, field_validator

from q21_player._infra.domain.models.message_context import MessageContext
from q21_player._infra.shared.config.constants import DEFAULT_SENDER_ROLE, PROTOCOL_VERSION, MessageType, UserRole

if TYPE_CHECKING:
    from q21_player._infra.shared.config.protocol_registry import ProtocolRegistry


class Envelope(BaseModel):
    """Protocol envelope for league.v2 and Q21G.v1 messages."""

    protocol_version: str = Field(default=PROTOCOL_VERSION)
    sender_role: str = Field(...)  # String to support any protocol role
    sender_email: str = Field(...)
    sender_logical_id: str | None = Field(default=None)
    recipient_email: str = Field(...)
    recipient_id: str | None = Field(default=None)  # Per UNIFIED_PROTOCOL.md Section 2.1
    transaction_id: str = Field(...)
    message_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    message_type: MessageType | str = Field(...)  # String for Q21G types
    raw_message_type: str | None = Field(default=None)  # Original wire format
    timestamp: datetime = Field(default_factory=lambda: datetime.now(UTC))
    reply_to_txid: str | None = Field(default=None)
    context: MessageContext | None = Field(default=None)
    authtoken: str | None = Field(default=None)

    model_config = ConfigDict(use_enum_values=True)

    @field_validator("sender_email", "recipient_email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        if "@" not in v or "." not in v:
            raise ValueError(f"Invalid email format: {v}")
        return v.strip().lower()

    def to_subject_line(self) -> str:
        """Convert to email subject line (5-part or 8-part with context)."""
        role = self.sender_role if isinstance(self.sender_role, str) else self.sender_role.value
        msg = self.message_type if isinstance(self.message_type, str) else self.message_type.value
        parts = [self.protocol_version, role, self.sender_email, self.transaction_id, msg]
        if self.context:
            parts.extend([self.context.league_id or "", self.context.round_id or "", self.context.game_id or ""])
        return "::".join(parts)

    @classmethod
    def from_subject_line(cls, subject: str, recipient: str) -> Optional["Envelope"]:
        """Parse envelope from email subject line (5-part or 8-part formats)."""
        try:
            parts = subject.split("::")
            if len(parts) < 5 or len(parts) > 8:
                return None
            protocol, role_str, sender, txid, msg_type = parts[:5]
            context = None
            if len(parts) == 8:
                lid, rid, gid = (parts[i] if parts[i] else None for i in [5, 6, 7])
                if any([lid, rid, gid]):
                    context = MessageContext(league_id=lid, round_id=rid, game_id=gid)
            return cls(
                protocol_version=protocol, sender_role=UserRole(role_str), sender_email=sender,
                recipient_email=recipient, transaction_id=txid, message_type=MessageType(msg_type), context=context,
            )
        except (ValueError, KeyError):
            return None

    def create_reply(self, reply_type: MessageType, new_sender: str, new_txid: str) -> "Envelope":
        """Create a reply envelope, preserving context."""
        return Envelope(
            protocol_version=self.protocol_version, sender_role=UserRole.PLAYER, sender_email=new_sender,
            recipient_email=self.sender_email, transaction_id=new_txid, message_type=reply_type,
            reply_to_txid=self.transaction_id, context=self.context,
        )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "protocol_version": self.protocol_version, "sender_role": self.sender_role,
            "sender_email": self.sender_email, "recipient_email": self.recipient_email,
            "transaction_id": self.transaction_id, "message_id": self.message_id,
            "message_type": self.message_type, "timestamp": self.timestamp.isoformat(),
            "reply_to_txid": self.reply_to_txid,
            "context": self.context.to_dict() if self.context else None,
        }

    def to_prd_dict(self, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        """Convert to PRD-compliant dictionary for JSON attachment (unified protocol snake_case)."""
        data: dict[str, Any] = {
            "protocol": self.protocol_version, "message_type": self.message_type,
            "message_id": self.message_id,
            "sender": {"email": self.sender_email, "role": self.sender_role, "logical_id": self.sender_logical_id},
            "timestamp": self.timestamp.isoformat(), "correlation_id": self.transaction_id,
            "recipient_id": self.recipient_id, "auth_token": self.authtoken,
        }
        if self.context:
            data["league_id"] = self.context.league_id
            data["season_id"] = self.context.season_id
            data["round_id"] = self.context.round_id
            data["game_id"] = self.context.game_id
        if payload is not None:
            data["payload"] = payload
        return data

    @classmethod
    def from_subject_line_with_registry(
        cls, subject: str, recipient: str, registry: ProtocolRegistry
    ) -> Optional["Envelope"]:
        """Parse envelope using protocol registry for multi-protocol support."""
        if not subject:
            return None
        protocol_id = registry.detect_protocol(subject)
        if not protocol_id:
            return None
        config = registry.get_protocol_config(protocol_id)
        if not config:
            return None
        parts = subject.split(config.subject_format.delimiter)
        if len(parts) < config.subject_format.min_parts or len(parts) > config.subject_format.max_parts:
            return None
        try:
            protocol, role_str, sender, txid, msg_type = parts[:5]
            context = None
            if len(parts) == 8 and config.subject_format.context_parts:
                lid, rid, gid = (parts[i] if parts[i] else None for i in [5, 6, 7])
                if any([lid, rid, gid]):
                    context = MessageContext(league_id=lid, round_id=rid, game_id=gid)
            return cls(
                protocol_version=protocol, sender_role=role_str, sender_email=sender,
                recipient_email=recipient, transaction_id=txid, message_type=msg_type,
                raw_message_type=msg_type, context=context,
            )
        except (ValueError, KeyError):
            return None

    def create_reply_raw(self, reply_type: str, new_sender: str, new_txid: str) -> "Envelope":
        """Create a reply envelope with raw message type string, preserving protocol."""
        return Envelope(
            protocol_version=self.protocol_version, sender_role=DEFAULT_SENDER_ROLE, sender_email=new_sender,
            recipient_email=self.sender_email, transaction_id=new_txid, message_type=reply_type,
            raw_message_type=reply_type, reply_to_txid=self.transaction_id, context=self.context,
        )
