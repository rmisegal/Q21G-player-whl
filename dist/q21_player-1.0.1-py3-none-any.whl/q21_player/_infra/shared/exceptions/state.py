"""
State machine exceptions for GmailAsPlayer.

Covers state transitions and timeout errors.
"""

from typing import Any

from q21_player._infra.shared.exceptions.base import PlayerError


class StateError(PlayerError):
    """Base exception for state machine errors."""

    def __init__(
        self,
        message: str,
        code: str | None = None,
        current_state: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        details = details or {}
        if current_state:
            details["current_state"] = current_state
        super().__init__(message, code or "STATE_ERROR", details)
        self.current_state = current_state


class InvalidTransitionError(StateError):
    """Invalid state transition attempted."""

    def __init__(
        self,
        from_state: str,
        to_state: str,
        event: str | None = None,
        message: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        message = message or f"Invalid transition from '{from_state}' to '{to_state}'"
        details = details or {}
        details["from_state"] = from_state
        details["to_state"] = to_state
        if event:
            details["event"] = event
        super().__init__(message, "INVALID_TRANSITION", from_state, details)
        self.from_state = from_state
        self.to_state = to_state
        self.event = event


class StateTimeoutError(StateError):
    """State timeout expired."""

    def __init__(
        self,
        state: str,
        timeout_seconds: float,
        message: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        message = message or f"Timeout in state '{state}' after {timeout_seconds}s"
        details = details or {}
        details["timeout_seconds"] = timeout_seconds
        super().__init__(message, "STATE_TIMEOUT", state, details)
        self.timeout_seconds = timeout_seconds


class StateNotFoundError(StateError):
    """Requested state does not exist."""

    def __init__(
        self,
        state_name: str,
        message: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        message = message or f"State '{state_name}' not found"
        super().__init__(message, "STATE_NOT_FOUND", None, details)
        self.state_name = state_name
