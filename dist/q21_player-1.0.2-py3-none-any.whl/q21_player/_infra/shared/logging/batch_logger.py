"""
Batch logger for tracking game progress.

Provides structured logging for game rounds, questions, and answers.
"""

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from q21_player._infra.shared.logging.logger import get_logger


@dataclass
class GameLogEntry:
    """Single game log entry."""

    timestamp: str
    event_type: str
    game_id: str
    data: dict[str, Any]


@dataclass
class BatchLogSession:
    """Tracks a single game session."""

    game_id: str
    started_at: str
    entries: list[GameLogEntry] = field(default_factory=list)
    ended_at: str | None = None


class BatchLogger:
    """
    Logger for tracking game progress in batches.

    Writes structured game events to game_history log files.
    """

    def __init__(self, game_id: str) -> None:
        self._logger = get_logger(f"game.{game_id}")
        self._game_id = game_id
        self._session = BatchLogSession(
            game_id=game_id,
            started_at=datetime.now(UTC).isoformat(),
        )

    def log_event(self, event_type: str, data: dict[str, Any]) -> None:
        """Log a game event."""
        entry = GameLogEntry(
            timestamp=datetime.now(UTC).isoformat(),
            event_type=event_type,
            game_id=self._game_id,
            data=data,
        )
        self._session.entries.append(entry)
        self._logger.info(f"[{event_type}] {json.dumps(data)}")

    def log_question_batch(self, questions: list[dict[str, Any]]) -> None:
        """Log a batch of questions submitted."""
        self.log_event("QUESTIONS_SUBMITTED", {
            "count": len(questions),
            "questions": questions,
        })

    def log_answers_received(self, answers: list[dict[str, Any]]) -> None:
        """Log answers received from referee."""
        self.log_event("ANSWERS_RECEIVED", {
            "count": len(answers),
            "answers": answers,
        })

    def log_guess_submitted(self, guess: dict[str, Any]) -> None:
        """Log final guess submission."""
        self.log_event("GUESS_SUBMITTED", guess)

    def log_result(self, result: dict[str, Any]) -> None:
        """Log game result."""
        self.log_event("GAME_RESULT", result)

    def log_state_transition(self, from_state: str, to_state: str) -> None:
        """Log state machine transition."""
        self.log_event("STATE_TRANSITION", {
            "from": from_state,
            "to": to_state,
        })

    def log_error(self, error: str, details: dict[str, Any] | None = None) -> None:
        """Log an error during the game."""
        self._logger.error(f"[ERROR] {error}")
        self.log_event("ERROR", {
            "error": error,
            "details": details or {},
        })

    def end_session(self) -> None:
        """Mark the session as ended and flush logs."""
        self._session.ended_at = datetime.now(UTC).isoformat()
        self._logger.info(f"Game session ended: {self._game_id}")

    def get_session_summary(self) -> dict[str, Any]:
        """Get summary of the game session."""
        return {
            "game_id": self._session.game_id,
            "started_at": self._session.started_at,
            "ended_at": self._session.ended_at,
            "event_count": len(self._session.entries),
        }
