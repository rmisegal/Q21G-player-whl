"""Registration handler for manual registration commands."""

from q21_player._infra.domain.services.registration_service import RegistrationService
from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.gmail.sender import GmailSender
from q21_player._infra.shared.logging.logger import get_logger


class RegistrationHandler:
    """Handler for manual registration operations."""

    def __init__(
        self, player_email: str, player_name: str, dry_run: bool = False
    ):
        self._logger = get_logger("registration_handler")
        self._player_email = player_email
        self._player_name = player_name
        self._dry_run = dry_run
        self._gmail_client = GmailClient()
        self._sender = GmailSender(self._gmail_client)
        self._registration_service = RegistrationService(player_email, player_name)

    def initialize(self) -> bool:
        """Initialize Gmail client."""
        if not self._gmail_client.authenticate():
            self._logger.error("Gmail authentication failed")
            return False
        return True

    def register(self) -> dict:
        """Send registration request to league."""
        result = {"success": False, "action": "register", "message": ""}
        try:
            message = self._registration_service.create_registration_request()
            if self._dry_run:
                result["message"] = "[DRY RUN] Would send registration"
                result["success"] = True
            else:
                self._sender.send(
                    to=message.envelope.recipient_email,
                    subject=message.subject,
                    body=message.body_text,
                    attachment=message.payload,
                    attachment_name=message.attachment_name,
                )
                result["message"] = "Registration request sent"
                result["success"] = True
            self._logger.info(result["message"])
        except Exception as e:
            result["message"] = f"Registration failed: {e}"
            self._logger.error(result["message"])
        return result

    def unregister(self) -> dict:
        """Send unregistration request to league."""
        result = {"success": False, "action": "unregister", "message": ""}
        try:
            message = self._registration_service.create_unregister_request()
            if message is None:
                result["message"] = "Cannot unregister: not registered"
                self._logger.warning(result["message"])
                return result
            if self._dry_run:
                result["message"] = "[DRY RUN] Would send unregistration"
                result["success"] = True
            else:
                self._sender.send(message)
                result["message"] = "Unregistration request sent"
                result["success"] = True
            self._logger.info(result["message"])
        except Exception as e:
            result["message"] = f"Unregistration failed: {e}"
            self._logger.error(result["message"])
        return result

    def send_heartbeat(self) -> dict:
        """Send heartbeat to league."""
        result = {"success": False, "action": "heartbeat", "message": ""}
        try:
            message = self._registration_service.create_heartbeat_message()
            if message is None:
                result["message"] = "Cannot send heartbeat: not registered"
                self._logger.warning(result["message"])
                return result
            if self._dry_run:
                result["message"] = "[DRY RUN] Would send heartbeat"
                result["success"] = True
            else:
                self._sender.send(message)
                result["message"] = "Heartbeat sent"
                result["success"] = True
            self._logger.info(result["message"])
        except Exception as e:
            result["message"] = f"Heartbeat failed: {e}"
            self._logger.error(result["message"])
        return result

    def get_status(self) -> dict:
        """Get registration status."""
        return {
            "player_email": self._player_email,
            "player_name": self._player_name,
            "is_registered": self._registration_service.is_registered,
            "registration_id": self._registration_service.registration_id,
            "dry_run": self._dry_run,
        }
