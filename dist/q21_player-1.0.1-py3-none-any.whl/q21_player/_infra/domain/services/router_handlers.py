"""Handler functions for message router."""
from typing import Any
from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.domain.models.messages import IncomingMessage


def p(m: IncomingMessage, k: str, d: Any = None) -> Any:
    """Extract field from message payload."""
    return m.payload.get(k, d)


def handle_registration_response(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    inner = p(msg, "payload", {})
    status = inner.get("status", p(msg, "status", ""))
    return {"action": "registration_complete", "success": status.upper() == "ACCEPTED" if status else False,
        "player_id": inner.get("player_id", p(msg, "player_id")), "auth_token": inner.get("auth_token", p(msg, "auth_token")),
        "league_id": inner.get("league_id", p(msg, "league_id"))}


def handle_game_invitation(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    game_inv = p(msg, "game_invitation", {})
    return {"action": "process_invitation", "match_id": p(msg, "match_id") or game_inv.get("match_id"),
        "round_id": p(msg, "round_id"), "game_type": game_inv.get("game_type", "q21"), "book_name": p(msg, "book_name"),
        "general_description": p(msg, "general_description") or p(msg, "book_description") or p(msg, "description"), "associative_domain": p(msg, "associative_domain"), "should_accept": True}


def handle_round_start(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "round_started", "match_id": p(msg, "match_id"), "round_id": p(msg, "round_id"),
        "book_name": p(msg, "book_name"), "general_description": p(msg, "general_description") or p(msg, "book_description") or p(msg, "description"), "associative_domain": p(msg, "associative_domain")}


def handle_warmup_call(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "answer_warmup", "match_id": p(msg, "match_id"), "warmup_question": p(msg, "warmup_question") or p(msg, "question"),
        "options": p(msg, "options", []), "deadline": p(msg, "deadline")}


def handle_questions_call(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "submit_questions", "match_id": p(msg, "match_id"), "deadline": p(msg, "deadline")}


def handle_answers_batch(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "process_answers_and_guess", "match_id": p(msg, "match_id"), "answers": p(msg, "answers", [])}


def handle_game_result(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    result = p(msg, "result", {})
    total_score = result.get("total_score") or p(msg, "total_score") or p(msg, "private_score", 0)
    return {"action": "process_result", "match_id": p(msg, "match_id"), "total_score": total_score,
        "breakdown": result.get("breakdown", {}), "feedback": result.get("feedback", {}), "game_complete": True}


def handle_hints(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "process_hints", "match_id": p(msg, "match_id"), "description": p(msg, "description", ""),
        "association_topic": p(msg, "association_topic", "")}


def handle_score_feedback(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    scores = p(msg, "scores") or p(msg, "breakdown") or {}
    total_score = scores.get("total_score") or p(msg, "total_score") or p(msg, "private_score", 0)
    return {"action": "process_score_feedback", "match_id": p(msg, "match_id"), "total_score": total_score,
        "breakdown": scores, "game_complete": True}


def handle_connectivity_test(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "echo_response", "ping_id": p(msg, "ping_id")}


def handle_standings_response(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "standings_received", "standings": p(msg, "standings", [])}


def handle_league_error(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "handle_error", "error_code": p(msg, "error_code"), "error_name": p(msg, "error_name"),
        "error_description": p(msg, "error_description"), "retryable": p(msg, "retryable", False)}


def handle_game_error(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "handle_game_error", "match_id": p(msg, "match_id"), "error_code": p(msg, "error_code"),
        "error_name": p(msg, "error_name"), "retryable": p(msg, "retryable", False), "retry_count": p(msg, "retry_count", 0), "max_retries": p(msg, "max_retries", 3)}


def handle_round_announcement(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "round_announced", "league_id": p(msg, "league_id"), "round_id": p(msg, "round_id"), "matches": p(msg, "matches", [])}


def handle_broadcast(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "handle_broadcast", "broadcast_id": p(msg, "broadcast_id"), "message_type": str(msg.message_type), "message_text": p(msg, "message_text")}


def handle_assignment_table(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "process_assignments", "season_id": p(msg, "season_id", ""), "round_number": p(msg, "round_number", 0),
        "assignments": p(msg, "assignments", [])}


def handle_unknown(msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
    return {"action": "unknown", "message_type": str(msg.message_type)}
