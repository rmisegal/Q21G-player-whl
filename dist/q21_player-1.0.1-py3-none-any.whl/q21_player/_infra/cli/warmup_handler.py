"""Warmup Handler for Q21_WARMUP_CALL and Q21_ROUND_START messages."""

from datetime import datetime, timezone
from typing import Any

from q21_player._infra.cli.handlers.base_game_handler import BaseGameHandler
from q21_player._infra.cli.match_tracker import MatchTracker
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository


class WarmupHandler(BaseGameHandler):
    """Handles warmup call and round start messages for Q21 games."""

    def __init__(
        self,
        state_repo: GameStateRepository | None = None,
        game_repo: GameRepository | None = None,
        tracker: MatchTracker | None = None,
    ):
        super().__init__(state_repo=state_repo, game_repo=game_repo)
        self._tracker = tracker or MatchTracker()

    def process(self, payload: dict[str, Any], player_email: str) -> dict[str, Any]:
        """Process Q21_WARMUP_CALL message.

        Args:
            payload: Warmup call payload
            player_email: Player's email

        Returns:
            dict with match_id, warmup_question, warmup_answer for response
        """
        match_id = payload.get("match_id", "")
        warmup_question = payload.get("warmup_question") or payload.get("question", "")

        # Create match entry
        self._tracker.create_from_warmup_call(payload, player_email)

        # Parse and store deadline if provided
        deadline_str = payload.get("deadline")
        if deadline_str:
            deadline = self._parse_deadline(deadline_str)
            if deadline:
                self._state_repo.set_warmup_deadline(match_id, deadline)

        # Initialize retry count
        self._state_repo.set_warmup_retry_count(match_id, 0)

        # Generate warmup answer (simple math evaluation for now)
        warmup_answer = self._generate_answer(warmup_question)

        # Store warmup in game state
        self._state_repo.store_warmup(match_id, warmup_question, warmup_answer)

        # Update phase
        self._state_repo.update_phase(match_id, "WARMUP_SENT")

        self._logger.info(f"Processed warmup for match {match_id}: Q={warmup_question}, A={warmup_answer}")
        return {
            "match_id": match_id,
            "warmup_question": warmup_question,
            "warmup_answer": warmup_answer,
        }

    def can_retry(self, match_id: str) -> bool:
        """Check if warmup retry is allowed (max 1 retry)."""
        retry_count = self._state_repo.get_warmup_retry_count(match_id)
        return retry_count < 1

    def increment_retry_count(self, match_id: str) -> None:
        """Increment the warmup retry count."""
        current = self._state_repo.get_warmup_retry_count(match_id)
        self._state_repo.set_warmup_retry_count(match_id, current + 1)

    def handle_round_start(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Handle Q21_ROUND_START message to store book info and round config."""
        match_id = payload.get("match_id", "")
        book_name = payload.get("book_name", "")
        book_description = payload.get("book_description") or payload.get("description", "")
        associative_domain = payload.get("associative_domain", "")

        # Store book info
        self._state_repo.store_book_info(match_id, book_name, book_description, associative_domain)

        result = {"match_id": match_id, "book_name": book_name, "domain": associative_domain}

        # Extract and store optional round config per PRD
        your_role = payload.get("your_role")
        if your_role:
            self._state_repo.store_player_role(match_id, your_role)
            result["your_role"] = your_role

        questions_required = payload.get("questions_required")
        if questions_required is not None:
            self._state_repo.store_questions_required(match_id, questions_required)
            result["questions_required"] = questions_required

        time_limit_minutes = payload.get("time_limit_minutes")
        if time_limit_minutes is not None:
            time_limit_seconds = time_limit_minutes * 60
            self._state_repo.store_time_limit(match_id, time_limit_seconds)
            result["time_limit_seconds"] = time_limit_seconds

        # Update phase
        self._state_repo.update_phase(match_id, "AWAITING_QUESTIONS_CALL")

        self._logger.info(f"Round start for match {match_id}: book={book_name}, role={your_role}")
        return result

    def _generate_answer(self, question: str) -> str:
        """Generate answer for warmup question using SDK strategy."""
        from q21_player._infra.strategy.strategy_factory import get_strategy
        strategy = get_strategy()
        return strategy.get_warmup_answer(question)
