"""Game invitation repository for tracking match invitations."""

from datetime import UTC, datetime

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import GameInvitationModel


class GameInvitationRepository(BaseRepository[GameInvitationModel]):
    """Repository for game invitation operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(GameInvitationModel, pool)

    def save_invitation(
        self, match_id: str, player_email: str, referee_email: str,
        opponent_email: str | None = None, book_name: str | None = None,
        deadline: datetime | None = None
    ) -> GameInvitationModel:
        """Create a new invitation record."""
        model = GameInvitationModel(
            match_id=match_id, player_email=player_email, referee_email=referee_email,
            opponent_email=opponent_email, book_name=book_name, deadline=deadline, status="PENDING",
        )
        return super().create(model)

    def get_by_match_id(self, match_id: str) -> GameInvitationModel | None:
        """Get invitation by match_id."""
        return self._query_one({"match_id": match_id}, "get invitation")

    def get_by_player_email(self, player_email: str) -> list[GameInvitationModel]:
        """Get all invitations for a player."""
        return self._query_many({"player_email": player_email})

    def get_pending(self, player_email: str) -> list[GameInvitationModel]:
        """Get pending invitations for a player."""
        return self._query_many({"player_email": player_email, "status": "PENDING"})

    def update_status(self, match_id: str, status: str) -> bool:
        """Update invitation status."""
        return self._update_fields({"match_id": match_id}, {"status": status}, "update status")

    def mark_responded(self, match_id: str, status: str) -> bool:
        """Mark invitation as responded with timestamp."""
        return self._update_fields(
            {"match_id": match_id},
            {"status": status, "responded_at": datetime.now(UTC)},
            "mark responded"
        )
