"""
Error handling and process termination.

Logs errors to terminal and file, then terminates the process.
"""

import json
import sys
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import NoReturn


@dataclass
class CallbackError:
    """Details of a callback error."""

    error_type: str  # TIMEOUT | INVALID_JSON | SCHEMA_VALIDATION
    callback_name: str
    input_payload: dict
    output_payload: dict | None
    validation_errors: list[str]


def format_error_log(error: CallbackError) -> str:
    """Format error details as a log string."""
    lines = [
        "",
        "=" * 64,
        " CALLBACK ERROR — PROCESS TERMINATED",
        "=" * 64,
        f" Timestamp:    {datetime.now(timezone.utc).isoformat()}",
        f" Error Type:   {error.error_type}",
        f" Callback:     {error.callback_name}",
        "",
        " ── INPUT PAYLOAD " + "─" * 46,
        json.dumps(error.input_payload, indent=2, default=str),
        "",
    ]

    if error.output_payload is not None:
        lines.extend([
            " ── OUTPUT PAYLOAD " + "─" * 45,
            json.dumps(error.output_payload, indent=2, default=str),
            "",
        ])

    if error.validation_errors:
        lines.extend([
            " ── VALIDATION ERRORS " + "─" * 42,
        ])
        for err in error.validation_errors:
            lines.append(f" • {err}")
        lines.append("")

    lines.append("=" * 64)
    lines.append("")

    return "\n".join(lines)


def write_error_log(error: CallbackError, log_dir: Path | None = None) -> Path:
    """Write error to log file."""
    if log_dir is None:
        log_dir = Path.cwd() / "logs"
    log_dir.mkdir(exist_ok=True)

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"error_{timestamp}_{error.callback_name}.log"

    log_content = format_error_log(error)
    log_file.write_text(log_content)

    return log_file


def handle_error(error: CallbackError) -> NoReturn:
    """
    Handle a callback error: log and terminate.

    1. Print to terminal
    2. Write to log file
    3. Exit with non-zero code
    """
    # Print to terminal
    log_content = format_error_log(error)
    print(log_content)

    # Write to log file
    try:
        log_file = write_error_log(error)
        print(f"Error log written to: {log_file}")
    except Exception as e:
        print(f"Failed to write log file: {e}")

    # Exit with error code
    sys.exit(1)
