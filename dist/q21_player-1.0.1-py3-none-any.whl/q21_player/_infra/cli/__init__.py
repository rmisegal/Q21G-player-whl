"""
CLI layer for GmailAsPlayer.

Provides:
- Main entry point
- Command line argument parsing
- Player orchestration
"""

from q21_player._infra.cli.main import main
from q21_player._infra.cli.orchestrator import PlayerOrchestrator
from q21_player._infra.cli.periodic_handler import PeriodicHandler

__all__ = [
    "main",
    "PlayerOrchestrator",
    "PeriodicHandler",
]
