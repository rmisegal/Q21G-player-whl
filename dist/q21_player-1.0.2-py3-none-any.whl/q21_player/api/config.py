"""
Configuration loading and validation.

Loads player configuration from JSON file.
"""

import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Any


REQUIRED_FIELDS = [
    "player_email",
    "player_password",
    "player_id",
    "referee_email",
]

OPTIONAL_DEFAULTS = {
    "league_manager_email": "",
    "poll_interval_seconds": 5,
    "llm_provider": "mock",
    "llm_timeout_seconds": 120,
}


class ConfigError(Exception):
    """Raised when configuration is invalid."""
    pass


@dataclass
class PlayerConfig:
    """Player configuration loaded from JSON."""

    player_email: str
    player_password: str
    player_id: str
    referee_email: str
    league_manager_email: str = ""
    poll_interval_seconds: int = 5
    llm_provider: str = "mock"
    llm_timeout_seconds: int = 120

    @classmethod
    def load(cls, path: str | Path) -> "PlayerConfig":
        """Load configuration from JSON file."""
        path = Path(path)
        if not path.exists():
            raise ConfigError(f"Config file not found: {path}")

        try:
            with open(path) as f:
                data = json.load(f)
        except json.JSONDecodeError as e:
            raise ConfigError(f"Invalid JSON in config file: {e}")

        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PlayerConfig":
        """Create config from dictionary."""
        # Check required fields
        missing = [f for f in REQUIRED_FIELDS if f not in data]
        if missing:
            raise ConfigError(f"Missing required fields: {missing}")

        # Apply defaults for optional fields
        for field_name, default in OPTIONAL_DEFAULTS.items():
            if field_name not in data:
                data[field_name] = default

        return cls(
            player_email=data["player_email"],
            player_password=data["player_password"],
            player_id=data["player_id"],
            referee_email=data["referee_email"],
            league_manager_email=data.get("league_manager_email", ""),
            poll_interval_seconds=data.get("poll_interval_seconds", 5),
            llm_provider=data.get("llm_provider", "mock"),
            llm_timeout_seconds=data.get("llm_timeout_seconds", 120),
        )

    def validate(self) -> None:
        """Validate configuration values."""
        if not self.player_email:
            raise ConfigError("player_email cannot be empty")
        if not self.player_password:
            raise ConfigError("player_password cannot be empty")
        if not self.player_id:
            raise ConfigError("player_id cannot be empty")
        if not self.referee_email:
            raise ConfigError("referee_email cannot be empty")
