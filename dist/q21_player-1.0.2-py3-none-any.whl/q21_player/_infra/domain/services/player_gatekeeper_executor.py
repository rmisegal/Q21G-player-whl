"""Gatekeeper action executor - performs DB operations for gatekeeper actions."""

from q21_player._infra.domain.services.player_gatekeeper_actions import ActionType, GatekeeperAction
from q21_player._infra.repository.assignment_repository import AssignmentRepository
from q21_player._infra.shared.logging.logger import get_logger

logger = get_logger("gatekeeper_executor")


class GatekeeperExecutor:
    """Executes gatekeeper actions that require side effects (DB writes)."""

    def __init__(self, assignment_repo: AssignmentRepository):
        self._assignment_repo = assignment_repo

    def execute(self, action: GatekeeperAction) -> None:
        """Execute the action returned by the gatekeeper."""
        if action.action_type == ActionType.STORE_ASSIGNMENT:
            self._store_assignments(action.params)
        elif action.action_type == ActionType.ADVANCE_ROUND:
            self._advance_round(action.params)
        elif action.action_type == ActionType.LOG_INCOMING:
            self._log_incoming(action.log_entry)

    def _store_assignments(self, params: dict) -> None:
        """Store enriched assignments with referee info."""
        season_id = params.get("season_id", "")
        assignments = params.get("assignments", [])
        # Don't pass round_number - each assignment has its own from game_id
        self._assignment_repo.save_assignments(season_id=season_id, assignments=assignments)
        logger.info(f"Stored {len(assignments)} assignments for season={season_id}")

    def _advance_round(self, params: dict) -> None:
        """Log round advancement."""
        logger.info(f"Round {params.get('completed_round')} → {params.get('new_round')}")

    def _log_incoming(self, log_entry: dict | None) -> None:
        """Log incoming request that requires a response."""
        if log_entry:
            logger.info(f"Incoming request: type={log_entry.get('msg_type')}, match={log_entry.get('match_id')}")
