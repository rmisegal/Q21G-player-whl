"""Message service for processing and building game messages."""
from dataclasses import dataclass
from typing import Any

from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.domain.models.guess import Guess
from q21_player._infra.domain.models.messages import IncomingMessage, OutgoingMessage
from q21_player._infra.domain.models.question import Question, QuestionBatch, QuestionOptions
from q21_player._infra.domain.services.broadcast_handler import BROADCAST_TYPES, BroadcastHandler
from q21_player._infra.domain.services.broadcast_response_builder import BroadcastResponseBuilder
from q21_player._infra.domain.services.message_parser import MessageParser
from q21_player._infra.domain.services.message_router import create_default_router
from q21_player._infra.domain.services.response_builder import ResponseBuilder
from q21_player._infra.domain.services.state_machine import PlayerStateMachine
from q21_player._infra.shared.config.constants import MessageType, PlayerState
from q21_player._infra.shared.config.protocol_registry import get_default_registry
from q21_player._infra.shared.logging.logger import get_logger


@dataclass
class MessageResult:
    success: bool
    response: OutgoingMessage | None = None
    state_changed: bool = False
    new_state: PlayerState | None = None
    error: str | None = None


class MessageService:
    def __init__(self, state_machine: PlayerStateMachine):
        self._logger = get_logger("message_service")
        self._state_machine = state_machine
        self._registry = get_default_registry()
        self._parser = MessageParser(registry=self._registry)
        self._router = create_default_router(registry=self._registry)
        self._builder = ResponseBuilder(registry=self._registry)
        self._broadcast_handler = BroadcastHandler()
        self._broadcast_builder = BroadcastResponseBuilder()

    def is_broadcast(self, message: IncomingMessage) -> bool:
        return message.message_type in BROADCAST_TYPES

    def process_message(self, message: IncomingMessage, context: GameContext) -> MessageResult:
        try:
            if message.envelope is None:
                message.envelope = self._parser.parse(message)
            handler_result = self._router.route(message, context)
            action = handler_result.get("action", "unknown")
            state_map = {
                "registration_complete": (handler_result.get("success"), PlayerState.REGISTERED),
                "process_invitation": (True, PlayerState.INVITED),
                "process_answers": (True, PlayerState.GUESSING),
                "process_result": (True, PlayerState.MATCH_COMPLETE),
            }
            state_changed, new_state = False, None
            if action in state_map:
                should_change, target_state = state_map[action]
                if should_change:
                    state_changed, new_state = True, target_state
            return MessageResult(success=True, response=None, state_changed=state_changed, new_state=new_state)
        except Exception as e:
            self._logger.error(f"Error processing message: {e}")
            return MessageResult(success=False, error=str(e))

    def build_question_response(self, questions_data: dict[str, Any], context: GameContext) -> OutgoingMessage:
        questions = [Question(number=q["number"], text=q["text"],
            options=QuestionOptions(A=q["options"]["A"], B=q["options"]["B"], C=q["options"]["C"], D=q["options"]["D"]))
            for q in questions_data.get("questions", [])]
        batch = QuestionBatch(questions=questions, game_id=context.game_id,
            strategy_used=questions_data.get("strategy", "unknown"))
        return self._builder.build_questions_batch(context.referee_email, batch, auth_token=context.auth_token,
            match_id=context.match_id, reply_to=context.transaction_id)

    def build_guess_response(self, guess_data: dict[str, Any], context: GameContext) -> OutgoingMessage:
        guess = Guess(game_id=context.game_id, opening_sentence=guess_data["opening_sentence"],
            sentence_justification=guess_data["sentence_justification"], associative_word=guess_data["associative_word"],
            word_variations=guess_data.get("word_variations", []), word_justification=guess_data["word_justification"],
            confidence=guess_data.get("confidence", 0.5), strategy_used=guess_data.get("strategy", "unknown"))
        return self._builder.build_guess_submission(context.referee_email, guess, auth_token=context.auth_token,
            match_id=context.match_id, reply_to=context.transaction_id)

    def build_error_response(self, error_message: str, context: GameContext) -> OutgoingMessage:
        return self._builder.build_error_response(context.referee_email, "PLAYER_ERROR", error_message, context.transaction_id)

    def handle_broadcast(self, message: IncomingMessage, current_state: PlayerState, match_id: str | None
    ) -> tuple[dict[str, Any], OutgoingMessage | None]:
        result = self._broadcast_handler.handle(message, current_state, match_id)
        response = self._build_broadcast_response(result) if result.get("action") == "respond" else None
        return result, response

    def _build_broadcast_response(self, result: dict[str, Any]) -> OutgoingMessage | None:
        resp_type, bid = result.get("response_type"), result.get("broadcast_id", "")
        if resp_type == MessageType.RESPONSE_KEEP_ALIVE:
            return self._broadcast_builder.build_keep_alive_response(bid, result.get("machine_state", "INIT_START_STATE"), "operational", "Agent active")
        elif resp_type == MessageType.RESPONSE_FREE_TEXT:
            return self._broadcast_builder.build_free_text_response(bid, "Message acknowledged")
        elif resp_type == MessageType.RESPONSE_CRITICAL_PAUSE:
            return self._broadcast_builder.build_critical_pause_response(bid, result.get("previous_state", ""), result.get("match_id"), "Paused")
        elif resp_type == MessageType.RESPONSE_CRITICAL_CONTINUE:
            return self._broadcast_builder.build_critical_continue_response(bid, result.get("restored_state", ""), result.get("restored_match_id"), "Resumed")
        elif resp_type == MessageType.RESPONSE_CRITICAL_RESET:
            return self._broadcast_builder.build_critical_reset_response(bid, ["game_sessions", "questions", "guesses"], "Reset complete")
        return None
