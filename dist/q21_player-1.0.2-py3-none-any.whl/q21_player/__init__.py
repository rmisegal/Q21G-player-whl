"""
q21-player: Student SDK for Q21 21-Questions Game.

Students implement PlayerAI callbacks and run via CLI or PlayerRunner.

Example:
    from q21_player import PlayerAI

    class MyPlayerAI(PlayerAI):
        def get_warmup_answer(self, ctx): return {"answer": "4"}
        def get_questions(self, ctx): return {"questions": [...]}
        def get_guess(self, ctx): return {"opening_sentence": "...", ...}
        def on_score_received(self, ctx): pass

    # Configure in config.json, then run: q21-player scan
"""

from q21_player._version import __version__

# Core classes
from q21_player.api.callbacks import PlayerAI
from q21_player.api.config import PlayerConfig, ConfigError
from q21_player.api.demo_player_ai import DemoPlayerAI
from q21_player.api.validator import SchemaValidator, ValidationError
from q21_player.api.state import GameState, GamePhase
from q21_player.api.message_parser import MessageParseError

# LLM integration
from q21_player.api.llm import LLMClient, LLMPlayerAI, LLMResponse

# Runner for programmatic use
from q21_player.runner import PlayerRunner

__all__ = [
    # Version
    "__version__",
    # Core
    "PlayerAI",
    "PlayerConfig",
    "ConfigError",
    "DemoPlayerAI",
    # Validation
    "SchemaValidator",
    "ValidationError",
    # State
    "GameState",
    "GamePhase",
    # Errors
    "MessageParseError",
    # LLM
    "LLMClient",
    "LLMPlayerAI",
    "LLMResponse",
    # Runner
    "PlayerRunner",
]
