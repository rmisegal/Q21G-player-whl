"""Scan logger for message logging during scan operations."""

from typing import Any

from q21_player._infra.repository.message_log_repository import MessageLogRepository
from q21_player._infra.shared.logging.logger import get_logger


class ScanLogger:
    """Helper class for logging messages during scan operations."""

    def __init__(self, message_log_repo: MessageLogRepository):
        self._message_log_repo = message_log_repo
        self._logger = get_logger("scan_logger")

    def log_incoming(
        self,
        gmail_id: str,
        thread_id: str,
        msg_type: str,
        transaction_id: str,
        sender_email: str,
        recipient_email: str,
        subject: str,
        payload: dict | None = None,
        league_id: str | None = None,
        round_id: str | None = None,
        game_id: str | None = None
    ) -> None:
        """Log an incoming message."""
        try:
            self._message_log_repo.log_incoming(
                gmail_id=gmail_id,
                thread_id=thread_id,
                message_type=msg_type,
                transaction_id=transaction_id,
                sender_email=sender_email,
                recipient_email=recipient_email,
                subject=subject,
                payload=payload,
                game_id=game_id,
                league_id=league_id,
                round_id=round_id
            )
            self._logger.debug(f"Logged incoming: {msg_type} ({gmail_id})")
        except Exception as e:
            self._logger.error(f"Failed to log incoming message: {e}")

    def log_outgoing(
        self,
        transaction_id: str,
        msg_type: str,
        sender_email: str,
        recipient_email: str,
        subject: str,
        payload: dict | None = None,
        league_id: str | None = None,
        round_id: str | None = None,
        game_id: str | None = None
    ) -> None:
        """Log an outgoing message."""
        try:
            gmail_id = f"out-{transaction_id}"
            self._message_log_repo.log_outgoing(
                gmail_id=gmail_id,
                message_type=msg_type,
                transaction_id=transaction_id,
                sender_email=sender_email,
                recipient_email=recipient_email,
                subject=subject,
                payload=payload,
                game_id=game_id,
                league_id=league_id,
                round_id=round_id
            )
            self._logger.debug(f"Logged outgoing: {msg_type} ({transaction_id})")
        except Exception as e:
            self._logger.error(f"Failed to log outgoing message: {e}")
