"""Message rules for player gatekeeper - maps message types to actions."""

from q21_player._infra.domain.services.player_gatekeeper_actions import ActionType


class SenderType:
    """Expected sender types for message validation."""

    REFEREE = "REFEREE"  # Must come from assigned referee
    MANAGER = "MANAGER"  # Must come from league manager
    ANY = "ANY"  # No sender validation


# Keys are uppercase, no underscores (wire format)
MESSAGE_RULES: dict[str, dict] = {
    # Assignment broadcast - store referee info then process (from manager)
    "BROADCASTASSIGNMENTTABLE": {"action": ActionType.STORE_ASSIGNMENT, "should_process": True, "sender": SenderType.MANAGER},
    # Game calls requiring response - log and process (from referee)
    "Q21WARMUPCALL": {"action": ActionType.LOG_INCOMING, "should_process": True, "sender": SenderType.REFEREE},
    "Q21QUESTIONSCALL": {"action": ActionType.LOG_INCOMING, "should_process": True, "sender": SenderType.REFEREE},
    "Q21GUESSCALL": {"action": ActionType.LOG_INCOMING, "should_process": True, "sender": SenderType.REFEREE},
    # Info-only messages - just process (from referee)
    "Q21ROUNDSTART": {"action": ActionType.PROCESS_NORMAL, "should_process": True, "sender": SenderType.REFEREE},
    "Q21ANSWERSBATCH": {"action": ActionType.PROCESS_NORMAL, "should_process": True, "sender": SenderType.REFEREE},
    "Q21HINTS": {"action": ActionType.PROCESS_NORMAL, "should_process": True, "sender": SenderType.REFEREE},
    "Q21GUESSRESULT": {"action": ActionType.PROCESS_NORMAL, "should_process": True, "sender": SenderType.REFEREE},
    "Q21SCOREFEEDBACK": {"action": ActionType.PROCESS_NORMAL, "should_process": True, "sender": SenderType.REFEREE},
    # Round lifecycle (from manager)
    "BROADCASTROUNDRESULTS": {"action": ActionType.ADVANCE_ROUND, "should_process": True, "sender": SenderType.MANAGER},
}

DEFAULT_RULE = {"action": ActionType.PROCESS_NORMAL, "should_process": True, "sender": SenderType.MANAGER}

PLAYER_ROLES = ["PLAYER1", "PLAYER2", "PLAYER_A", "PLAYER_B", "player1", "player2"]
