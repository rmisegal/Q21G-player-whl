"""
Timeout manager for GmailAsPlayer.

Tracks and enforces timeouts for each state.
"""

import threading
import time
from collections.abc import Callable

from q21_player._infra.shared.config.constants import DEFAULT_STATE_TIMEOUT_SEC, PlayerState
from q21_player._infra.shared.logging.logger import get_logger

# Default timeouts per state (seconds)
STATE_TIMEOUTS: dict[PlayerState, float] = {
    PlayerState.INIT_START_STATE: float("inf"),  # No timeout
    PlayerState.REGISTRATION_OPEN: float("inf"),  # No timeout - waiting for registration
    PlayerState.REGISTERING: 300.0,  # 5 minutes
    PlayerState.REGISTERED: float("inf"),  # No timeout
    PlayerState.AWAITING_ASSIGNMENT: float("inf"),  # No timeout - waiting for game invitation
    PlayerState.ASSIGNMENTS_RECEIVED: 120.0,  # 2 minutes to process assignments
    PlayerState.INVITED: 120.0,  # 2 minutes to accept
    PlayerState.IN_MATCH: 60.0,  # 1 minute to start
    PlayerState.WARMUP: 60.0,  # 1 minute to answer warmup
    PlayerState.QUESTIONING: 300.0,  # 5 minutes to submit questions
    PlayerState.AWAITING_ANSWERS: 600.0,  # 10 minutes for answers
    PlayerState.GUESSING: 300.0,  # 5 minutes to submit guess
    PlayerState.MATCH_COMPLETE: 60.0,  # 1 minute to process result
    PlayerState.PAUSED: float("inf"),  # No timeout while paused
    PlayerState.ERROR: float("inf"),  # No timeout
    PlayerState.WAITING_FOR_CONFIRMATION: 300.0,  # 5 minutes for confirmation
    PlayerState.SEASON_REJECTED: float("inf"),  # No timeout - terminal state
}


class TimeoutManager:
    """Manages state timeouts with callbacks."""

    def __init__(self, on_timeout: Callable[[PlayerState], None] | None = None):
        self._logger = get_logger("timeout_manager")
        self._on_timeout = on_timeout
        self._current_state: PlayerState | None = None
        self._state_entered_at: float | None = None
        self._timer: threading.Timer | None = None
        self._lock = threading.Lock()
        self._custom_timeouts: dict[PlayerState, float] = {}

    def set_state(self, state: PlayerState) -> None:
        """Update current state and reset timeout."""
        with self._lock:
            self._cancel_timer()
            self._current_state = state
            self._state_entered_at = time.monotonic()
            timeout = self._get_timeout(state)

            if timeout != float("inf"):
                self._timer = threading.Timer(timeout, self._handle_timeout)
                self._timer.daemon = True
                self._timer.start()
                self._logger.debug(f"Timeout set: {state.value} ({timeout}s)")

    def _get_timeout(self, state: PlayerState) -> float:
        """Get timeout for state (custom or default)."""
        if state in self._custom_timeouts:
            return self._custom_timeouts[state]
        return STATE_TIMEOUTS.get(state, DEFAULT_STATE_TIMEOUT_SEC)

    def set_custom_timeout(self, state: PlayerState, timeout_seconds: float) -> None:
        """Set custom timeout for a state."""
        self._custom_timeouts[state] = timeout_seconds

    def _cancel_timer(self) -> None:
        """Cancel existing timer."""
        if self._timer is not None:
            self._timer.cancel()
            self._timer = None

    def _handle_timeout(self) -> None:
        """Handle timeout expiration."""
        with self._lock:
            state = self._current_state

        if state is None:
            return

        self._logger.warning(f"Timeout expired for state: {state.value}")

        if self._on_timeout:
            try:
                self._on_timeout(state)
            except Exception as e:
                self._logger.error(f"Timeout callback error: {e}")

    def get_remaining_time(self) -> float | None:
        """Get remaining time in current state."""
        with self._lock:
            if self._current_state is None or self._state_entered_at is None:
                return None

            timeout = self._get_timeout(self._current_state)
            if timeout == float("inf"):
                return None

            elapsed = time.monotonic() - self._state_entered_at
            remaining = timeout - elapsed
            return max(0, remaining)

    def is_timed_out(self) -> bool:
        """Check if current state has timed out."""
        remaining = self.get_remaining_time()
        return remaining is not None and remaining <= 0

    def reset(self) -> None:
        """Reset timeout for current state."""
        with self._lock:
            if self._current_state is not None:
                state = self._current_state
        self.set_state(state)

    def stop(self) -> None:
        """Stop all timeout tracking."""
        with self._lock:
            self._cancel_timer()
            self._current_state = None
            self._state_entered_at = None

    @property
    def current_state(self) -> PlayerState | None:
        return self._current_state

    @property
    def time_in_state(self) -> float | None:
        """Get seconds spent in current state."""
        with self._lock:
            if self._state_entered_at is None:
                return None
            return time.monotonic() - self._state_entered_at
