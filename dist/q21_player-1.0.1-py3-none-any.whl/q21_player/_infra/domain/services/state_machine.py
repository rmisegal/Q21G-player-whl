"""Player state machine for GmailAsPlayer."""

from __future__ import annotations

from collections.abc import Callable
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

from q21_player._infra.domain.models.player_state import PlayerStateDTO
from q21_player._infra.domain.services.state_transitions import (
    TransitionEvent,
    get_transition,
    get_valid_transitions_from,
)
from q21_player._infra.shared.config.constants import PlayerState
from q21_player._infra.shared.exceptions.state import InvalidTransitionError
from q21_player._infra.shared.logging.logger import get_logger

if TYPE_CHECKING:
    from q21_player._infra.repository.state_repository import StateRepository


class PlayerStateMachine:
    """State machine for managing player lifecycle."""

    def __init__(
        self, player_email: str, initial_state: PlayerState = PlayerState.INIT_START_STATE,
        repository: StateRepository | None = None
    ):
        self._logger = get_logger("state_machine")
        self._state = PlayerStateDTO(player_email=player_email, current_state=initial_state)
        self._repository = repository
        self._history: list[dict[str, Any]] = []
        self._listeners: list[Callable[[PlayerState, PlayerState, TransitionEvent], None]] = []

    @property
    def current_state(self) -> PlayerState:
        return self._state.current_state

    @property
    def state_dto(self) -> PlayerStateDTO:
        return self._state

    @property
    def player_email(self) -> str:
        return self._state.player_email

    def can_transition(self, event: TransitionEvent) -> bool:
        return get_transition(self.current_state, event) is not None

    def get_available_events(self) -> list[TransitionEvent]:
        return [t.event for t in get_valid_transitions_from(self.current_state)]

    def transition(self, event: TransitionEvent, metadata: dict[str, Any] = None) -> PlayerState:
        """Execute state transition for given event."""
        transition = get_transition(self.current_state, event)
        if transition is None:
            curr_val = self.current_state.value if hasattr(self.current_state, 'value') else self.current_state
            raise InvalidTransitionError(
                from_state=curr_val, to_state="unknown", event=event.value,
                message=f"No valid transition for event '{event.value}' from state '{curr_val}'"
            )
        old_state, new_state = self.current_state, transition.to_state
        old_val = old_state.value if hasattr(old_state, 'value') else old_state
        new_val = new_state.value if hasattr(new_state, 'value') else new_state
        if self._repository:
            self._repository.save_transition(self._state.player_email, old_val, new_val, event.value, metadata)
        else:
            self._history.append({
                "from_state": old_val, "to_state": new_val, "event": event.value,
                "timestamp": datetime.now(UTC).isoformat(), "metadata": metadata or {}
            })
        self._state = self._state.transition_to(new_state)
        if metadata:
            self._state.metadata.update(metadata)
        self._logger.info(f"Transition: {old_val} -> {new_val} [{event.value}]")
        for listener in self._listeners:
            try:
                listener(old_state, new_state, event)
            except Exception as e:
                self._logger.error(f"Listener error: {e}")
        return new_state

    def force_state(self, state: PlayerState, reason: str = "") -> None:
        """Force state without validation (for recovery)."""
        old_state = self.current_state
        self._state = self._state.transition_to(state)
        old_val = old_state.value if hasattr(old_state, 'value') else old_state
        new_val = state.value if hasattr(state, 'value') else state
        if self._repository:
            self._repository.save_transition(self._state.player_email, old_val, new_val, "FORCE", {"reason": reason})
        else:
            self._history.append({
                "from_state": old_val, "to_state": new_val, "event": "FORCE",
                "reason": reason, "timestamp": datetime.now(UTC).isoformat()
            })
        self._logger.warning(f"Forced state: {old_val} -> {new_val} ({reason})")

    def add_listener(self, callback: Callable[[PlayerState, PlayerState, TransitionEvent], None]) -> None:
        self._listeners.append(callback)

    def set_game_id(self, game_id: str | None) -> None:
        self._state = self._state.set_game(game_id)

    @property
    def active_game_id(self) -> str | None:
        return self._state.active_game_id

    @property
    def history(self) -> list[dict[str, Any]]:
        if self._repository:
            transitions = self._repository.get_transition_history(self._state.player_email)
            return [{
                "from_state": t.from_state, "to_state": t.to_state, "event": t.event,
                "timestamp": t.created_at.isoformat(), "metadata": t.transition_metadata or {}
            } for t in reversed(transitions)]
        return self._history.copy()

    @property
    def is_in_game(self) -> bool:
        return self._state.is_in_game

    def reset(self) -> None:
        if self.current_state == PlayerState.ERROR:
            self.transition(TransitionEvent.RESET)
        else:
            self.force_state(PlayerState.INIT_START_STATE, "manual reset")
