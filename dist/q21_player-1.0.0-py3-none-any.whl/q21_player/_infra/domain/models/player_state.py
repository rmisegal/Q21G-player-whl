"""
Player state model for GmailAsPlayer.

Represents the current state of the player in the game lifecycle.
"""

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from q21_player._infra.domain.models.message_context import MessageContext
from q21_player._infra.shared.config.constants import PlayerState


class PlayerStateDTO(BaseModel):
    """Data transfer object for player state."""

    player_email: str = Field(..., description="Player's Gmail address")
    player_name: str = Field(default="", description="Player display name")
    current_state: PlayerState = Field(
        default=PlayerState.INIT_START_STATE,
        description="Current state in the state machine"
    )
    previous_state: PlayerState | None = Field(
        default=None,
        description="Previous state before transition"
    )
    active_game_id: str | None = Field(default=None, description="ID of active game session")
    current_game_id: str | None = Field(default=None, description="Current game ID (alias)")
    current_book: str | None = Field(default=None, description="Current book in game")
    current_description: str | None = Field(default=None, description="Current game description")
    current_domain: str | None = Field(default=None, description="Current game domain")
    current_context: MessageContext | None = Field(
        default=None,
        description="Current message context (league, season, round)"
    )
    state_entered_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="Timestamp when current state was entered"
    )
    last_activity: datetime | None = Field(default=None, description="Last activity timestamp")
    last_activity_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="Timestamp of last activity"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional state metadata"
    )

    model_config = ConfigDict(use_enum_values=True)

    def transition_to(self, new_state: PlayerState) -> "PlayerStateDTO":
        """Create a new state DTO with transition applied."""
        return PlayerStateDTO(
            player_email=self.player_email,
            player_name=self.player_name,
            current_state=new_state,
            previous_state=self.current_state,
            active_game_id=self.active_game_id,
            current_game_id=self.current_game_id,
            current_book=self.current_book,
            current_description=self.current_description,
            current_domain=self.current_domain,
            current_context=self.current_context,
            state_entered_at=datetime.now(UTC),
            last_activity=datetime.now(UTC),
            last_activity_at=datetime.now(UTC),
            metadata=self.metadata,
        )

    def update_activity(self) -> "PlayerStateDTO":
        """Create a new state DTO with updated activity timestamp."""
        return self.model_copy(update={"last_activity_at": datetime.now(UTC)})

    def set_game(self, game_id: str | None) -> "PlayerStateDTO":
        """Create a new state DTO with game ID set."""
        return self.model_copy(update={"active_game_id": game_id})

    @property
    def is_idle(self) -> bool:
        return self.current_state == PlayerState.INIT_START_STATE

    @property
    def is_in_game(self) -> bool:
        return self.current_state in [
            PlayerState.IN_MATCH,
            PlayerState.QUESTIONING,
            PlayerState.AWAITING_ANSWERS,
            PlayerState.GUESSING,
        ]

    @property
    def time_in_state_seconds(self) -> float:
        """Get seconds since entering current state."""
        return (datetime.now(UTC) - self.state_entered_at).total_seconds()
