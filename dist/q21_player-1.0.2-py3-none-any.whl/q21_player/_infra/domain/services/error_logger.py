"""Error logger service for consistent error logging to both Python logging and database."""

import traceback

from q21_player._infra.repository.error_log_repository import ErrorLogRepository
from q21_player._infra.shared.logging.logger import get_logger


class ErrorLogger:
    """Service for logging errors consistently to Python logging and database."""

    _instance: "ErrorLogger | None" = None
    _repo: ErrorLogRepository | None = None
    _logger = get_logger("error_logger")

    def __new__(cls) -> "ErrorLogger":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._repo = ErrorLogRepository()
        return cls._instance

    @classmethod
    def log(
        cls,
        error_type: str,
        message: str,
        context: dict | None = None,
        exc_info: BaseException | None = None,
        error_code: str | None = None,
    ) -> int | None:
        """
        Log an error to both Python logging and database.

        Args:
            error_type: Category of error (e.g., EMAIL_SEND_FAILURE, API_ERROR)
            message: Human-readable error message
            context: Additional context data as dict
            exc_info: Exception instance to extract stack trace from
            error_code: Optional error code for categorization

        Returns:
            Database error log ID if successful, None otherwise
        """
        instance = cls()
        stack_trace = None
        if exc_info:
            stack_trace = "".join(traceback.format_exception(
                type(exc_info), exc_info, exc_info.__traceback__
            ))

        # Log to Python logging
        log_msg = f"[{error_type}] {message}"
        if context:
            log_msg += f" | context={context}"
        cls._logger.error(log_msg, exc_info=exc_info is not None)

        # Log to database
        try:
            if instance._repo:
                error_log = instance._repo.log_error(
                    error_type=error_type,
                    error_message=message,
                    context=context,
                    stack_trace=stack_trace,
                    error_code=error_code,
                )
                return error_log.id
        except Exception as e:
            cls._logger.warning(f"Failed to log error to database: {e}")

        return None
