"""
Game context model for GmailAsPlayer.

Contains all information about an active game session.
"""

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from q21_player._infra.shared.config.constants import GameType


class GameContext(BaseModel):
    """Context for an active Q21 game session."""

    game_id: str = Field(..., description="Unique game identifier")
    match_id: str = Field(default="", description="Match ID from invitation (R1M1 format)")
    transaction_id: str = Field(default="", description="Transaction ID from invitation")
    auth_token: str = Field(default="", description="Authentication token from registration")
    game_type: GameType = Field(default=GameType.Q21, description="Type of game")
    referee_email: str = Field(default="", description="Referee's email address")
    season_id: str = Field(default="", description="Season identifier")
    round_id: str = Field(default="", description="Round identifier")
    league_id: str = Field(default="", description="League identifier")

    # Game content from invitation
    book_name: str = Field(default="", description="Name of book/lecture")
    general_description: str = Field(default="", description="General description (15 words max)")
    associative_domain: str = Field(default="", description="Domain for associative word")

    # Game progress tracking
    questions_submitted: int = Field(default=0, description="Number of questions submitted")
    answers_received: int = Field(default=0, description="Number of answers received")
    guess_submitted: bool = Field(default=False, description="Whether guess was submitted")

    # Timing
    started_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    # History for strategy
    question_history: list[dict[str, Any]] = Field(
        default_factory=list,
        description="History of questions and answers"
    )

    # Results
    final_score: float | None = Field(default=None, description="Final score if game complete")
    result_details: dict[str, Any] = Field(
        default_factory=dict,
        description="Detailed scoring breakdown"
    )

    # Metadata
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(use_enum_values=True, extra="allow")

    def add_question_answer(self, question_num: int, question: str, answer: str) -> None:
        """Add a question-answer pair to history."""
        self.question_history.append({
            "number": question_num,
            "question": question,
            "answer": answer,
            "timestamp": datetime.now(UTC).isoformat(),
        })
        self.answers_received += 1
        self.updated_at = datetime.now(UTC)

    def mark_questions_submitted(self, count: int = 20) -> None:
        """Mark questions as submitted."""
        self.questions_submitted = count
        self.updated_at = datetime.now(UTC)

    def mark_guess_submitted(self) -> None:
        """Mark final guess as submitted."""
        self.guess_submitted = True
        self.updated_at = datetime.now(UTC)

    def set_result(self, score: float, details: dict[str, Any]) -> None:
        """Set game result."""
        self.final_score = score
        self.result_details = details
        self.updated_at = datetime.now(UTC)

    @property
    def is_complete(self) -> bool:
        """Check if game is complete."""
        return self.final_score is not None

    @property
    def can_submit_questions(self) -> bool:
        """Check if questions can still be submitted."""
        return self.questions_submitted == 0

    @property
    def can_submit_guess(self) -> bool:
        """Check if guess can be submitted."""
        return self.answers_received == 20 and not self.guess_submitted

    @property
    def duration_seconds(self) -> float:
        """Get game duration in seconds."""
        return (self.updated_at - self.started_at).total_seconds()
