"""
Resource manager for GmailAsPlayer.

Singleton pattern for managing shared resources and thread-safe access.
"""

from __future__ import annotations

import threading
from typing import Any


class ResourceManager:
    """
    Singleton resource manager for thread-safe resource access.

    Manages shared resources like database connections, API clients,
    and provides thread-safe access patterns.
    """

    _instance: ResourceManager | None = None
    _lock: threading.Lock = threading.Lock()
    _initialized: bool = False

    def __new__(cls) -> ResourceManager:
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if ResourceManager._initialized:
            return

        with ResourceManager._lock:
            if ResourceManager._initialized:
                return

            self._resources: dict[str, Any] = {}
            self._resource_locks: dict[str, threading.Lock] = {}
            self._shutdown_event = threading.Event()
            ResourceManager._initialized = True

    def register(self, name: str, resource: Any) -> None:
        """
        Register a resource with the manager.

        Args:
            name: Unique resource name
            resource: Resource instance to manage
        """
        with self._lock:
            self._resources[name] = resource
            self._resource_locks[name] = threading.Lock()

    def get(self, name: str) -> Any | None:
        """
        Get a registered resource.

        Args:
            name: Resource name

        Returns:
            Resource instance or None if not found
        """
        return self._resources.get(name)

    def get_lock(self, name: str) -> threading.Lock | None:
        """
        Get the lock for a specific resource.

        Args:
            name: Resource name

        Returns:
            Lock instance or None if resource not found
        """
        return self._resource_locks.get(name)

    def acquire(self, name: str, blocking: bool = True, timeout: float = -1) -> bool:
        """
        Acquire lock for a resource.

        Args:
            name: Resource name
            blocking: Whether to block waiting for lock
            timeout: Maximum wait time (-1 for infinite)

        Returns:
            True if lock acquired, False otherwise
        """
        lock = self._resource_locks.get(name)
        if lock is None:
            return False
        return lock.acquire(blocking=blocking, timeout=timeout)

    def release(self, name: str) -> None:
        """
        Release lock for a resource.

        Args:
            name: Resource name
        """
        lock = self._resource_locks.get(name)
        if lock is not None:
            try:
                lock.release()
            except RuntimeError:
                pass  # Lock was not held

    def shutdown(self) -> None:
        """Signal shutdown to all waiting threads."""
        self._shutdown_event.set()

    def is_shutdown(self) -> bool:
        """Check if shutdown has been signaled."""
        return self._shutdown_event.is_set()

    def wait_for_shutdown(self, timeout: float | None = None) -> bool:
        """
        Wait for shutdown signal.

        Args:
            timeout: Maximum wait time in seconds

        Returns:
            True if shutdown was signaled, False if timeout
        """
        return self._shutdown_event.wait(timeout=timeout)

    def unregister(self, name: str) -> Any | None:
        """
        Remove a resource from the manager.

        Args:
            name: Resource name

        Returns:
            Removed resource or None if not found
        """
        with self._lock:
            self._resource_locks.pop(name, None)
            return self._resources.pop(name, None)
