"""Repository factory for centralized repository access."""

from collections.abc import Generator
from contextlib import contextmanager

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.attachment_repository import AttachmentRepository
from q21_player._infra.repository.broadcast_repository import BroadcastRepository
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.message_log_repository import MessageLogRepository
from q21_player._infra.repository.pause_state_repository import PauseStateRepository
from q21_player._infra.repository.state_repository import StateRepository
from q21_player._infra.shared.logging.logger import get_logger


class TransactionContext:
    """Context manager for database transactions."""

    def __init__(self, pool: ConnectionPool):
        self._pool = pool
        self._session = None
        self._logger = get_logger("transaction")

    def __enter__(self) -> "TransactionContext":
        self._session = self._pool.get_session()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        if exc_type is not None:
            self._logger.warning(f"Rolling back transaction: {exc_val}")
            self._session.rollback()
            return False
        self._session.commit()
        return True

    @property
    def session(self):
        return self._session


class RepositoryFactory:
    """Factory for creating repository instances with shared connection pool."""

    _instance: "RepositoryFactory | None" = None

    def __init__(self, pool: ConnectionPool | None = None):
        self._pool = pool or ConnectionPool()
        self._logger = get_logger("repository_factory")
        self._game_repo: GameRepository | None = None
        self._state_repo: StateRepository | None = None
        self._attachment_repo: AttachmentRepository | None = None
        self._message_log_repo: MessageLogRepository | None = None
        self._broadcast_repo: BroadcastRepository | None = None
        self._pause_state_repo: PauseStateRepository | None = None

    @classmethod
    def get_instance(cls, pool: ConnectionPool | None = None) -> "RepositoryFactory":
        """Get singleton instance of factory."""
        if cls._instance is None:
            cls._instance = cls(pool)
        return cls._instance

    @classmethod
    def reset_instance(cls) -> None:
        """Reset singleton instance (for testing)."""
        cls._instance = None

    @property
    def pool(self) -> ConnectionPool:
        return self._pool

    def get_game_repository(self) -> GameRepository:
        """Get game repository instance."""
        if self._game_repo is None:
            self._game_repo = GameRepository(self._pool)
        return self._game_repo

    def get_state_repository(self) -> StateRepository:
        """Get state repository instance."""
        if self._state_repo is None:
            self._state_repo = StateRepository(self._pool)
        return self._state_repo

    def get_attachment_repository(self) -> AttachmentRepository:
        """Get attachment repository instance."""
        if self._attachment_repo is None:
            self._attachment_repo = AttachmentRepository(self._pool)
        return self._attachment_repo

    def get_message_log_repository(self) -> MessageLogRepository:
        """Get message log repository instance."""
        if self._message_log_repo is None:
            self._message_log_repo = MessageLogRepository(self._pool)
        return self._message_log_repo

    def get_broadcast_repository(self) -> BroadcastRepository:
        """Get broadcast repository instance."""
        if self._broadcast_repo is None:
            self._broadcast_repo = BroadcastRepository(self._pool)
        return self._broadcast_repo

    def get_pause_state_repository(self) -> PauseStateRepository:
        """Get pause state repository instance."""
        if self._pause_state_repo is None:
            self._pause_state_repo = PauseStateRepository(self._pool)
        return self._pause_state_repo

    @contextmanager
    def transaction(self) -> Generator[TransactionContext, None, None]:
        """Create a transaction context."""
        ctx = TransactionContext(self._pool)
        with ctx:
            yield ctx

    def close(self) -> None:
        """Close connection pool."""
        self._pool.close()
        self._logger.info("Repository factory closed")


def get_repository_factory() -> RepositoryFactory:
    """Get the singleton repository factory."""
    return RepositoryFactory.get_instance()
