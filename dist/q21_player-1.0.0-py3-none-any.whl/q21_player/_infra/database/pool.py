"""
PostgreSQL connection pool for GmailAsPlayer.
"""

import threading
from collections.abc import Generator
from contextlib import contextmanager
from typing import Any, Optional

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from q21_player._infra.shared.config.constants import DB_MAX_OVERFLOW, DB_POOL_SIZE
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.exceptions.repository import DatabaseConnectionError
from q21_player._infra.shared.logging.logger import get_logger


class ConnectionPool:
    """PostgreSQL connection pool using SQLAlchemy."""

    _instance: Optional["ConnectionPool"] = None
    _lock: threading.Lock = threading.Lock()
    _initialized: bool = False

    def __new__(cls) -> "ConnectionPool":
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if ConnectionPool._initialized:
            return
        with ConnectionPool._lock:
            if ConnectionPool._initialized:
                return
            self._logger = get_logger("database.pool")
            self._config = Config()
            self._engine: Engine | None = None
            self._session_factory: sessionmaker | None = None
            ConnectionPool._initialized = True

    def _ensure_database_exists(self) -> None:
        """Create database if it doesn't exist."""
        db = self._config.database
        db_name = db.get("name", "")
        if not db_name:
            return

        # Connect to 'postgres' default database to create target database
        admin_url = f"postgresql://{db['user']}:{db['password']}@{db['host']}:{db['port']}/postgres"
        try:
            admin_engine = create_engine(admin_url, isolation_level="AUTOCOMMIT")
            with admin_engine.connect() as conn:
                result = conn.execute(
                    text("SELECT 1 FROM pg_database WHERE datname = :name"),
                    {"name": db_name}
                )
                if not result.fetchone():
                    conn.execute(text(f'CREATE DATABASE "{db_name}"'))
                    self._logger.info(f"Created database: {db_name}")
            admin_engine.dispose()
        except Exception as e:
            self._logger.warning(f"Could not check/create database: {e}")

    def connect(self, pool_size: int = DB_POOL_SIZE, max_overflow: int = DB_MAX_OVERFLOW) -> None:
        """Initialize the connection pool."""
        # Ensure database exists before connecting
        self._ensure_database_exists()

        try:
            self._engine = create_engine(
                self._config.database_url,
                pool_size=pool_size,
                max_overflow=max_overflow,
                pool_pre_ping=True,
                echo=False,
            )
            self._session_factory = sessionmaker(bind=self._engine)
            self._logger.info(f"Connection pool initialized (size={pool_size})")
        except Exception as e:
            raise DatabaseConnectionError(f"Failed to create pool: {e}") from e

    @property
    def engine(self) -> Engine:
        """Get SQLAlchemy engine."""
        if not self._engine:
            self.connect()
        return self._engine

    @contextmanager
    def session(self) -> Generator[Session, None, None]:
        """Get a database session context manager."""
        if not self._session_factory:
            self.connect()
        session = self._session_factory()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def execute(self, query: str, params: dict | None = None) -> Any:
        """Execute a raw SQL query."""
        with self.session() as session:
            result = session.execute(text(query), params or {})
            return result

    def test_connection(self) -> bool:
        """Test database connectivity."""
        try:
            with self.session() as session:
                session.execute(text("SELECT 1"))
            self._logger.info("Database connection test passed")
            return True
        except Exception as e:
            self._logger.error(f"Database connection test failed: {e}")
            return False

    def close(self) -> None:
        """Close all connections in the pool."""
        if self._engine:
            self._engine.dispose()
            self._logger.info("Connection pool closed")

    @property
    def is_connected(self) -> bool:
        """Check if pool is initialized."""
        return self._engine is not None

    def get_session(self) -> Session:
        """Get a database session (caller responsible for commit/rollback/close)."""
        if not self._session_factory:
            self.connect()
        return self._session_factory()
