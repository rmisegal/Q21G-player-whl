"""
Attachment handler for processing JSON attachments from emails.
"""

import base64
import hashlib
import json
import time
from pathlib import Path
from typing import Any

from q21_player._infra.domain.models.lookup_table import LookupTable
from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.exceptions.gmail import GmailAttachmentError
from q21_player._infra.shared.logging.logger import get_logger
from q21_player._infra.shared.utils.paths import get_attachments_folder


class AttachmentHandler:
    """Handler for extracting and processing JSON attachments."""

    def __init__(
        self, client: GmailClient, lookup_table: LookupTable | None = None
    ) -> None:
        self._client = client
        self._logger = get_logger("gmail.attachment")
        self._attachments_folder = get_attachments_folder()
        self._lookup = lookup_table or LookupTable()

    def extract_attachments(self, message: dict[str, Any]) -> list[dict[str, Any]]:
        """Extract attachment metadata from a message."""
        attachments = []
        payload = message.get("payload", {})
        parts = payload.get("parts", [])

        for part in parts:
            filename = part.get("filename", "")
            if filename and filename.endswith(".json"):
                attachments.append({
                    "filename": filename,
                    "mime_type": part.get("mimeType", ""),
                    "attachment_id": part.get("body", {}).get("attachmentId"),
                    "size": part.get("body", {}).get("size", 0),
                })
        return attachments

    def download_attachment(self, message_id: str, attachment_id: str) -> bytes:
        """Download attachment content by ID."""
        try:
            t0 = time.perf_counter()
            result = self._client.service.users().messages().attachments().get(
                userId="me", messageId=message_id, id=attachment_id
            ).execute()
            self._logger.info(f"[TIMING] attachment:download: {(time.perf_counter()-t0)*1000:.1f}ms")
            data = result.get("data", "")
            return base64.urlsafe_b64decode(data)
        except Exception as e:
            raise GmailAttachmentError(f"Failed to download: {e}") from e

    def parse_json_attachment(
        self, message_id: str, attachment_id: str
    ) -> dict[str, Any]:
        """Download and parse a JSON attachment."""
        try:
            content = self.download_attachment(message_id, attachment_id)
            return json.loads(content.decode("utf-8"))
        except json.JSONDecodeError as e:
            raise GmailAttachmentError(f"Invalid JSON: {e}") from e

    def save_attachment(
        self, message_id: str, attachment_id: str, filename: str
    ) -> Path:
        """Download and save attachment using internal filename."""
        content = self.download_attachment(message_id, attachment_id)
        checksum = hashlib.sha256(content).hexdigest()
        entry = self._lookup.register_attachment(
            original_filename=filename,
            message_id=message_id,
            mime_type="application/json" if filename.endswith(".json") else "",
            size_bytes=len(content),
            checksum=checksum,
        )
        save_path = self._attachments_folder / entry.internal_filename
        save_path.write_bytes(content)
        self._logger.debug(f"Saved: {filename} -> {entry.internal_filename}")
        return save_path

    def get_internal_path(self, original_filename: str) -> Path | None:
        """Get internal file path from original filename."""
        internal = self._lookup.get_internal_by_original(original_filename)
        if internal:
            return self._attachments_folder / internal
        return None

    def get_original_filename(self, internal_filename: str) -> str | None:
        """Get original filename from internal filename."""
        return self._lookup.get_original_by_internal(internal_filename)

    def get_payload_from_message(self, message: dict[str, Any]) -> dict[str, Any] | None:
        """Extract JSON payload from message (first JSON attachment)."""
        message_id = message.get("id", "")
        attachments = self.extract_attachments(message)

        for att in attachments:
            if att.get("attachment_id"):
                try:
                    return self.parse_json_attachment(message_id, att["attachment_id"])
                except GmailAttachmentError as e:
                    self._logger.error(f"Failed to parse attachment: {e}")
        return None

    def cleanup_old_attachments(self, max_age_days: int | None = None) -> int:
        """Remove attachments older than max_age_days."""
        import time
        if max_age_days is None:
            max_age_days = Config().get("gmail.attachment_cleanup_age_days", 7)
        count = 0
        cutoff = time.time() - (max_age_days * 86400)
        for file in self._attachments_folder.glob("*.json"):
            if file.stat().st_mtime < cutoff:
                file.unlink()
                count += 1
        self._logger.info(f"Cleaned up {count} old attachments")
        return count
