# Area: CLI Message Processing
# PRD: docs/LOGGER_OUTPUT_PLAYER.md
"""Logging context setup based on message types."""
import re
from q21_player._infra.repository.assignment_repository import AssignmentRepository
from q21_player._infra.shared.logging.protocol_logger import (
    set_season_context, set_round_context, set_game_context
)


def _normalize_game_id(raw_game_id: str) -> str:
    """Extract SSRRGGG format from various game_id formats.

    Handles:
    - Standard: "0102001" -> "0102001"
    - Training: "TRAIN_2026-02-11_0900_0102001" -> "0102001"
    - Other formats with trailing 7 digits
    """
    if not raw_game_id:
        return ""
    # If already 7 digits, return as-is
    if re.match(r'^\d{7}$', raw_game_id):
        return raw_game_id
    # Extract trailing 7 digits if present
    match = re.search(r'(\d{7})$', raw_game_id)
    if match:
        return match.group(1)
    return raw_game_id  # Return original if no pattern matches


def set_logging_context(
    normalized_type: str,
    game_id: str,
    inner: dict,
    payload: dict,
    assignment_repo: AssignmentRepository,
    gatekeeper_season_id: str | None
) -> None:
    """Set logging context based on message type.

    - Q21 messages (game-level): SSRRGGG, always PLAYER-ACTIVE
    - START-ROUND (round-level): SSRR999, with ACTIVE/INACTIVE role
    - Other messages (season-level): SS99999, no role
    """
    if normalized_type.startswith("Q21"):
        # Game-level: Q21 messages always imply PLAYER-ACTIVE.
        # Normalize game_id to SSRRGGG format.
        normalized_gid = _normalize_game_id(game_id)
        set_game_context(normalized_gid, True)
    elif "NEWLEAGUEROUND" in normalized_type or "STARTROUND" in normalized_type:
        # Round-level: set_round_context constructs SSRR999 internally
        round_number = inner.get("round_number") or payload.get("round_number") or 1
        player_active = False
        if gatekeeper_season_id:
            assignments = assignment_repo.get_by_round(gatekeeper_season_id, round_number)
            if assignments:
                player_active = any(a.my_role for a in assignments)
        set_round_context(round_number, player_active)
    else:
        # Season-level: SS99999, no role
        set_season_context()
