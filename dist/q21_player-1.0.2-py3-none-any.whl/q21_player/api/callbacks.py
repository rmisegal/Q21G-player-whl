"""
Abstract base class for student AI implementations.

Students subclass PlayerAI and implement all 4 callback methods.
"""

from abc import ABC, abstractmethod


class PlayerAI(ABC):
    """
    Abstract base class for Q21 Player AI.

    Students must implement all 4 methods:
    - get_warmup_answer: Answer the warmup question
    - get_questions: Generate 20 multiple-choice questions
    - get_guess: Guess opening sentence and associative word
    - on_score_received: Handle final score notification
    """

    @abstractmethod
    def get_warmup_answer(self, ctx: dict) -> dict:
        """
        Answer the warmup question.

        Args:
            ctx: Context with dynamic.warmup_question and service info

        Returns:
            dict with "answer" key
        """
        ...

    @abstractmethod
    def get_questions(self, ctx: dict) -> dict:
        """
        Generate 20 multiple-choice questions.

        Args:
            ctx: Context with dynamic.book_name, book_hint, association_word

        Returns:
            dict with "questions" list (20 items, each with
            question_number, question_text, options with A/B/C/D)
        """
        ...

    @abstractmethod
    def get_guess(self, ctx: dict) -> dict:
        """
        Guess the opening sentence and associative word.

        Args:
            ctx: Context with dynamic.answers (20 items) and book info

        Returns:
            dict with opening_sentence, sentence_justification (30-50 words),
            associative_word, word_justification (20-30 words), confidence (0-1)
        """
        ...

    @abstractmethod
    def on_score_received(self, ctx: dict) -> None:
        """
        Handle final score notification.

        Args:
            ctx: Context with dynamic.league_points, private_score, breakdown
        """
        ...
