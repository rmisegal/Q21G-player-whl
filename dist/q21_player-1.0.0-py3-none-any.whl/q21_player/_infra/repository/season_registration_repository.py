"""Season registration repository for tracking season enrollments."""

from datetime import UTC, datetime

from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import SeasonRegistrationModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class SeasonRegistrationRepository(BaseRepository[SeasonRegistrationModel]):
    """Repository for season registration operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(SeasonRegistrationModel, pool)

    def save_registration(
        self, season_id: str, league_id: str | None = None, season_name: str | None = None
    ) -> SeasonRegistrationModel:
        """Save a new season registration with PENDING status."""
        return self.create(SeasonRegistrationModel(
            season_id=season_id,
            league_id=league_id,
            season_name=season_name,
            registration_status="PENDING",
        ))

    def get_by_season_id(self, season_id: str) -> SeasonRegistrationModel | None:
        """Get registration by season ID."""
        session = self._get_session()
        try:
            return session.query(SeasonRegistrationModel).filter_by(season_id=season_id).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by season_id failed: {e}")
            raise RepositoryError(f"Failed to get registration: {e}") from e

    def update_status(
        self, season_id: str, status: str, rejection_reason: str | None = None
    ) -> bool:
        """Update registration status."""
        model = self.get_by_season_id(season_id)
        if not model:
            return False
        model.registration_status = status
        if status == "CONFIRMED":
            model.confirmed_at = datetime.now(UTC)
        if rejection_reason:
            model.rejection_reason = rejection_reason
        self.update(model)
        return True

    def get_pending(self) -> list[SeasonRegistrationModel]:
        """Get all PENDING registrations."""
        session = self._get_session()
        try:
            return session.query(SeasonRegistrationModel).filter_by(
                registration_status="PENDING"
            ).order_by(SeasonRegistrationModel.registered_at.desc()).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get pending failed: {e}")
            raise RepositoryError(f"Failed to get pending registrations: {e}") from e

    def get_confirmed(self) -> list[SeasonRegistrationModel]:
        """Get all CONFIRMED registrations."""
        session = self._get_session()
        try:
            return session.query(SeasonRegistrationModel).filter_by(
                registration_status="CONFIRMED"
            ).order_by(SeasonRegistrationModel.confirmed_at.desc()).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get confirmed failed: {e}")
            raise RepositoryError(f"Failed to get confirmed registrations: {e}") from e
