"""Manual handler for single action mode."""

from q21_player._infra.domain.services.message_service import MessageService
from q21_player._infra.domain.services.player_service import PlayerService
from q21_player._infra.domain.services.state_machine import PlayerStateMachine
from q21_player._infra.domain.services.strategy_service import StrategyService
from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.gmail.scanner import GmailScanner
from q21_player._infra.gmail.sender import GmailSender
from q21_player._infra.shared.config.constants import SINGLE_SCAN_RESULTS
from q21_player._infra.shared.logging.logger import get_logger


class ManualHandler:
    """Handler for single manual actions without continuous polling."""

    def __init__(
        self,
        player_email: str,
        player_name: str,
        strategy_type: str = "llm",
        dry_run: bool = False,
    ):
        self._logger = get_logger("manual_handler")
        self._player_email = player_email
        self._player_name = player_name
        self._dry_run = dry_run
        self._gmail_client = GmailClient()
        self._scanner = GmailScanner(self._gmail_client)
        self._sender = GmailSender(self._gmail_client)
        self._state_machine = PlayerStateMachine()
        self._message_service = MessageService(self._state_machine)
        self._strategy_service = StrategyService(preferred_strategy=strategy_type)
        self._player_service = PlayerService(
            self._state_machine, self._message_service, self._strategy_service
        )

    def initialize(self) -> bool:
        """Initialize Gmail client."""
        if not self._gmail_client.authenticate():
            self._logger.error("Gmail authentication failed")
            return False
        self._player_service.initialize(self._player_email, self._player_name)
        return True

    def process_one(self) -> dict:
        """Process a single message and return result."""
        result = {"processed": 0, "responses_sent": 0, "errors": []}
        try:
            messages = self._scanner.scan(max_results=SINGLE_SCAN_RESULTS)
            if not messages:
                self._logger.info("No messages to process")
                return result
            msg = messages[0]
            result["processed"] = 1
            response = self._player_service.process_message(msg)
            if response:
                if self._dry_run:
                    self._logger.info("[DRY RUN] Would send response")
                else:
                    self._sender.send(response)
                    result["responses_sent"] = 1
        except Exception as e:
            result["errors"].append(str(e))
            self._logger.error(f"Error processing message: {e}")
        return result

    def process_all_pending(self) -> dict:
        """Process all pending messages."""
        result = {"processed": 0, "responses_sent": 0, "errors": []}
        try:
            messages = self._scanner.scan()
            for msg in messages:
                try:
                    result["processed"] += 1
                    response = self._player_service.process_message(msg)
                    if response:
                        if self._dry_run:
                            self._logger.info("[DRY RUN] Would send response")
                        else:
                            self._sender.send(response)
                            result["responses_sent"] += 1
                except Exception as e:
                    result["errors"].append(str(e))
                    self._logger.error(f"Error processing message: {e}")
        except Exception as e:
            result["errors"].append(str(e))
            self._logger.error(f"Scan error: {e}")
        return result

    def get_status(self) -> dict:
        """Get current player status."""
        return {
            "player_email": self._player_email,
            "player_name": self._player_name,
            "current_state": self._player_service.current_state.value,
            "dry_run": self._dry_run,
        }
