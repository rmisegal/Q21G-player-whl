"""
Email subject parser and generator.

Parses and generates Q21 protocol email subjects.
"""

PROTOCOL_PREFIX = "Q21G.v1"
DELIMITER = "::"
EXPECTED_FIELDS = 5


def parse_subject(subject: str) -> dict | None:
    """
    Parse an email subject line into components.

    Subject format: protocol::role::email::tx_id::message_type

    Args:
        subject: The email subject line

    Returns:
        Dict with parsed fields or None if invalid
    """
    if not subject:
        return None

    parts = subject.split(DELIMITER)
    if len(parts) != EXPECTED_FIELDS:
        return None

    protocol = parts[0]
    if not protocol.startswith("Q21"):
        return None

    return {
        "protocol": parts[0],
        "role": parts[1],
        "email": parts[2],
        "tx_id": parts[3],
        "message_type": parts[4],
    }


def generate_subject(
    protocol: str,
    role: str,
    email: str,
    tx_id: str,
    message_type: str,
) -> str:
    """
    Generate an email subject line from components.

    Args:
        protocol: Protocol version (e.g., Q21G.v1)
        role: Sender role (PLAYER or REFEREE)
        email: Sender email address
        tx_id: Transaction ID
        message_type: Q21 message type

    Returns:
        Formatted subject line
    """
    return DELIMITER.join([protocol, role, email, tx_id, message_type])
