"""
Dependency Injection module for GmailAsPlayer.

Provides:
- DIContainer: Singleton container for dependency injection
"""

from q21_player._infra.shared.di.container import DIContainer

__all__ = [
    "DIContainer",
]
