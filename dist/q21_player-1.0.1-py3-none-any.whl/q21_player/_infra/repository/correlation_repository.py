"""Correlation repository for tracking message request-response pairs."""

from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import MessageCorrelationModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class CorrelationRepository(BaseRepository[MessageCorrelationModel]):
    """Repository for message correlation operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(MessageCorrelationModel, pool)

    def save_correlation(
        self,
        request_type: str,
        request_id: str,
        response_type: str | None = None,
        response_id: str | None = None,
        request_gmail_id: str | None = None,
        response_gmail_id: str | None = None,
    ) -> MessageCorrelationModel:
        """Save a message correlation record."""
        model = MessageCorrelationModel(
            request_type=request_type,
            request_id=request_id,
            request_gmail_id=request_gmail_id,
            response_type=response_type,
            response_id=response_id,
            response_gmail_id=response_gmail_id,
        )
        return self.create(model)

    def get_by_request_id(self, request_id: str) -> MessageCorrelationModel | None:
        """Get correlation by request ID."""
        session = self._get_session()
        try:
            return (session.query(MessageCorrelationModel)
                    .filter_by(request_id=request_id)
                    .first())
        except SQLAlchemyError as e:
            self._logger.error(f"Get by request_id failed: {e}")
            raise RepositoryError(f"Failed to get correlation: {e}") from e

    def get_by_response_id(self, response_id: str) -> MessageCorrelationModel | None:
        """Get correlation by response ID."""
        session = self._get_session()
        try:
            return (session.query(MessageCorrelationModel)
                    .filter_by(response_id=response_id)
                    .first())
        except SQLAlchemyError as e:
            self._logger.error(f"Get by response_id failed: {e}")
            raise RepositoryError(f"Failed to get correlation: {e}") from e

    def update_response_gmail_id(
        self, response_id: str, gmail_id: str
    ) -> bool:
        """Update the Gmail ID for a response."""
        model = self.get_by_response_id(response_id)
        if not model:
            return False
        model.response_gmail_id = gmail_id
        self.update(model)
        self._logger.info(f"Correlation {response_id} gmail_id updated")
        return True
