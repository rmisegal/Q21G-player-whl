"""Attachment entry dataclass for file lookup."""

from dataclasses import dataclass, field
from datetime import UTC, datetime


@dataclass
class AttachmentEntry:
    """Entry representing an attachment with original and internal filenames."""

    original_filename: str
    internal_filename: str
    message_id: str
    mime_type: str = ""
    size_bytes: int = 0
    checksum: str = ""
    created_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "original_filename": self.original_filename,
            "internal_filename": self.internal_filename,
            "message_id": self.message_id,
            "mime_type": self.mime_type,
            "size_bytes": self.size_bytes,
            "checksum": self.checksum,
            "created_at": self.created_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "AttachmentEntry":
        """Create from dictionary."""
        created = data.get("created_at")
        if isinstance(created, str):
            created = datetime.fromisoformat(created)
        return cls(
            original_filename=data["original_filename"],
            internal_filename=data["internal_filename"],
            message_id=data["message_id"],
            mime_type=data.get("mime_type", ""),
            size_bytes=data.get("size_bytes", 0),
            checksum=data.get("checksum", ""),
            created_at=created or datetime.now(UTC),
        )
