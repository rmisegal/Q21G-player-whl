"""Standings repository for tracking season standings."""

from sqlalchemy import func
from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import StandingsModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class StandingsRepository(BaseRepository[StandingsModel]):
    """Repository for standings operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(StandingsModel, pool)

    def save_standings(self, season_id: str, round_number: int, standings: list[dict]) -> int:
        """Bulk insert/update standings. Returns count of records processed."""
        session = self._get_session()
        count = 0
        try:
            for s in standings:
                group_id = s.get("group_id")
                existing = session.query(StandingsModel).filter_by(
                    season_id=season_id, round_number=round_number, group_id=group_id
                ).first()
                if existing:
                    existing.total_score = s.get("total_score", existing.total_score)
                    existing.games_played = s.get("games_played", existing.games_played)
                    existing.games_won = s.get("games_won", existing.games_won)
                    existing.rank = s.get("rank", existing.rank)
                else:
                    session.add(StandingsModel(
                        season_id=season_id, round_number=round_number, group_id=group_id,
                        total_score=s.get("total_score", 0), games_played=s.get("games_played", 0),
                        games_won=s.get("games_won", 0), rank=s.get("rank"),
                    ))
                count += 1
            session.commit()
            return count
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Save standings failed: {e}")
            raise RepositoryError(f"Failed to save standings: {e}") from e

    def get_by_season(self, season_id: str) -> list[StandingsModel]:
        """Get all standings for a season."""
        session = self._get_session()
        try:
            return session.query(StandingsModel).filter_by(season_id=season_id).order_by(
                StandingsModel.round_number, StandingsModel.rank
            ).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by season failed: {e}")
            raise RepositoryError(f"Failed to get standings: {e}") from e

    def get_by_round(self, season_id: str, round_number: int) -> list[StandingsModel]:
        """Get standings filtered by round."""
        session = self._get_session()
        try:
            return session.query(StandingsModel).filter_by(
                season_id=season_id, round_number=round_number
            ).order_by(StandingsModel.rank).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by round failed: {e}")
            raise RepositoryError(f"Failed to get standings: {e}") from e

    def get_my_standing(self, season_id: str, round_number: int, group_id: str) -> StandingsModel | None:
        """Get own group's standing for a round."""
        session = self._get_session()
        try:
            return session.query(StandingsModel).filter_by(
                season_id=season_id, round_number=round_number, group_id=group_id
            ).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get my standing failed: {e}")
            raise RepositoryError(f"Failed to get standing: {e}") from e

    def get_latest_round(self, season_id: str) -> int | None:
        """Get the latest round number for a season."""
        session = self._get_session()
        try:
            result = session.query(func.max(StandingsModel.round_number)).filter_by(
                season_id=season_id
            ).scalar()
            return result
        except SQLAlchemyError as e:
            self._logger.error(f"Get latest round failed: {e}")
            raise RepositoryError(f"Failed to get latest round: {e}") from e
