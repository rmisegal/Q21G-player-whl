"""SQLAlchemy ORM models - re-exports from split modules."""
# Core models with relationships
from q21_player._infra.repository.orm_core_models import (
    AnswerModel,
    Base,
    GameSessionModel,
    GuessModel,
    PlayerStateModel,
    QuestionModel,
)

# Message and logging models
from q21_player._infra.repository.orm_message_models import (
    AttachmentModel,
    BroadcastReceivedModel,
    ErrorLogModel,
    MessageCorrelationModel,
    MessageLogModel,
    PauseStateModel,
    StateTransitionModel,
)

# Season, assignment, and game state models
from q21_player._infra.repository.orm_season_models import (
    AssignmentModel,
    GameInvitationModel,
    GameResultModel,
    GameStateModel,
    SeasonRegistrationModel,
    StandingsModel,
)

__all__ = [
    # Core
    "Base",
    "PlayerStateModel",
    "GameSessionModel",
    "QuestionModel",
    "AnswerModel",
    "GuessModel",
    # Message
    "AttachmentModel",
    "MessageLogModel",
    "BroadcastReceivedModel",
    "PauseStateModel",
    "StateTransitionModel",
    "MessageCorrelationModel",
    "ErrorLogModel",
    # Season
    "SeasonRegistrationModel",
    "AssignmentModel",
    "StandingsModel",
    "GameStateModel",
    "GameResultModel",
    "GameInvitationModel",
]
