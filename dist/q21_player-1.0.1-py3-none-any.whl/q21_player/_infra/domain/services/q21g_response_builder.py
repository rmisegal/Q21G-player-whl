"""league.v2 response builder for player responses to referee messages."""
import uuid
from datetime import UTC, datetime
from typing import Any

from q21_player._infra.domain.models.envelope import Envelope
from q21_player._infra.domain.models.messages import OutgoingMessage
from q21_player._infra.shared.config.constants import DEFAULT_SENDER_ROLE, PROTOCOL_VERSION, Q21G_ATTACHMENT_NAME
from q21_player._infra.shared.utils.helpers import generate_transaction_id


class Q21GResponseBuilder:
    """Builds league.v2 format responses for player messages."""

    PROTOCOL = PROTOCOL_VERSION
    ROLE = DEFAULT_SENDER_ROLE
    ATTACHMENT_NAME = Q21G_ATTACHMENT_NAME

    def build_warmup_response(
        self, player_email: str, match_id: str, answer: str, auth_token: str, referee_email: str,
        correlation_id: str | None = None, logical_id: str | None = None,
    ) -> OutgoingMessage:
        """Build Q21_WARMUP_RESPONSE message with answer to warmup question."""
        msg_type = "Q21_WARMUP_RESPONSE"
        inner_payload = {"match_id": match_id, "auth_token": auth_token, "answer": answer}
        return self._build_message(msg_type, player_email, match_id, inner_payload, referee_email, correlation_id, logical_id)

    def build_questions_batch(
        self, player_email: str, match_id: str, questions: list[dict],
        auth_token: str, referee_email: str, correlation_id: str | None = None, logical_id: str | None = None,
    ) -> OutgoingMessage:
        """Build Q21_QUESTIONS_BATCH message with 20 MC questions."""
        msg_type = "Q21_QUESTIONS_BATCH"
        inner_payload = {"match_id": match_id, "auth_token": auth_token, "questions": questions, "total_questions": len(questions)}
        return self._build_message(msg_type, player_email, match_id, inner_payload, referee_email, correlation_id, logical_id)

    def build_guess_submission(
        self, player_email: str, match_id: str, opening_sentence: str, sentence_justification: str,
        associative_word: str, word_justification: str, auth_token: str, referee_email: str,
        confidence: float = 0.5, correlation_id: str | None = None, logical_id: str | None = None,
    ) -> OutgoingMessage:
        """Build Q21_GUESS_SUBMISSION message per UNIFIED_PROTOCOL.md."""
        msg_type = "Q21_GUESS_SUBMISSION"
        inner_payload = {
            "match_id": match_id, "auth_token": auth_token, "opening_sentence": opening_sentence,
            "sentence_justification": sentence_justification, "associative_word": associative_word,
            "word_justification": word_justification, "confidence": confidence,
        }
        return self._build_message(msg_type, player_email, match_id, inner_payload, referee_email, correlation_id, logical_id)

    def build_game_join_ack(
        self, player_email: str, match_id: str, referee_email: str,
        correlation_id: str | None = None, logical_id: str | None = None,
    ) -> OutgoingMessage:
        """Build GAME_JOIN_ACK message."""
        msg_type = "GAME_JOIN_ACK"
        inner_payload = {"match_id": match_id, "acknowledged": True}
        return self._build_message(msg_type, player_email, match_id, inner_payload, referee_email, correlation_id, logical_id)

    def _build_message(
        self, msg_type: str, player_email: str, match_id: str, inner_payload: dict[str, Any],
        referee_email: str, correlation_id: str | None = None, logical_id: str | None = None,
    ) -> OutgoingMessage:
        """Build OutgoingMessage with league.v2 wrapper format."""
        envelope = self._build_envelope(player_email, referee_email, msg_type, logical_id)
        wrapper = self._build_wrapper(msg_type, player_email, match_id, inner_payload, referee_email, correlation_id, logical_id)
        return OutgoingMessage(envelope=envelope, payload=wrapper, body_text=f"{msg_type} response", attachment_name=self.ATTACHMENT_NAME)

    def _build_envelope(self, player_email: str, referee_email: str, msg_type: str, logical_id: str | None = None) -> Envelope:
        """Build league.v2 envelope: league.v2::PLAYER::{email}::{txid}::{msg_type}."""
        return Envelope(
            protocol_version=self.PROTOCOL, sender_role=self.ROLE, sender_email=player_email,
            sender_logical_id=logical_id, recipient_email=referee_email,
            transaction_id=generate_transaction_id("tx"), message_type=msg_type, raw_message_type=msg_type,
        )

    def _build_wrapper(
        self, msg_type: str, player_email: str, match_id: str, payload: dict[str, Any],
        referee_email: str, correlation_id: str | None = None, logical_id: str | None = None,
    ) -> dict[str, Any]:
        """Build league.v2 JSON wrapper per UNIFIED_PROTOCOL.md Section 2."""
        wrapper: dict[str, Any] = {
            "protocol": self.PROTOCOL, "message_type": msg_type, "message_id": str(uuid.uuid4()),
            "sender": {"email": player_email, "role": self.ROLE, "logical_id": logical_id},
            "recipient_id": referee_email, "timestamp": datetime.now(UTC).isoformat(),
            "game_id": match_id, "payload": payload,
        }
        if correlation_id:
            wrapper["correlation_id"] = correlation_id
        return wrapper
