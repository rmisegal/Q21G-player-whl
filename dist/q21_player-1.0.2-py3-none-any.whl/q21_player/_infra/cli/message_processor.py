"""Message processor for handling different message types."""
from typing import Any

from q21_player._infra.domain.models.messages import OutgoingMessage
from q21_player._infra.domain.services.broadcast_response_builder import BroadcastResponseBuilder
from q21_player._infra.repository.correlation_repository import CorrelationRepository
from q21_player._infra.repository.state_repository import StateRepository
from q21_player._infra.shared.config.constants import MessageType, PlayerState
from q21_player._infra.shared.logging.logger import get_logger

HANDLED_TYPES = {"BROADCASTKEEPALIVE", "BROADCASTSTARTSEASON", "BROADCASTFREETEXT",
                 "BROADCASTCRITICALRESET", "BROADCASTCRITICALPAUSE", "BROADCASTCRITICALCONTINUE"}


class MessageProcessor:
    """Processes incoming messages and builds responses."""

    def __init__(self, builder: BroadcastResponseBuilder | None = None, correlation_repo: CorrelationRepository | None = None,
                 state_repo: StateRepository | None = None, player_email: str | None = None):
        self._logger = get_logger("message_processor")
        self._builder, self._correlation_repo = builder or BroadcastResponseBuilder(), correlation_repo
        self._state_repo, self._player_email = state_repo, player_email

    def can_handle(self, msg_type: str) -> bool:
        # Normalize by removing underscores to handle both BROADCAST_KEEP_ALIVE and BROADCASTKEEPALIVE formats
        return msg_type.replace("_", "") in HANDLED_TYPES

    def process(self, msg_type: str, payload: dict, sender_email: str | None = None) -> OutgoingMessage | None:
        normalized = msg_type.replace("_", "").upper()
        if "STARTSEASON" in normalized:
            info = self.extract_season_info(payload)
            self._update_season_context(info)
            self._set_waiting_for_confirmation()
            return self.process_broadcast_start_season(broadcast_id=info["broadcast_id"], season_id=info["season_id"], season_name=info["season_name"], recipient_email=sender_email)
        if "KEEPALIVE" in normalized:
            broadcast_id = payload.get("payload", {}).get("broadcast_id")
            if broadcast_id:
                return self._builder.build_keep_alive_response(broadcast_id=broadcast_id, machine_state="REGISTERED", state_detail="Active", message_text="Keep-alive acknowledged", recipient_email=sender_email)
        return None

    def process_broadcast_start_season(self, broadcast_id: str, season_id: str, season_name: str, recipient_email: str | None = None) -> OutgoingMessage:
        self._logger.info(f"Processing start season: {season_name} ({season_id})")
        return self._builder.build_season_registration_request(broadcast_id=broadcast_id, season_id=season_id, season_name=season_name, recipient_email=recipient_email)

    def _update_season_context(self, info: dict) -> None:
        if self._state_repo and self._player_email:
            self._state_repo.update_season_context(self._player_email, info.get("league_id", ""), info.get("season_id", ""), info.get("round_id"))

    def _set_waiting_for_confirmation(self) -> None:
        if self._state_repo and self._player_email:
            self._state_repo.update_state_only(self._player_email, PlayerState.WAITING_FOR_CONFIRMATION)

    def extract_season_info(self, payload: dict) -> dict[str, Any]:
        inner = payload.get("payload", {})
        return {"broadcast_id": inner.get("broadcast_id", ""), "season_id": inner.get("season_id", ""),
                "season_name": inner.get("season_name", ""), "league_id": payload.get("leagueid", ""), "round_id": inner.get("round_id")}

    def update_player_state(self, league_id: str, season_id: str, round_id: str | None = None) -> bool:
        if not self._state_repo or not self._player_email: return False
        return self._state_repo.update_season_context(self._player_email, league_id, season_id, round_id)

    def save_correlation(self, request_type: str, request_id: str, response_type: str, response_id: str,
                         request_gmail_id: str | None = None, response_gmail_id: str | None = None) -> bool:
        if not self._correlation_repo:
            self._logger.warning("No correlation repository - skipping save"); return False
        try:
            self._correlation_repo.save_correlation(request_type=request_type, request_id=request_id, response_type=response_type,
                response_id=response_id, request_gmail_id=request_gmail_id, response_gmail_id=response_gmail_id)
            self._logger.info(f"Correlation saved: {request_id} -> {response_id}"); return True
        except Exception as e:
            self._logger.error(f"Failed to save correlation: {e}"); return False

    def create_correlation(self, request_type: str, request_id: str, response_type: str, response_id: str) -> dict[str, str]:
        return {"request_type": request_type, "request_id": request_id, "response_type": response_type, "response_id": response_id}
