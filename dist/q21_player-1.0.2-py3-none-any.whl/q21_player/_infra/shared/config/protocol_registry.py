"""Protocol registry for loading and managing protocol configurations."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from q21_player._infra.shared.config.protocol_config import ProtocolConfig
from q21_player._infra.shared.logging.logger import get_logger

if TYPE_CHECKING:
    pass

# Singleton instance
_default_registry: "ProtocolRegistry | None" = None


def get_default_registry() -> "ProtocolRegistry":
    """Get or create the default protocol registry from protocols/ directory."""
    global _default_registry
    if _default_registry is None:
        protocols_dir = Path(__file__).parent.parent.parent.parent / "protocols"
        _default_registry = ProtocolRegistry(protocols_dir)
    return _default_registry


class ProtocolRegistry:
    """Registry for loading and managing protocol configurations."""

    def __init__(self, protocols_dir: Path | str | None = None):
        """Initialize registry and optionally load protocols from directory."""
        self._logger = get_logger("protocol_registry")
        self._protocols: dict[str, ProtocolConfig] = {}
        if protocols_dir:
            self.load_protocols(protocols_dir)

    @property
    def protocols(self) -> dict[str, ProtocolConfig]:
        """Get all loaded protocol configurations."""
        return self._protocols

    def load_protocols(self, protocols_dir: Path | str) -> None:
        """Load all protocol JSON files from directory."""
        path = Path(protocols_dir)
        if not path.exists():
            self._logger.warning(f"Protocols directory not found: {path}")
            return
        for json_file in path.glob("*.json"):
            try:
                config = ProtocolConfig.from_json_file(json_file)
                self._protocols[config.protocol_id] = config
                self._logger.debug(f"Loaded protocol: {config.protocol_id}")
            except Exception as e:
                self._logger.error(f"Failed to load protocol {json_file}: {e}")

    def detect_protocol(self, subject: str) -> str | None:
        """Detect protocol from subject line prefix."""
        if not subject:
            return None
        parts = subject.split("::")
        if not parts:
            return None
        protocol_id = parts[0]
        if protocol_id in self._protocols:
            return protocol_id
        return None

    def get_protocol_config(self, protocol_id: str) -> ProtocolConfig | None:
        """Get protocol configuration by ID."""
        return self._protocols.get(protocol_id)

    def get_handler_name(self, protocol_id: str, message_type: str) -> str | None:
        """Get handler name for protocol and message type."""
        config = self._protocols.get(protocol_id)
        if not config:
            return None
        return config.get_handler_name(message_type)

    def normalize_message_type(self, protocol_id: str, message_type: str) -> str:
        """Normalize message type using protocol aliases."""
        config = self._protocols.get(protocol_id)
        if not config:
            return message_type
        return config.normalize_message_type(message_type)

    def is_broadcast_type(self, protocol_id: str, message_type: str) -> bool:
        """Check if message type is a broadcast for given protocol."""
        config = self._protocols.get(protocol_id)
        if not config:
            return False
        return config.is_broadcast_type(message_type)

    def get_all_protocol_ids(self) -> list[str]:
        """Get list of all loaded protocol IDs."""
        return list(self._protocols.keys())

    def register_protocol(self, config: ProtocolConfig) -> None:
        """Register a protocol configuration manually."""
        self._protocols[config.protocol_id] = config

    def get_response_type(self, protocol_id: str, message_type: str) -> str | None:
        """Get expected response type for a message type."""
        config = self._protocols.get(protocol_id)
        if not config:
            return None
        return config.get_response_type(message_type)
