"""Error log repository for tracking application errors."""

from datetime import UTC, datetime

from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import ErrorLogModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class ErrorLogRepository(BaseRepository[ErrorLogModel]):
    """Repository for error log operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(ErrorLogModel, pool)

    def log_error(
        self,
        error_type: str,
        error_message: str,
        context: dict | None = None,
        stack_trace: str | None = None,
        error_code: str | None = None,
    ) -> ErrorLogModel:
        """Log a new error entry."""
        return self.create(ErrorLogModel(
            error_type=error_type,
            error_code=error_code,
            error_message=error_message,
            context=context,
            stack_trace=stack_trace,
        ))

    def get_unresolved(self, limit: int = 50) -> list[ErrorLogModel]:
        """Get all unresolved errors."""
        session = self._get_session()
        try:
            return (session.query(ErrorLogModel)
                    .filter(ErrorLogModel.resolved_at.is_(None))
                    .order_by(ErrorLogModel.created_at.desc())
                    .limit(limit).all())
        except SQLAlchemyError as e:
            self._logger.error(f"Get unresolved errors failed: {e}")
            raise RepositoryError(f"Failed to get unresolved errors: {e}") from e

    def mark_resolved(
        self, error_id: int, resolution_notes: str | None = None
    ) -> bool:
        """Mark an error as resolved."""
        model = self.get_by_id(error_id)
        if not model:
            return False
        model.resolved_at = datetime.now(UTC)
        model.resolution_notes = resolution_notes
        self.update(model)
        return True

    def get_by_type(
        self, error_type: str, include_resolved: bool = False, limit: int = 50
    ) -> list[ErrorLogModel]:
        """Get errors filtered by type."""
        session = self._get_session()
        try:
            query = session.query(ErrorLogModel).filter_by(error_type=error_type)
            if not include_resolved:
                query = query.filter(ErrorLogModel.resolved_at.is_(None))
            return query.order_by(ErrorLogModel.created_at.desc()).limit(limit).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by type failed: {e}")
            raise RepositoryError(f"Failed to get errors by type: {e}") from e
