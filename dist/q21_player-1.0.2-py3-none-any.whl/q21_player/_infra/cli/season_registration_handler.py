"""Season registration response handler."""

from datetime import UTC, datetime

from q21_player._infra.repository.state_repository import StateRepository
from q21_player._infra.shared.config.constants import PlayerState
from q21_player._infra.shared.logging.logger import get_logger

logger = get_logger("season_registration_handler")


class SeasonRegistrationHandler:
    """Handles SEASON_REGISTRATION_RESPONSE messages from the server."""

    def __init__(self, state_repo: StateRepository, player_email: str):
        self._state_repo = state_repo
        self._player_email = player_email

    def process(self, payload: dict) -> tuple[bool, str]:
        """Process season registration response.

        Args:
            payload: The full message payload from server.

        Returns:
            Tuple of (success, reason).
            - On ACCEPTED: (True, "")
            - On REJECTED: (False, rejection_reason)
            - On error: (False, error_message)
        """
        inner = payload.get("payload", {})
        if not inner:
            logger.error("Missing payload in season registration response")
            return False, "Missing payload"

        status = inner.get("status", "").upper()

        if status == "ACCEPTED":
            return self._handle_accepted(inner)
        elif status == "REJECTED":
            return self._handle_rejected(inner)
        else:
            logger.warning(f"Unknown registration status: {status}")
            return False, f"Unknown status: {status}"

    def _handle_accepted(self, inner: dict) -> tuple[bool, str]:
        """Handle ACCEPTED registration response."""
        season_id = inner.get("season_id", "")
        registration_id = inner.get("registration_id", "")

        logger.info(f"Season registration ACCEPTED: season={season_id}, reg_id={registration_id}")

        # Update state to REGISTERED
        self._state_repo.update_state_only(self._player_email, PlayerState.REGISTERED)

        # Save registration
        self._state_repo.save_registration(
            self._player_email,
            registration_id,
            datetime.now(UTC)
        )

        return True, ""

    def _handle_rejected(self, inner: dict) -> tuple[bool, str]:
        """Handle REJECTED registration response."""
        reason = inner.get("reason", "Registration rejected")

        logger.warning(f"Season registration REJECTED: {reason}")

        # Update state to SEASON_REJECTED
        self._state_repo.update_state_only(self._player_email, PlayerState.SEASON_REJECTED)

        return False, reason
