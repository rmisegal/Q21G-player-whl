"""SDK strategy that delegates to PlayerAI callbacks."""

from q21_player.api.callbacks import PlayerAI
from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.domain.models.guess import Guess
from q21_player._infra.domain.models.question import Question, QuestionBatch, QuestionOptions
from q21_player._infra.shared.logging.logger import get_logger
from q21_player._infra.shared.logging.protocol_logger import log_callback_call, log_callback_response
from q21_player._infra.strategy.base_strategy import IGameStrategy, StrategyResult

logger = get_logger("sdk_strategy")


class SDKStrategy(IGameStrategy):
    """Strategy that delegates to SDK PlayerAI callbacks."""

    def __init__(self, player_ai: PlayerAI):
        """Initialize with a PlayerAI implementation."""
        self._ai = player_ai

    @property
    def name(self) -> str:
        return "sdk"

    def generate_questions(self, context: GameContext) -> StrategyResult:
        """Generate questions by calling PlayerAI.get_questions()."""
        try:
            ctx = self._build_questions_context(context)
            log_callback_call("get_questions")
            result = self._ai.get_questions(ctx)
            log_callback_response("get_questions")
            batch = self._convert_questions_result(result, context.game_id)
            return StrategyResult(success=True, data=batch, confidence=0.8)
        except Exception as e:
            log_callback_response("get_questions")
            logger.error(f"SDK generate_questions failed: {e}")
            return StrategyResult(success=False, error=str(e))

    def formulate_guess(self, context: GameContext) -> StrategyResult:
        """Formulate guess by calling PlayerAI.get_guess()."""
        try:
            ctx = self._build_guess_context(context)
            log_callback_call("get_guess")
            result = self._ai.get_guess(ctx)
            log_callback_response("get_guess")
            guess = self._convert_guess_result(result, context.game_id)
            return StrategyResult(success=True, data=guess, confidence=result.get("confidence", 0.5))
        except Exception as e:
            log_callback_response("get_guess")
            logger.error(f"SDK formulate_guess failed: {e}")
            return StrategyResult(success=False, error=str(e))

    def get_warmup_answer(self, question: str) -> str:
        """Get warmup answer by calling PlayerAI.get_warmup_answer()."""
        try:
            ctx = {"dynamic": {"warmup_question": question}, "service": {}}
            log_callback_call("get_warmup_answer")
            result = self._ai.get_warmup_answer(ctx)
            log_callback_response("get_warmup_answer")
            answer = result.get("answer", "0")
            return str(answer)
        except Exception as e:
            log_callback_response("get_warmup_answer")
            logger.error(f"SDK get_warmup_answer failed: {e}")
            return "0"

    def _build_questions_context(self, context: GameContext) -> dict:
        """Convert GameContext to SDK questions context."""
        return {
            "dynamic": {
                "book_name": context.book_name,
                "book_hint": context.general_description,
                "association_word": context.associative_domain,
            },
            "service": {"game_id": context.game_id, "match_id": context.match_id},
        }

    def _build_guess_context(self, context: GameContext) -> dict:
        """Convert GameContext to SDK guess context."""
        answers = [
            {"question_number": qa["number"], "answer": qa["answer"]}
            for qa in context.question_history
        ]
        return {
            "dynamic": {
                "book_name": context.book_name,
                "book_hint": context.general_description,
                "association_word": context.associative_domain,
                "answers": answers,
                "questions_sent": [],
            },
            "service": {"game_id": context.game_id, "match_id": context.match_id},
        }

    def _convert_questions_result(self, result: dict, game_id: str) -> QuestionBatch:
        """Convert SDK questions result to QuestionBatch."""
        raw_questions = result.get("questions", [])
        questions = []
        for q in raw_questions[:20]:
            opts = q.get("options", {})
            questions.append(Question(
                number=q.get("question_number", len(questions) + 1),
                text=q.get("question_text", f"Question {len(questions) + 1}?"),
                options=QuestionOptions(
                    A=opts.get("A", "Yes"), B=opts.get("B", "No"),
                    C=opts.get("C", "Maybe"), D=opts.get("D", "Unknown"),
                ),
            ))
        # Pad with placeholder questions if SDK returned fewer than 20
        while len(questions) < 20:
            n = len(questions) + 1
            questions.append(Question(
                number=n, text=f"Placeholder question {n}?",
                options=QuestionOptions(A="Yes", B="No", C="Maybe", D="Unknown"),
            ))
        return QuestionBatch(questions=questions, game_id=game_id, strategy_used="sdk")

    def _convert_guess_result(self, result: dict, game_id: str) -> Guess:
        """Convert SDK guess result to Guess model."""
        return Guess(
            game_id=game_id,
            opening_sentence=result.get("opening_sentence", "Unknown opening."),
            sentence_justification=result.get("sentence_justification", " ".join(["word"] * 35)),
            associative_word=result.get("associative_word", "unknown"),
            word_justification=result.get("word_justification", " ".join(["word"] * 25)),
            confidence=float(result.get("confidence", 0.5)),
            strategy_used="sdk",
        )
