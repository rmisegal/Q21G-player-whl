"""Message log repository for tracking protocol messages."""

from datetime import UTC, datetime

from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import MessageLogModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class MessageLogRepository(BaseRepository[MessageLogModel]):
    """Repository for message log operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(MessageLogModel, pool)

    def log_incoming(
        self, gmail_id: str, thread_id: str, message_type: str, transaction_id: str,
        sender_email: str, recipient_email: str, subject: str = "",
        payload: dict | None = None, game_id: str | None = None,
        league_id: str | None = None, round_id: str | None = None,
    ) -> MessageLogModel | None:
        """Log an incoming message. Returns None if already logged."""
        existing = self.get_by_gmail_id(gmail_id)
        if existing:
            return existing
        return self.create(MessageLogModel(
            gmail_id=gmail_id, thread_id=thread_id, direction="IN",
            message_type=message_type, transaction_id=transaction_id,
            sender_email=sender_email, recipient_email=recipient_email,
            subject=subject, payload=payload, game_id=game_id,
            league_id=league_id, round_id=round_id,
        ))

    def log_outgoing(
        self, gmail_id: str, message_type: str, transaction_id: str,
        sender_email: str, recipient_email: str, subject: str = "",
        payload: dict | None = None, game_id: str | None = None,
        league_id: str | None = None, round_id: str | None = None,
    ) -> MessageLogModel:
        """Log an outgoing message."""
        return self.create(MessageLogModel(
            gmail_id=gmail_id, thread_id=None, direction="OUT",
            message_type=message_type, transaction_id=transaction_id,
            sender_email=sender_email, recipient_email=recipient_email,
            subject=subject, payload=payload, game_id=game_id,
            league_id=league_id, round_id=round_id,
        ))

    def get_by_gmail_id(self, gmail_id: str) -> MessageLogModel | None:
        """Get message log by Gmail ID."""
        session = self._get_session()
        try:
            return session.query(MessageLogModel).filter_by(gmail_id=gmail_id).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by gmail_id failed: {e}")
            raise RepositoryError(f"Failed to get message log: {e}") from e

    def get_by_transaction_id(self, txid: str) -> list[MessageLogModel]:
        """Get all messages for a transaction."""
        session = self._get_session()
        try:
            return (session.query(MessageLogModel).filter_by(transaction_id=txid)
                    .order_by(MessageLogModel.created_at).all())
        except SQLAlchemyError as e:
            self._logger.error(f"Get by transaction_id failed: {e}")
            raise RepositoryError(f"Failed to get message logs: {e}") from e

    def get_by_game_id(self, game_id: str) -> list[MessageLogModel]:
        """Get all messages for a game."""
        session = self._get_session()
        try:
            return (session.query(MessageLogModel).filter_by(game_id=game_id)
                    .order_by(MessageLogModel.created_at).all())
        except SQLAlchemyError as e:
            self._logger.error(f"Get by game_id failed: {e}")
            raise RepositoryError(f"Failed to get message logs: {e}") from e

    def get_by_league_id(self, league_id: str) -> list[MessageLogModel]:
        """Get all messages for a league."""
        session = self._get_session()
        try:
            return (session.query(MessageLogModel).filter_by(league_id=league_id)
                    .order_by(MessageLogModel.created_at).all())
        except SQLAlchemyError as e:
            self._logger.error(f"Get by league_id failed: {e}")
            raise RepositoryError(f"Failed to get message logs: {e}") from e

    def get_unprocessed(self, limit: int = 50) -> list[MessageLogModel]:
        """Get unprocessed incoming messages."""
        session = self._get_session()
        try:
            return (session.query(MessageLogModel)
                    .filter_by(direction="IN", processed=False)
                    .order_by(MessageLogModel.created_at).limit(limit).all())
        except SQLAlchemyError as e:
            self._logger.error(f"Get unprocessed failed: {e}")
            raise RepositoryError(f"Failed to get unprocessed messages: {e}") from e

    def mark_processed(self, gmail_id: str, error_message: str | None = None) -> bool:
        """Mark a message as processed."""
        model = self.get_by_gmail_id(gmail_id)
        if not model:
            return False
        model.processed = True
        model.processed_at = datetime.now(UTC)
        model.error_message = error_message
        self.update(model)
        return True

    def get_by_type(
        self, message_type: str, direction: str | None = None, limit: int = 50
    ) -> list[MessageLogModel]:
        """Get messages by type."""
        session = self._get_session()
        try:
            query = session.query(MessageLogModel).filter_by(message_type=message_type)
            if direction:
                query = query.filter_by(direction=direction)
            return query.order_by(MessageLogModel.created_at.desc()).limit(limit).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by type failed: {e}")
            raise RepositoryError(f"Failed to get message logs: {e}") from e

    def get_recent(self, direction: str | None = None, limit: int = 50) -> list[MessageLogModel]:
        """Get recent messages."""
        session = self._get_session()
        try:
            query = session.query(MessageLogModel)
            if direction:
                query = query.filter_by(direction=direction)
            return query.order_by(MessageLogModel.created_at.desc()).limit(limit).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get recent failed: {e}")
            raise RepositoryError(f"Failed to get message logs: {e}") from e
