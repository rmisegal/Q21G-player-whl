"""
Rate limiter for Gmail API calls.

Implements token bucket algorithm for rate limiting.
"""

import threading
import time

from q21_player._infra.shared.config.constants import MAX_EMAILS_PER_MINUTE, RATE_LIMIT_PERIOD_SEC


class GmailRateLimiter:
    """
    Rate limiter using token bucket algorithm.

    Controls the rate of Gmail API calls to stay within quota limits.
    Default: 5 emails per minute.
    """

    def __init__(
        self,
        max_calls: int = MAX_EMAILS_PER_MINUTE,
        period_seconds: float = RATE_LIMIT_PERIOD_SEC,
    ) -> None:
        """
        Initialize rate limiter.

        Args:
            max_calls: Maximum calls allowed per period
            period_seconds: Time period in seconds
        """
        self._max_tokens = max_calls
        self._tokens = float(max_calls)
        self._period = period_seconds
        self._refill_rate = max_calls / period_seconds
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    def _refill(self) -> None:
        """Refill tokens based on elapsed time."""
        now = time.monotonic()
        elapsed = now - self._last_refill
        tokens_to_add = elapsed * self._refill_rate
        self._tokens = min(self._max_tokens, self._tokens + tokens_to_add)
        self._last_refill = now

    def acquire(self, timeout: float | None = None) -> bool:
        """
        Acquire permission to make an API call.

        Blocks until a token is available or timeout expires.

        Args:
            timeout: Maximum wait time in seconds (None = infinite)

        Returns:
            True if acquired, False if timeout
        """
        start = time.monotonic()
        deadline = None if timeout is None else start + timeout

        while True:
            with self._lock:
                self._refill()

                if self._tokens >= 1.0:
                    self._tokens -= 1.0
                    waited = time.monotonic() - start
                    if waited > 0.1:  # Only log if waited more than 100ms
                        import logging
                        logging.getLogger("rate_limiter").info(
                            f"[TIMING] rate_limit:wait: {waited*1000:.1f}ms"
                        )
                    return True

                # Calculate wait time for next token
                wait_time = (1.0 - self._tokens) / self._refill_rate

            # Check timeout
            if deadline is not None:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return False
                wait_time = min(wait_time, remaining)

            time.sleep(wait_time)

    def try_acquire(self) -> bool:
        """
        Try to acquire permission without blocking.

        Returns:
            True if acquired, False if no tokens available
        """
        with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                self._tokens -= 1.0
                return True
            return False

    @property
    def available_tokens(self) -> float:
        """Get current number of available tokens."""
        with self._lock:
            self._refill()
            return self._tokens

    def reset(self) -> None:
        """Reset the rate limiter to full capacity."""
        with self._lock:
            self._tokens = float(self._max_tokens)
            self._last_refill = time.monotonic()

    def wait_time(self) -> float:
        """
        Get estimated wait time for next token.

        Returns:
            Seconds until next token available (0 if available now)
        """
        with self._lock:
            self._refill()
            if self._tokens >= 1.0:
                return 0.0
            return (1.0 - self._tokens) / self._refill_rate
