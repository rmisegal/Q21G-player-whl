"""Connectivity handler for GmailAsPlayer - handles CONNECTIVITY_TEST messages."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from q21_player._infra.domain.models.messages import IncomingMessage, OutgoingMessage
from q21_player._infra.domain.services.response_builder import ResponseBuilder
from q21_player._infra.shared.config.constants import MessageType
from q21_player._infra.shared.logging.logger import get_logger

if TYPE_CHECKING:
    from q21_player._infra.repository.message_log_repository import (
        MessageLogRepository,
    )


class ConnectivityHandler:
    """Handles CONNECTIVITY_TEST_CALL messages and generates echo responses."""

    def __init__(
        self, response_builder: ResponseBuilder | None = None,
        message_log_repo: MessageLogRepository | None = None
    ):
        self._logger = get_logger("connectivity_handler")
        self._response_builder = response_builder or ResponseBuilder()
        self._message_log_repo = message_log_repo

    def handle_test_call(self, message: IncomingMessage) -> OutgoingMessage:
        """Handle incoming connectivity test and generate echo response."""
        ping_id = message.payload.get("ping_id", "unknown")
        timestamp = message.payload.get("timestamp", "")

        self._logger.info(f"Received connectivity test: ping_id={ping_id}")

        # Persist connectivity test to database
        if self._message_log_repo:
            self._message_log_repo.log_incoming(
                gmail_id=message.gmail_id,
                thread_id=message.thread_id or "",
                message_type=MessageType.CONNECTIVITY_TEST_CALL.value,
                transaction_id=ping_id,
                sender_email=message.sender,
                recipient_email=message.envelope.recipient_email if message.envelope else "",
                payload={"ping_id": ping_id, "timestamp": timestamp},
            )

        # Build echo response
        response = self._response_builder.build_connectivity_echo(message)
        self._logger.info(f"Generated echo response for ping_id={ping_id}")

        return response

    def is_connectivity_test(self, message: IncomingMessage) -> bool:
        """Check if message is a connectivity test."""
        return message.message_type == MessageType.CONNECTIVITY_TEST_CALL

    def validate_ping_id(self, ping_id: str) -> bool:
        """Validate ping_id format."""
        if not ping_id or not isinstance(ping_id, str):
            return False
        return len(ping_id) >= 4

    def get_test_history(self, limit: int = 50) -> list[dict[str, Any]]:
        """Get history of connectivity tests received."""
        if self._message_log_repo:
            logs = self._message_log_repo.get_by_type(
                MessageType.CONNECTIVITY_TEST_CALL.value, direction="IN", limit=limit
            )
            return [{
                "ping_id": log.payload.get("ping_id") if log.payload else "",
                "sender": log.sender_email,
                "received_at": log.created_at.isoformat(),
                "original_timestamp": log.payload.get("timestamp") if log.payload else "",
            } for log in logs]
        return []

    def get_last_test(self) -> dict[str, Any] | None:
        """Get most recent connectivity test."""
        history = self.get_test_history(limit=1)
        return history[0] if history else None

    @property
    def test_count(self) -> int:
        """Get total number of tests received."""
        return len(self.get_test_history(limit=1000))
