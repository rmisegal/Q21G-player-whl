"""
Domain models for GmailAsPlayer.

Pydantic models for game entities, messages, and state.
"""

from q21_player._infra.domain.models.answer import Answer, AnswerBatch
from q21_player._infra.domain.models.attachment_entry import AttachmentEntry
from q21_player._infra.domain.models.broadcast import (
    BroadcastMessage,
    BroadcastResponse,
    StandingsEntry,
)
from q21_player._infra.domain.models.envelope import Envelope
from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.domain.models.message_context import MessageContext
from q21_player._infra.domain.models.guess import Guess
from q21_player._infra.domain.models.lookup_table import LookupTable
from q21_player._infra.domain.models.messages import IncomingMessage, OutgoingMessage
from q21_player._infra.domain.models.pause_context import PauseContext
from q21_player._infra.domain.models.player_state import PlayerStateDTO
from q21_player._infra.domain.models.question import Question, QuestionBatch

__all__ = [
    "PlayerStateDTO",
    "GameContext",
    "IncomingMessage",
    "OutgoingMessage",
    "Envelope",
    "Question",
    "QuestionBatch",
    "Answer",
    "AnswerBatch",
    "Guess",
    "AttachmentEntry",
    "LookupTable",
    "BroadcastMessage",
    "BroadcastResponse",
    "StandingsEntry",
    "PauseContext",
    "MessageContext",
]
