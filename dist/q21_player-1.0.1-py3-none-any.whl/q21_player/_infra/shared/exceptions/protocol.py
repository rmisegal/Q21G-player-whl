"""
Protocol/message exceptions for GmailAsPlayer.

Covers message parsing and protocol validation errors.
"""

from typing import Any

from q21_player._infra.shared.exceptions.base import PlayerError


class ProtocolError(PlayerError):
    """Base exception for protocol-related errors."""

    def __init__(
        self,
        message: str,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, code or "PROTOCOL_ERROR", details)


class MessageParseError(ProtocolError):
    """Failed to parse a message."""

    def __init__(
        self,
        message: str = "Failed to parse message",
        raw_content: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        details = details or {}
        if raw_content:
            # Truncate for safety
            details["raw_content_preview"] = raw_content[:200]
        super().__init__(message, "MESSAGE_PARSE_ERROR", details)


class InvalidEnvelopeError(ProtocolError):
    """Invalid message envelope structure."""

    def __init__(
        self,
        message: str = "Invalid message envelope",
        missing_fields: list[str] | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        details = details or {}
        if missing_fields:
            details["missing_fields"] = missing_fields
        super().__init__(message, "INVALID_ENVELOPE", details)


class UnknownMessageTypeError(ProtocolError):
    """Unknown or unsupported message type."""

    def __init__(
        self,
        message_type: str,
        message: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        message = message or f"Unknown message type: '{message_type}'"
        details = details or {}
        details["message_type"] = message_type
        super().__init__(message, "UNKNOWN_MESSAGE_TYPE", details)
        self.message_type = message_type


class SubjectLineError(ProtocolError):
    """Invalid email subject line format."""

    def __init__(
        self,
        subject: str,
        message: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        message = message or "Invalid subject line format"
        details = details or {}
        details["subject"] = subject
        super().__init__(message, "SUBJECT_LINE_ERROR", details)


class PayloadValidationError(ProtocolError):
    """Message payload validation failed."""

    def __init__(
        self,
        message: str = "Payload validation failed",
        field: str | None = None,
        expected: str | None = None,
        actual: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        details = details or {}
        if field:
            details["field"] = field
        if expected:
            details["expected"] = expected
        if actual:
            details["actual"] = actual
        super().__init__(message, "PAYLOAD_VALIDATION_ERROR", details)
