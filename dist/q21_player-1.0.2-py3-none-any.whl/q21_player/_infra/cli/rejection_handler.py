"""Rejection notification handler for processing message rejections."""

from q21_player._infra.domain.services.error_logger import ErrorLogger
from q21_player._infra.shared.logging.logger import get_logger

logger = get_logger("rejection_handler")


class RejectionHandler:
    """Handles REJECTION_NOTIFICATION messages from the league manager."""

    def process(self, payload: dict) -> dict:
        """
        Process a rejection notification payload.

        Args:
            payload: The message payload containing rejection data

        Returns:
            Dict with:
                - correlation_id: str | None - Original message correlation ID
                - reason: str - Rejection reason
                - deadline: str | None - Original deadline
                - received_at: str | None - When the rejected message was received
                - can_request_extension: bool - Whether extension can be requested
        """
        inner_payload = payload.get("payload", {})
        correlation_id = inner_payload.get("correlation_id")
        reason = inner_payload.get("reason", "Unknown reason")
        deadline = inner_payload.get("deadline")
        received_at = inner_payload.get("received_at")
        can_request_extension = inner_payload.get("can_request_extension", False)

        result = {
            "correlation_id": correlation_id,
            "reason": reason,
            "deadline": deadline,
            "received_at": received_at,
            "can_request_extension": can_request_extension,
        }

        logger.warning(f"Message REJECTED - correlation_id={correlation_id}, reason={reason}")

        # Log to error_log table
        ErrorLogger.log(
            error_type="MESSAGE_REJECTED",
            message=f"Message rejected: {reason}",
            context={
                "correlation_id": correlation_id,
                "deadline": deadline,
                "received_at": received_at,
                "can_request_extension": can_request_extension,
            },
        )

        return result
