"""Hints Handler for Q21_HINTS messages."""

from typing import Any

from q21_player._infra.cli.handlers.base_game_handler import BaseGameHandler
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository


class HintsHandler(BaseGameHandler):
    """Handles Q21_HINTS message processing."""

    def __init__(
        self,
        state_repo: GameStateRepository | None = None,
        game_repo: GameRepository | None = None,
    ):
        super().__init__(state_repo=state_repo, game_repo=game_repo)

    def process(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Process Q21_HINTS message.

        Args:
            payload: Hints payload with description and association_topic

        Returns:
            dict with match_id, description, and association_topic
        """
        match_id = payload.get("match_id", "")
        description = payload.get("description", "")
        association_topic = payload.get("association_topic", "")

        # Store hints in game state
        self._state_repo.store_hints(match_id, description, association_topic)

        # Update phase
        self._state_repo.update_phase(match_id, "HINTS_RECEIVED")

        self._logger.info(f"Processed hints for match {match_id}: domain={association_topic}")
        return {
            "match_id": match_id,
            "description": description,
            "association_topic": association_topic,
        }
