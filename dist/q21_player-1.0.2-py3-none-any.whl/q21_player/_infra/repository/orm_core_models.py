"""Core ORM models for game sessions with relationships."""
from datetime import UTC, datetime
from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, JSON, String, Text
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()
def _now() -> datetime: return datetime.now(UTC)


class PlayerStateModel(Base):
    __tablename__ = "player_states"
    id = Column(Integer, primary_key=True, autoincrement=True)
    player_email = Column(String(255), unique=True, nullable=False, index=True)
    player_name = Column(String(255), nullable=False)
    current_state = Column(String(50), nullable=False, default="INIT_START_STATE")
    current_game_id, current_book = Column(String(100), nullable=True), Column(String(255), nullable=True)
    current_description, current_domain = Column(Text, nullable=True), Column(String(255), nullable=True)
    current_league_id = Column(String(100), nullable=True)
    current_season_id = Column(String(100), nullable=True)
    current_round_id = Column(String(100), nullable=True)
    registration_id, registered_at = Column(String(100), nullable=True), Column(DateTime, nullable=True)
    last_activity, created_at = Column(DateTime, default=_now), Column(DateTime, default=_now)
    updated_at = Column(DateTime, default=_now, onupdate=_now)


class GameSessionModel(Base):
    __tablename__ = "game_sessions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    game_id = Column(String(100), unique=True, nullable=False, index=True)
    player_email = Column(String(255), nullable=False)
    book_name, description, domain = Column(String(255), nullable=False), Column(Text, nullable=True), Column(String(255), nullable=True)
    season_id = Column(String(50), nullable=True, index=True)
    round_id, round_number, game_number = Column(String(50), nullable=True), Column(Integer, nullable=True), Column(Integer, nullable=True)
    opponent_email, opponent_name = Column(String(255), nullable=True), Column(String(100), nullable=True)
    my_role = Column(String(20), nullable=True)
    match_id = Column(String(50), unique=True, nullable=True, index=True)
    referee_email = Column(String(255), nullable=True)
    invitation_status = Column(String(20), default="PENDING")
    invitation_deadline, invitation_received_at = Column(DateTime, nullable=True), Column(DateTime, nullable=True)
    started_at, ended_at = Column(DateTime, default=_now), Column(DateTime, nullable=True)
    is_completed, is_abandoned = Column(Boolean, default=False), Column(Boolean, default=False)
    result_correct, result_score = Column(Boolean, nullable=True), Column(Float, nullable=True)
    questions = relationship("QuestionModel", back_populates="game", cascade="all, delete-orphan")
    answers = relationship("AnswerModel", back_populates="game", cascade="all, delete-orphan")
    guess = relationship("GuessModel", back_populates="game", uselist=False, cascade="all, delete-orphan")


class QuestionModel(Base):
    __tablename__ = "questions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    game_id = Column(String(100), ForeignKey("game_sessions.game_id"), nullable=False)
    question_number, question_text = Column(Integer, nullable=False), Column(Text, nullable=False)
    options, created_at = Column(JSON, nullable=True), Column(DateTime, default=_now)
    answer_received = Column(String(20), nullable=True)
    answer_received_at = Column(DateTime, nullable=True)
    game = relationship("GameSessionModel", back_populates="questions")


class AnswerModel(Base):
    __tablename__ = "answers"
    id = Column(Integer, primary_key=True, autoincrement=True)
    game_id = Column(String(100), ForeignKey("game_sessions.game_id"), nullable=False)
    question_number, selected_option = Column(Integer, nullable=False), Column(String(10), nullable=False)
    received_at = Column(DateTime, default=_now)
    game = relationship("GameSessionModel", back_populates="answers")


class GuessModel(Base):
    __tablename__ = "guesses"
    id = Column(Integer, primary_key=True, autoincrement=True)
    game_id = Column(String(100), ForeignKey("game_sessions.game_id"), unique=True, nullable=False)
    opening_sentence, sentence_justification = Column(Text, nullable=False), Column(Text, nullable=True)
    associative_word, word_justification = Column(String(100), nullable=True), Column(Text, nullable=True)
    confidence, strategy_used = Column(Float, nullable=True), Column(String(50), nullable=True)
    created_at = Column(DateTime, default=_now)
    game = relationship("GameSessionModel", back_populates="guess")
