"""
Helper functions for GmailAsPlayer.

Provides ID generation and formatting utilities.
"""

import hashlib
import uuid
from datetime import UTC, datetime

from q21_player._infra.shared.config.constants import (
    PROTOCOL_VERSION,
    SUBJECT_DELIMITER,
    MessageType,
    UserRole,
)


def generate_transaction_id(prefix: str = "tx") -> str:
    """
    Generate a unique transaction ID.

    Format: {prefix}-{timestamp}-{uuid4_short}
    Example: tx-20250111-a1b2c3d4

    Args:
        prefix: Prefix for the transaction ID

    Returns:
        Unique transaction ID string
    """
    timestamp = datetime.now(UTC).strftime("%Y%m%d")
    unique_part = uuid.uuid4().hex[:8]
    return f"{prefix}-{timestamp}-{unique_part}"


def generate_unique_key(components: list[str]) -> str:
    """
    Generate a unique key from multiple components.

    Args:
        components: List of string components to hash

    Returns:
        SHA256 hash of joined components
    """
    combined = "|".join(str(c) for c in components)
    return hashlib.sha256(combined.encode()).hexdigest()[:16]


def format_subject_line(
    role: UserRole,
    email: str,
    transaction_id: str,
    message_type: MessageType,
    protocol_version: str = PROTOCOL_VERSION,
) -> str:
    """
    Format an email subject line according to league.v2 protocol.

    Format: {protocol}::{role}::{email}::{txid}::{message_type}

    Args:
        role: User role (PLAYER, MANAGER, REFEREE)
        email: Sender's email address
        transaction_id: Unique transaction ID
        message_type: Type of message
        protocol_version: Protocol version string

    Returns:
        Formatted subject line string
    """
    return SUBJECT_DELIMITER.join([
        protocol_version,
        role.value,
        email,
        transaction_id,
        message_type.value,
    ])


def parse_subject_line(subject: str) -> tuple[str, UserRole, str, str, MessageType] | None:
    """
    Parse an email subject line according to league.v2 protocol.

    Args:
        subject: Email subject line string

    Returns:
        Tuple of (protocol, role, email, txid, message_type) or None if invalid
    """
    try:
        parts = subject.split(SUBJECT_DELIMITER)
        if len(parts) != 5:
            return None

        protocol, role_str, email, txid, msg_type_str = parts

        # Validate and convert enum values
        role = UserRole(role_str)
        message_type = MessageType(msg_type_str)

        return (protocol, role, email, txid, message_type)

    except (ValueError, KeyError):
        return None
