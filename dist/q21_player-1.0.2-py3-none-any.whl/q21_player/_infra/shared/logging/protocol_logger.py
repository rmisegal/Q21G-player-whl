# Area: Protocol Logging
# PRD: docs/LOGGER_OUTPUT_PLAYER.md
"""Protocol Logger - Colored output for player protocol messages."""
from datetime import datetime
from typing import Optional
from q21_player._infra.shared.logging.constants import (
    Colors, MESSAGE_DISPLAY_NAMES, EXPECTED_RESPONSES, CALLBACK_DISPLAY_NAMES
)


class ProtocolLogger:
    """Logger for protocol messages. Context: Season=SS99999, Round=SSRR999, Game=SSRRGGG."""
    _current_game_id: str = "0199999"
    _season: str = "01"
    _show_role: bool = False
    _player_active: bool = True

    @classmethod
    def set_season_context(cls) -> None:
        """Set context for season-level messages (SS99999, empty role)."""
        cls._current_game_id = cls._season + "99999"
        cls._show_role = False

    @classmethod
    def set_round_context(cls, round_number: int, player_active: bool = True) -> None:
        """Set context for round-level messages (SSRR999, with role)."""
        cls._current_game_id = cls._season + f"{round_number:02d}" + "999"
        cls._show_role = True
        cls._player_active = player_active

    @classmethod
    def set_game_context(cls, game_id: str, player_active: bool = True) -> None:
        """Set context for game-level messages (SSRRGGG, with role)."""
        cls._current_game_id = game_id or "0199999"
        cls._show_role = True
        cls._player_active = player_active
        if game_id and len(game_id) >= 2:
            cls._season = game_id[:2]

    @classmethod
    def _get_display_name(cls, msg_type: str) -> str:
        if msg_type in MESSAGE_DISPLAY_NAMES: return MESSAGE_DISPLAY_NAMES[msg_type]
        normalized = msg_type.replace("_", "").upper()
        for key, value in MESSAGE_DISPLAY_NAMES.items():
            if key.replace("_", "").upper() == normalized: return value
        return msg_type

    @classmethod
    def _get_expected_response(cls, msg_type: str) -> str:
        if msg_type in EXPECTED_RESPONSES: return EXPECTED_RESPONSES[msg_type]
        normalized = msg_type.replace("_", "").upper()
        for key, value in EXPECTED_RESPONSES.items():
            if key.replace("_", "").upper() == normalized: return value
        return "Unknown"

    @classmethod
    def _get_role(cls) -> str:
        if not cls._show_role: return ""
        return "PLAYER-ACTIVE" if cls._player_active else "PLAYER-INACTIVE"

    @classmethod
    def _format_time(cls, with_ms: bool = False) -> str:
        now = datetime.now()
        return now.strftime("%H:%M:%S:%f")[:-3] if with_ms else now.strftime("%H:%M:%S")

    @classmethod
    def _format_deadline(cls, deadline: Optional[str]) -> str:
        if not deadline: return "N/A"
        try:
            dt = datetime.fromisoformat(deadline.replace("Z", "+00:00"))
            return dt.strftime("%H:%M:%S")
        except (ValueError, AttributeError): return deadline if deadline else "N/A"

    @classmethod
    def log_received(cls, msg_type: str, sender: str, game_id: str = None, deadline: str = None):
        gid = game_id or cls._current_game_id
        print(f"{Colors.GREEN}{cls._format_time()} | GAME-ID: {gid} | RECEIVED | from {sender:<30} | "
              f"{cls._get_display_name(msg_type):<20} | EXPECTED-RESPONSE: {cls._get_expected_response(msg_type):<25} | "
              f"ROLE: {cls._get_role()} | DEADLINE: {cls._format_deadline(deadline)}{Colors.RESET}")

    @classmethod
    def log_sent(cls, msg_type: str, recipient: str, game_id: str = None, deadline: str = None):
        gid = game_id or cls._current_game_id
        print(f"{Colors.GREEN}{cls._format_time()} | GAME-ID: {gid} | SENT     | to {recipient:<32} | "
              f"{cls._get_display_name(msg_type):<20} | EXPECTED-RESPONSE: {cls._get_expected_response(msg_type):<25} | "
              f"ROLE: {cls._get_role()} | DEADLINE: {cls._format_deadline(deadline)}{Colors.RESET}")

    @classmethod
    def log_rejected(cls, msg_type: str, sender: str, reason: str = ""):
        msg = f"REJECTED {cls._get_display_name(msg_type)} from {sender}"
        if reason: msg += f": {reason}"
        print(f"{Colors.RED}[ERROR] {cls._format_time()} | {msg}{Colors.RESET}")

    @classmethod
    def log_error(cls, message: str):
        print(f"{Colors.RED}[ERROR] {cls._format_time()} | {message}{Colors.RESET}")

    @classmethod
    def log_callback_call(cls, callback_name: str):
        display = CALLBACK_DISPLAY_NAMES.get(callback_name, callback_name)
        print(f"{Colors.ORANGE}{cls._format_time(True)} | CALLBACK: {display:<20} | CALL     | ROLE: PLAYER{Colors.RESET}")

    @classmethod
    def log_callback_response(cls, callback_name: str):
        display = CALLBACK_DISPLAY_NAMES.get(callback_name, callback_name)
        print(f"{Colors.ORANGE}{cls._format_time(True)} | CALLBACK: {display:<20} | RESPONSE | ROLE: PLAYER{Colors.RESET}")


# Convenience functions
def set_season_context(): ProtocolLogger.set_season_context()
def set_round_context(rn: int, active: bool = True): ProtocolLogger.set_round_context(rn, active)
def set_game_context(gid: str, active: bool = True): ProtocolLogger.set_game_context(gid, active)
def log_received(msg: str, sender: str, gid: str = None, dl: str = None): ProtocolLogger.log_received(msg, sender, gid, dl)
def log_sent(msg: str, to: str, gid: str = None, dl: str = None): ProtocolLogger.log_sent(msg, to, gid, dl)
def log_rejected(msg: str, sender: str, reason: str = ""): ProtocolLogger.log_rejected(msg, sender, reason)
def log_error(message: str): ProtocolLogger.log_error(message)
def log_callback_call(name: str): ProtocolLogger.log_callback_call(name)
def log_callback_response(name: str): ProtocolLogger.log_callback_response(name)
