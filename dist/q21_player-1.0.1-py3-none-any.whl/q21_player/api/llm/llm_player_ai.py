"""
LLM-powered PlayerAI implementation.

Default AI that uses LLM for all callbacks.
"""

from ..callbacks import PlayerAI
from .client import LLMClient
from .prompts import (
    format_warmup_prompt,
    format_questions_prompt,
    format_guess_prompt,
)
from .response_helpers import (
    validate_questions,
    fallback_questions,
    extract_guess,
    fallback_guess,
)


class LLMPlayerAI(PlayerAI):
    """
    PlayerAI implementation using LLM for responses.

    Uses LLM to:
    - Answer warmup questions
    - Generate 20 strategic questions
    - Formulate guess based on answers
    """

    def __init__(
        self,
        provider: str = "anthropic",
        model: str | None = None,
        api_key: str | None = None,
    ):
        """
        Initialize LLM-powered AI.

        Args:
            provider: LLM provider (anthropic, openai, gemini)
            model: Model name (uses default if not specified)
            api_key: API key (uses env var if not specified)
        """
        self.client = LLMClient(provider=provider, model=model, api_key=api_key)
        self._last_questions: list[dict] = []

    def get_warmup_answer(self, ctx: dict) -> dict:
        """Use LLM to answer the warmup question."""
        question = ctx["dynamic"]["warmup_question"]
        prompt = format_warmup_prompt(question)

        response = self.client.send(prompt)
        if not response.success:
            return {"answer": "0"}

        parsed = self.client.parse_json(response.content)
        if parsed and "answer" in parsed:
            return {"answer": str(parsed["answer"])}

        # Fallback: try to extract answer from text
        return {"answer": response.content.strip()[:100]}

    def get_questions(self, ctx: dict) -> dict:
        """Use LLM to generate 20 strategic questions."""
        book_name = ctx["dynamic"]["book_name"]
        book_hint = ctx["dynamic"].get("book_hint", "")
        association_word = ctx["dynamic"].get("association_word", "")

        prompt = format_questions_prompt(book_name, book_hint, association_word)
        response = self.client.send(prompt)

        if not response.success:
            return {"questions": fallback_questions(book_name)}

        parsed = self.client.parse_json(response.content)
        if parsed and "questions" in parsed:
            questions = parsed["questions"]
            if validate_questions(questions):
                self._last_questions = questions
                return {"questions": questions}

        return {"questions": fallback_questions(book_name)}

    def get_guess(self, ctx: dict) -> dict:
        """Use LLM to formulate guess based on answers."""
        answers = ctx["dynamic"]["answers"]
        book_name = ctx["dynamic"].get("book_name", "Unknown")
        book_hint = ctx["dynamic"].get("book_hint", "")
        association_word = ctx["dynamic"].get("association_word", "general")
        questions = ctx["dynamic"].get("questions_sent", self._last_questions)

        prompt = format_guess_prompt(
            book_name, book_hint, association_word, answers, questions
        )
        response = self.client.send(prompt)

        if not response.success:
            return fallback_guess()

        parsed = self.client.parse_json(response.content)
        if parsed:
            return extract_guess(parsed)

        return fallback_guess()

    def on_score_received(self, ctx: dict) -> None:
        """Handle score notification."""
        points = ctx["dynamic"].get("league_points", 0)
        print(f"Game complete! Scored {points} points.")
