"""
Broadcast message models for GmailAsPlayer.

Models for League Manager broadcast messages and player responses.
"""

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

from q21_player._infra.shared.config.constants import MessageType


class BroadcastMessage(BaseModel):
    """Represents an incoming broadcast message from League Manager."""

    broadcast_id: str = Field(..., description="Unique broadcast identifier")
    message_type: MessageType = Field(..., description="Type of broadcast message")
    league_id: str | None = Field(None, description="League identifier")
    round_id: str | None = Field(None, description="Round identifier if applicable")
    message_text: str | None = Field(None, description="Human-readable message (max 20 words)")
    payload: dict[str, Any] = Field(default_factory=dict, description="Full broadcast payload")
    received_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When broadcast was received"
    )
    response_required: bool = Field(default=False, description="Whether response is needed")
    deadline: datetime | None = Field(None, description="Response deadline if applicable")

    @classmethod
    def from_payload(cls, payload: dict[str, Any], message_type: MessageType) -> "BroadcastMessage":
        """Create BroadcastMessage from raw payload."""
        response_types = {
            MessageType.BROADCAST_KEEP_ALIVE,
            MessageType.BROADCAST_FREE_TEXT,
            MessageType.BROADCAST_CRITICAL_RESET,
            MessageType.BROADCAST_CRITICAL_PAUSE,
            MessageType.BROADCAST_CRITICAL_CONTINUE,
        }
        # Handle nested payload structure (payload.payload.broadcast_id)
        inner = payload.get("payload", {}) if isinstance(payload.get("payload"), dict) else {}
        return cls(
            broadcast_id=inner.get("broadcast_id") or payload.get("broadcast_id", ""),
            message_type=message_type,
            league_id=inner.get("league_id") or payload.get("league_id"),
            round_id=inner.get("round_id") or payload.get("round_id"),
            message_text=inner.get("message_text") or payload.get("message_text"),
            payload=payload,
            response_required=message_type in response_types,
            deadline=inner.get("response_deadline") or payload.get("deadline"),
        )


class BroadcastResponse(BaseModel):
    """Represents an outgoing broadcast response to League Manager."""

    broadcast_id: str = Field(..., description="Original broadcast ID being responded to")
    response_type: MessageType = Field(..., description="Response message type")
    message_text: str = Field(default="", description="Response message (max 40 words)")
    payload: dict[str, Any] = Field(default_factory=dict, description="Response payload")
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    @property
    def response_timestamp(self) -> str:
        """Get ISO format timestamp for payload."""
        return self.created_at.isoformat()


class StandingsEntry(BaseModel):
    """Entry in league standings."""

    rank: int = Field(..., description="Position in standings")
    player_id: str = Field(..., description="Player identifier")
    email: str = Field(..., description="Player email")
    display_name: str = Field(..., description="Player display name")
    points: int = Field(default=0, description="Total points")
    wins: int = Field(default=0, description="Number of wins")
    losses: int = Field(default=0, description="Number of losses")
    avg_score: float | None = Field(None, description="Average score")
