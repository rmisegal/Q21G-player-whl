"""
PlayerRunner - Simple API for running the Q21 player programmatically.

Example:
    from q21_player import PlayerAI, PlayerRunner

    class MyAI(PlayerAI):
        def get_warmup_answer(self, ctx): return {"answer": "4"}
        def get_questions(self, ctx): return {"questions": [...]}
        def get_guess(self, ctx): return {"opening_sentence": "...", ...}
        def on_score_received(self, ctx): pass

    runner = PlayerRunner(ai=MyAI())
    runner.run()  # Continuous mode
    # or
    result = runner.run_once()  # Single scan
"""

from q21_player.api.callbacks import PlayerAI
from q21_player._infra.cli.scan_handler import run_scan
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.strategy.sdk_strategy import SDKStrategy
from q21_player._infra.strategy.strategy_factory import set_player_ai


class PlayerRunner:
    """Runner that wraps infrastructure for programmatic use."""

    def __init__(self, ai: PlayerAI | None = None):
        """Initialize runner with optional PlayerAI instance.

        Args:
            ai: PlayerAI implementation. If None, uses config to load.
        """
        self._config = Config()
        self._ai = ai
        self._running = False

        # Register AI with strategy factory if provided
        if ai is not None:
            set_player_ai(ai)

    def run(self) -> None:
        """Run continuous polling mode (blocking).

        Polls Gmail for messages until stopped.
        """
        self._running = True
        player_email = self._config.gmail.account
        player_name = self._config.get("player.display_name", "Player")

        while self._running:
            try:
                run_scan(player_email, player_name)
            except KeyboardInterrupt:
                break
            except Exception as e:
                print(f"Scan error: {e}")

    def run_once(self) -> dict:
        """Run single scan and return results.

        Returns:
            dict with scan results (emails_found, emails_processed, etc.)
        """
        player_email = self._config.gmail.account
        player_name = self._config.get("player.display_name", "Player")
        result = run_scan(player_email, player_name)
        return {
            "status": result.status,
            "emails_found": result.emails_found,
            "emails_processed": result.emails_processed,
            "responses_sent": result.responses_sent,
            "errors": result.errors,
        }

    def stop(self) -> None:
        """Stop the runner."""
        self._running = False

    @property
    def is_running(self) -> bool:
        """Check if runner is active."""
        return self._running
