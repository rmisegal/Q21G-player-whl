"""
Answer models for Q21 game.

Represents answers received from the referee.
"""

from typing import Literal

from pydantic import BaseModel, Field, field_validator

from q21_player._infra.shared.config.constants import MAX_QUESTIONS

AnswerChoice = Literal["A", "B", "C", "D"]


class Answer(BaseModel):
    """A single answer to a question."""

    question_number: int = Field(..., ge=1, le=MAX_QUESTIONS)
    answer: AnswerChoice = Field(..., description="Selected answer (A/B/C/D)")
    question_text: str | None = Field(default=None, description="Original question")

    @field_validator("answer")
    @classmethod
    def validate_answer(cls, v: str) -> str:
        """Ensure answer is valid choice."""
        v = v.upper().strip()
        if v not in ["A", "B", "C", "D"]:
            raise ValueError(f"Invalid answer: {v}. Must be A, B, C, or D")
        return v

    def to_dict(self) -> dict:
        return {
            "question_number": self.question_number,
            "answer": self.answer,
        }


class AnswerBatch(BaseModel):
    """Batch of answers received from referee."""

    answers: list[Answer] = Field(..., min_length=1, max_length=MAX_QUESTIONS)
    game_id: str = Field(..., description="Associated game ID")
    received_count: int = Field(default=0, description="Number of answers in this batch")

    def model_post_init(self, __context) -> None:
        """Set received count after init."""
        self.received_count = len(self.answers)

    @field_validator("answers")
    @classmethod
    def validate_unique_questions(cls, v: list[Answer]) -> list[Answer]:
        """Ensure no duplicate question numbers."""
        numbers = [a.question_number for a in v]
        if len(numbers) != len(set(numbers)):
            raise ValueError("Duplicate question numbers in answers")
        return sorted(v, key=lambda a: a.question_number)

    def get_answer(self, question_number: int) -> Answer | None:
        """Get answer for a specific question."""
        for a in self.answers:
            if a.question_number == question_number:
                return a
        return None

    def to_dict_map(self) -> dict[int, str]:
        """Convert to {question_number: answer} mapping."""
        return {a.question_number: a.answer for a in self.answers}

    @classmethod
    def from_protocol_payload(cls, payload: dict, game_id: str) -> "AnswerBatch":
        """Parse from protocol payload."""
        answers_data = payload.get("answers", [])
        answers = [
            Answer(
                question_number=a.get("question_number"),
                answer=a.get("answer"),
                question_text=a.get("question_text"),
            )
            for a in answers_data
        ]
        return cls(answers=answers, game_id=game_id)

    @property
    def is_complete(self) -> bool:
        """Check if all 20 answers received."""
        return len(self.answers) == MAX_QUESTIONS

    def count_by_answer(self) -> dict[str, int]:
        """Count answers by choice."""
        counts = {"A": 0, "B": 0, "C": 0, "D": 0}
        for a in self.answers:
            counts[a.answer] += 1
        return counts
