"""Periodic handler for email polling and heartbeat."""

import threading
from collections.abc import Callable
from datetime import UTC, datetime

from q21_player._infra.shared.config.constants import (
    DEFAULT_POLL_INTERVAL_SEC,
    DEFAULT_STATE_TIMEOUT_SEC,
    THREAD_JOIN_TIMEOUT_SEC,
)
from q21_player._infra.shared.logging.logger import get_logger


class PeriodicHandler:
    """Handles periodic tasks like email polling and heartbeats."""

    def __init__(
        self,
        poll_callback: Callable[[], None],
        poll_interval: int = DEFAULT_POLL_INTERVAL_SEC,
        heartbeat_callback: Callable[[], None] | None = None,
        heartbeat_interval: int = DEFAULT_STATE_TIMEOUT_SEC,
    ):
        self._logger = get_logger("periodic_handler")
        self._poll_callback = poll_callback
        self._poll_interval = poll_interval
        self._heartbeat_callback = heartbeat_callback
        self._heartbeat_interval = heartbeat_interval
        self._running = False
        self._poll_thread: threading.Thread | None = None
        self._heartbeat_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._last_poll: datetime | None = None
        self._last_heartbeat: datetime | None = None
        self._poll_count = 0
        self._error_count = 0

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def stats(self) -> dict:
        return {
            "poll_count": self._poll_count,
            "error_count": self._error_count,
            "last_poll": self._last_poll.isoformat() if self._last_poll else None,
            "last_heartbeat": self._last_heartbeat.isoformat() if self._last_heartbeat else None,
        }

    def start(self) -> None:
        """Start periodic handlers."""
        if self._running:
            return

        self._running = True
        self._stop_event.clear()
        self._poll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._poll_thread.start()
        self._logger.info(f"Started polling every {self._poll_interval}s")

        if self._heartbeat_callback:
            self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
            self._heartbeat_thread.start()
            self._logger.info(f"Started heartbeat every {self._heartbeat_interval}s")

    def stop(self) -> None:
        """Stop periodic handlers."""
        if not self._running:
            return

        self._running = False
        self._stop_event.set()

        if self._poll_thread and self._poll_thread.is_alive():
            self._poll_thread.join(timeout=THREAD_JOIN_TIMEOUT_SEC)
        if self._heartbeat_thread and self._heartbeat_thread.is_alive():
            self._heartbeat_thread.join(timeout=THREAD_JOIN_TIMEOUT_SEC)

        self._logger.info("Periodic handlers stopped")

    def _poll_loop(self) -> None:
        """Main polling loop."""
        while self._running and not self._stop_event.is_set():
            try:
                self._poll_callback()
                self._last_poll = datetime.now(UTC)
                self._poll_count += 1
            except Exception as e:
                self._error_count += 1
                self._logger.error(f"Poll error: {e}")

            self._stop_event.wait(timeout=self._poll_interval)

    def _heartbeat_loop(self) -> None:
        """Heartbeat loop."""
        while self._running and not self._stop_event.is_set():
            self._stop_event.wait(timeout=self._heartbeat_interval)
            if not self._running:
                break
            try:
                if self._heartbeat_callback:
                    self._heartbeat_callback()
                    self._last_heartbeat = datetime.now(UTC)
            except Exception as e:
                self._logger.error(f"Heartbeat error: {e}")

    def trigger_poll(self) -> None:
        """Manually trigger a poll."""
        if self._running:
            try:
                self._poll_callback()
                self._last_poll = datetime.now(UTC)
                self._poll_count += 1
            except Exception as e:
                self._error_count += 1
                self._logger.error(f"Manual poll error: {e}")

    def set_poll_interval(self, interval: int) -> None:
        """Update poll interval."""
        self._poll_interval = max(5, interval)
        self._logger.info(f"Poll interval updated to {self._poll_interval}s")
