"""
Gmail API client with OAuth2 authentication.
"""

from pathlib import Path
from typing import Any

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import Resource, build

from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.exceptions.gmail import GmailAuthenticationError, GmailConnectionError
from q21_player._infra.shared.logging.logger import get_logger

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/gmail.modify",
]


class GmailClient:
    """Gmail API client with OAuth2 authentication."""

    def __init__(self) -> None:
        self._logger = get_logger("gmail.client")
        self._config = Config()
        self._service: Resource | None = None
        self._credentials: Credentials | None = None

    def authenticate(self) -> bool:
        """Authenticate with Gmail API using OAuth2."""
        creds_path = Path(self._config.gmail.credentials_path)
        token_path = Path(self._config.gmail.token_path)

        if not creds_path.exists():
            raise GmailAuthenticationError(f"Credentials file not found: {creds_path}")

        creds = None
        if token_path.exists():
            creds = Credentials.from_authorized_user_file(str(token_path), SCOPES)

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(str(creds_path), SCOPES)
                creds = flow.run_local_server(port=0)
            with open(token_path, "w") as token:
                token.write(creds.to_json())

        self._credentials = creds
        self._logger.info("Gmail authentication successful")
        return True

    def connect(self) -> None:
        """Connect to Gmail API."""
        if not self._credentials:
            self.authenticate()
        try:
            self._service = build("gmail", "v1", credentials=self._credentials)
            self._logger.info("Connected to Gmail API")
        except Exception as e:
            raise GmailConnectionError(f"Failed to connect: {e}") from e

    @property
    def service(self) -> Resource:
        """Get Gmail API service instance."""
        if not self._service:
            self.connect()
        return self._service

    def get_profile(self) -> dict[str, Any]:
        """Get authenticated user's profile."""
        return self.service.users().getProfile(userId="me").execute()

    def list_messages(
        self, query: str = "", max_results: int = 10, page_token: str | None = None
    ) -> dict[str, Any]:
        """List messages matching query."""
        return self.service.users().messages().list(
            userId="me", q=query, maxResults=max_results, pageToken=page_token
        ).execute()

    def get_message(self, message_id: str, format: str = "full") -> dict[str, Any]:
        """Get a specific message by ID."""
        return self.service.users().messages().get(
            userId="me", id=message_id, format=format
        ).execute()

    def modify_message(self, message_id: str, add_labels: list[str] = None,
                       remove_labels: list[str] = None) -> dict[str, Any]:
        """Modify message labels."""
        body = {}
        if add_labels:
            body["addLabelIds"] = add_labels
        if remove_labels:
            body["removeLabelIds"] = remove_labels
        return self.service.users().messages().modify(
            userId="me", id=message_id, body=body
        ).execute()

    def is_connected(self) -> bool:
        """Check if connected to Gmail API."""
        return self._service is not None
