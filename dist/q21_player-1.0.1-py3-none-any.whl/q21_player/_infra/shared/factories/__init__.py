"""Shared factories for message and envelope creation."""

from q21_player._infra.shared.factories.envelope_factory import EnvelopeFactory

__all__ = ["EnvelopeFactory"]
