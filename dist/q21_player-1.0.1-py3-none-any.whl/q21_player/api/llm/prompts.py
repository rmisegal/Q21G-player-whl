"""
Prompt templates for Q21 Player SDK.

Contains prompts for warmup, questions, and guess callbacks.
"""

WARMUP_PROMPT = """You are playing a 21-Questions game. Answer the warmup question.

WARMUP QUESTION:
{warmup_question}

INSTRUCTIONS:
1. Answer the question directly and concisely
2. If it's a math problem, calculate the answer
3. If it's a trivia question, give your best answer
4. Be brief - just the answer

OUTPUT FORMAT (JSON only, no other text):
{{
  "answer": "Your answer here"
}}

Answer now:"""


QUESTIONS_PROMPT = """You are playing a 21-Questions game. Generate 20 strategic yes/no questions to identify a hidden opening sentence from a book.

GAME CONTEXT:
- Book/Lecture: {book_name}
- Description: {book_hint}
- Associative Word Domain: {association_word}

STRATEGY:
1. Start with broad questions about theme, genre, time period
2. Narrow down to specific elements: characters, settings, tone
3. Focus on identifying the opening sentence style and content
4. Use the domain hint to guide associative thinking

RULES:
- Generate exactly 20 questions numbered 1-20
- Each question must have 4 options: A, B, C, D
- Options should be: Yes, No, Partially, Cannot determine

OUTPUT FORMAT (JSON only, no other text):
{{
  "questions": [
    {{
      "question_number": 1,
      "question_text": "Your question ending with ?",
      "options": {{
        "A": "Yes",
        "B": "No",
        "C": "Partially",
        "D": "Cannot determine"
      }}
    }}
  ]
}}

Generate 20 questions now:"""


GUESS_PROMPT = """You are playing a 21-Questions game. Based on the answers received, guess the opening sentence and associative word.

GAME CONTEXT:
- Book/Lecture: {book_name}
- Description: {book_hint}
- Associative Word Domain: {association_word}

QUESTIONS AND ANSWERS:
{qa_history}

YOUR TASK:
1. Analyze the pattern of answers
2. Guess the opening sentence of the hidden paragraph
3. Choose an associative word from the domain "{association_word}"

REQUIREMENTS:
- opening_sentence: Your best guess for how the paragraph begins
- sentence_justification: EXACTLY 30-50 words explaining your reasoning
- associative_word: A word from the domain that connects to the content
- word_justification: EXACTLY 20-30 words explaining the connection
- confidence: 0.0-1.0 based on answer clarity

OUTPUT FORMAT (JSON only, no other text):
{{
  "opening_sentence": "The paragraph begins with...",
  "sentence_justification": "Based on the answers to questions about X and Y, combined with negative responses to Z, this opening is suggested because...",
  "associative_word": "your_word",
  "word_justification": "This word connects to the domain because the answers indicate...",
  "confidence": 0.7
}}

Formulate your guess now:"""


def format_warmup_prompt(warmup_question: str) -> str:
    """Format the warmup prompt with the question."""
    return WARMUP_PROMPT.format(warmup_question=warmup_question)


def format_questions_prompt(
    book_name: str,
    book_hint: str,
    association_word: str,
) -> str:
    """Format the questions generation prompt."""
    return QUESTIONS_PROMPT.format(
        book_name=book_name,
        book_hint=book_hint,
        association_word=association_word,
    )


def format_guess_prompt(
    book_name: str,
    book_hint: str,
    association_word: str,
    answers: list[dict],
    questions: list[dict],
) -> str:
    """Format the guess prompt with Q&A history."""
    qa_lines = []
    for i, answer in enumerate(answers):
        q_num = answer.get("question_number", i + 1)
        ans = answer.get("answer", "?")
        # Find matching question text if available
        q_text = f"Question {q_num}"
        for q in questions:
            if q.get("question_number") == q_num:
                q_text = q.get("question_text", q_text)
                break
        qa_lines.append(f"Q{q_num}: {q_text} -> Answer: {ans}")

    qa_history = "\n".join(qa_lines) if qa_lines else "No answers received."

    return GUESS_PROMPT.format(
        book_name=book_name,
        book_hint=book_hint,
        association_word=association_word,
        qa_history=qa_history,
    )
