"""Assignment repository for tracking game assignments."""

from datetime import UTC, datetime

from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import AssignmentModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class AssignmentRepository(BaseRepository[AssignmentModel]):
    """Repository for assignment operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(AssignmentModel, pool)

    def save_assignments(self, season_id: str, assignments: list[dict], round_number: int | None = None) -> int:
        """Bulk insert/update assignments with enriched fields. Returns count."""
        session = self._get_session()
        try:
            for a in assignments:
                rn = round_number or a.get("round_number")
                gn = a.get("game_number")
                existing = session.query(AssignmentModel).filter_by(
                    season_id=season_id, round_number=rn, game_number=gn
                ).first()
                if existing:
                    existing.role = a.get("role", existing.role)
                    existing.my_role = a.get("my_role", existing.my_role)
                    existing.game_id = a.get("game_id", existing.game_id)
                    existing.referee_group_id = a.get("referee_group_id", existing.referee_group_id)
                    existing.opponent_group_id = a.get("opponent_group_id", existing.opponent_group_id)
                else:
                    session.add(AssignmentModel(
                        season_id=season_id, round_number=rn, game_number=gn,
                        role=a.get("role", ""), my_role=a.get("my_role"),
                        game_id=a.get("game_id"), referee_group_id=a.get("referee_group_id"),
                        opponent_group_id=a.get("opponent_group_id"), assignment_status="PENDING",
                    ))
            session.commit()
            return len(assignments)
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Save assignments failed: {e}")
            raise RepositoryError(f"Failed to save assignments: {e}") from e

    def get_by_season(self, season_id: str) -> list[AssignmentModel]:
        """Get all assignments for a season."""
        return self._query_many({"season_id": season_id}, AssignmentModel.round_number)

    def get_by_round(self, season_id: str, round_number: int) -> list[AssignmentModel]:
        """Get assignments filtered by round."""
        return self._query_many(
            {"season_id": season_id, "round_number": round_number},
            AssignmentModel.game_number
        )

    def get_pending(self, season_id: str) -> list[AssignmentModel]:
        """Get pending assignments for a season."""
        return self._query_many(
            {"season_id": season_id, "assignment_status": "PENDING"},
            AssignmentModel.round_number
        )

    def update_status(self, season_id: str, round_number: int, game_number: int, status: str) -> bool:
        """Update assignment status."""
        return self._update_fields(
            {"season_id": season_id, "round_number": round_number, "game_number": game_number},
            {"assignment_status": status}, "update status"
        )

    def mark_started(self, season_id: str, round_number: int, game_number: int) -> bool:
        """Mark assignment as started."""
        return self._update_fields(
            {"season_id": season_id, "round_number": round_number, "game_number": game_number},
            {"assignment_status": "IN_PROGRESS", "started_at": datetime.now(UTC)}, "mark started"
        )

    def get_by_game_id(self, game_id: str) -> AssignmentModel | None:
        """Get assignment by game_id."""
        session = self._get_session()
        try:
            return session.query(AssignmentModel).filter_by(game_id=game_id).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by game_id failed: {e}")
            return None

    def get_referee_for_round(self, season_id: str, round_number: int) -> str | None:
        """Get referee email for a given round. Returns first match."""
        session = self._get_session()
        try:
            model = session.query(AssignmentModel).filter_by(
                season_id=season_id, round_number=round_number
            ).filter(AssignmentModel.referee_group_id.isnot(None)).first()
            return model.referee_group_id if model else None
        except SQLAlchemyError as e:
            self._logger.error(f"Get referee for round failed: {e}")
            return None

    def mark_completed(self, season_id: str, round_number: int, game_number: int) -> bool:
        """Mark assignment as completed."""
        return self._update_fields(
            {"season_id": season_id, "round_number": round_number, "game_number": game_number},
            {"assignment_status": "COMPLETED", "completed_at": datetime.now(UTC)}, "mark completed"
        )
