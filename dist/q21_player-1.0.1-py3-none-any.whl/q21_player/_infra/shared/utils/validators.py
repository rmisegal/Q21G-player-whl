"""
Validation functions for GmailAsPlayer.

Validates emails, envelopes, messages, and game constraints.
"""

import re
from typing import Any

from q21_player._infra.shared.config.constants import (
    MAX_OPENING_JUSTIFICATION_WORDS,
    MAX_QUESTIONS,
    MAX_WORD_JUSTIFICATION_WORDS,
    MIN_OPENING_JUSTIFICATION_WORDS,
    MIN_WORD_JUSTIFICATION_WORDS,
    MessageType,
)

# Email regex pattern
EMAIL_PATTERN = re.compile(
    r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
)


def validate_email(email: str) -> bool:
    """
    Validate email address format.

    Args:
        email: Email address to validate

    Returns:
        True if valid, False otherwise
    """
    if not email or not isinstance(email, str):
        return False
    return bool(EMAIL_PATTERN.match(email.strip()))


def validate_envelope(envelope: dict[str, Any]) -> tuple[bool, str | None]:
    """
    Validate a message envelope structure.

    Args:
        envelope: Dictionary containing message envelope

    Returns:
        Tuple of (is_valid, error_message)
    """
    required_fields = ["protocol_version", "sender_role", "sender_email",
                       "transaction_id", "message_type", "timestamp"]

    for field in required_fields:
        if field not in envelope:
            return False, f"Missing required field: {field}"

    if not validate_email(envelope.get("sender_email", "")):
        return False, "Invalid sender email format"

    return True, None


def validate_message_type(msg_type: str) -> bool:
    """
    Validate that a message type is recognized.

    Args:
        msg_type: Message type string to validate

    Returns:
        True if valid MessageType enum value
    """
    try:
        MessageType(msg_type)
        return True
    except ValueError:
        return False


def validate_question_batch(questions: list[dict[str, Any]]) -> tuple[bool, str | None]:
    """
    Validate a batch of questions according to Q21 rules.

    Rules:
    - Exactly 20 questions
    - Each question must have text and 4 options (A, B, C, D)

    Args:
        questions: List of question dictionaries

    Returns:
        Tuple of (is_valid, error_message)
    """
    if len(questions) != MAX_QUESTIONS:
        return False, f"Expected {MAX_QUESTIONS} questions, got {len(questions)}"

    for i, q in enumerate(questions):
        if "text" not in q:
            return False, f"Question {i+1} missing 'text' field"
        if "options" not in q:
            return False, f"Question {i+1} missing 'options' field"

        options = q.get("options", {})
        required_options = ["A", "B", "C", "D"]
        for opt in required_options:
            if opt not in options:
                return False, f"Question {i+1} missing option '{opt}'"

    return True, None


def validate_justification_word_count(
    text: str, min_words: int, max_words: int
) -> tuple[bool, str | None]:
    """
    Validate that justification text meets word count requirements.

    Args:
        text: Justification text
        min_words: Minimum word count
        max_words: Maximum word count

    Returns:
        Tuple of (is_valid, error_message)
    """
    word_count = len(text.split())
    if word_count < min_words:
        return False, f"Justification too short: {word_count} words (min: {min_words})"
    if word_count > max_words:
        return False, f"Justification too long: {word_count} words (max: {max_words})"
    return True, None


def validate_opening_justification(text: str) -> tuple[bool, str | None]:
    """Validate opening sentence justification (30-50 words)."""
    return validate_justification_word_count(
        text, MIN_OPENING_JUSTIFICATION_WORDS, MAX_OPENING_JUSTIFICATION_WORDS
    )


def validate_word_justification(text: str) -> tuple[bool, str | None]:
    """Validate associative word justification (20-30 words)."""
    return validate_justification_word_count(
        text, MIN_WORD_JUSTIFICATION_WORDS, MAX_WORD_JUSTIFICATION_WORDS
    )
