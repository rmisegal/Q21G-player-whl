"""Result Handler for Q21_GUESS_RESULT messages."""

from decimal import Decimal
from typing import Any

from q21_player._infra.cli.handlers.base_game_handler import BaseGameHandler
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.game_result_repository import GameResultRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository


class ResultHandler(BaseGameHandler):
    """Handles Q21_GUESS_RESULT message processing."""

    def __init__(
        self,
        state_repo: GameStateRepository | None = None,
        game_repo: GameRepository | None = None,
        result_repo: GameResultRepository | None = None,
    ):
        super().__init__(state_repo=state_repo, game_repo=game_repo)
        self._result_repo = result_repo or GameResultRepository()

    def process(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Process Q21_GUESS_RESULT message.

        Args:
            payload: Result payload with scores and feedback

        Returns:
            dict with match_id and result summary
        """
        match_id = payload.get("match_id", "")
        total_score = payload.get("total_score") or payload.get("private_score", 0.0)
        season_id = payload.get("season_id")

        # Extract score breakdown
        breakdown = {
            "opening_sentence_score": payload.get("opening_sentence_score"),
            "sentence_justification_score": payload.get("sentence_justification_score"),
            "associative_word_score": payload.get("associative_word_score"),
            "word_justification_score": payload.get("word_justification_score"),
        }

        # Extract feedback
        feedback = {
            "opening_sentence_feedback": payload.get("opening_sentence_feedback"),
            "word_feedback": payload.get("word_feedback"),
        }

        # Extract actual values
        actuals = {
            "actual_opening_sentence": payload.get("actual_opening_sentence"),
            "actual_associative_word": payload.get("actual_associative_word"),
        }

        # Store result
        self._result_repo.save_result(
            match_id=match_id,
            total_score=Decimal(str(total_score)),
            breakdown=breakdown,
            feedback=feedback,
            actuals=actuals,
            season_id=season_id,
        )

        # Update phase
        self._state_repo.update_phase(match_id, "COMPLETE")

        # Mark game as completed
        is_correct = total_score >= 50.0  # Consider 50+ as a "win"
        self._game_repo.complete_game(match_id, is_correct=is_correct, score=total_score)

        self._logger.info(f"Result for match {match_id}: score={total_score}")
        return {"match_id": match_id, "total_score": total_score, "is_correct": is_correct}
