"""
Gmail scanner for polling and filtering league emails.
"""

import time
from collections.abc import Callable
from typing import Any

from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.shared.config.constants import (
    MAX_SCAN_RESULTS,
    PROTOCOL_VERSION,
    RATE_LIMIT_ACQUIRE_TIMEOUT_SEC,
)
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.logging.logger import get_logger
from q21_player._infra.shared.threading.rate_limiter import GmailRateLimiter
from q21_player._infra.shared.threading.watchdog import PollingWatchdog


class GmailScanner:
    """Scanner for polling Gmail inbox for league messages."""

    def __init__(self, client: GmailClient) -> None:
        self._client = client
        self._config = Config()
        self._logger = get_logger("gmail.scanner")
        self._rate_limiter = GmailRateLimiter()
        self._watchdog: PollingWatchdog | None = None
        self._running = False
        self._last_history_id: str | None = None

    def build_league_query(self, manager_email: str | None = None) -> str:
        """Build Gmail search query for league messages."""
        # Note: No from: filter - sender validation done by gatekeeper/SenderValidator
        return f"subject:{PROTOCOL_VERSION} is:unread"

    def scan_once(self, query: str | None = None) -> list[dict[str, Any]]:
        """Perform a single scan for matching emails."""
        t0 = time.perf_counter()
        if not self._rate_limiter.acquire(timeout=RATE_LIMIT_ACQUIRE_TIMEOUT_SEC):
            self._logger.warning("Rate limit reached, skipping scan")
            return []

        search_query = query or self.build_league_query()
        self._logger.debug(f"Scanning with query: {search_query}")

        t1 = time.perf_counter()
        result = self._client.list_messages(query=search_query, max_results=MAX_SCAN_RESULTS)
        t2 = time.perf_counter()
        self._logger.info(f"[TIMING] scan:list_messages: {(t2-t1)*1000:.1f}ms")
        messages = result.get("messages", [])

        if not messages:
            return []

        detailed_messages = []
        for i, msg in enumerate(messages):
            if self._rate_limiter.acquire(timeout=RATE_LIMIT_ACQUIRE_TIMEOUT_SEC):
                t3 = time.perf_counter()
                full_msg = self._client.get_message(msg["id"])
                t4 = time.perf_counter()
                self._logger.info(f"[TIMING] scan:get_message[{i}]: {(t4-t3)*1000:.1f}ms")
                detailed_messages.append(full_msg)
        self._logger.info(f"[TIMING] scan:total: {(time.perf_counter()-t0)*1000:.1f}ms")
        return detailed_messages

    def start_periodic(
        self, callback: Callable[[list[dict[str, Any]]], None],
        interval_sec: int | None = None
    ) -> None:
        """Start periodic scanning."""
        interval = interval_sec or self._config.app.poll_interval_sec
        self._running = True
        self._watchdog = PollingWatchdog(
            timeout_seconds=interval * 3,
            on_timeout=lambda: self._logger.error("Polling watchdog timeout")
        )
        self._watchdog.start()
        self._logger.info(f"Started periodic scanning (interval: {interval}s)")

        while self._running:
            self._watchdog.heartbeat()
            try:
                messages = self.scan_once()
                if messages:
                    callback(messages)
            except Exception as e:
                self._logger.error(f"Scan error: {e}")
            time.sleep(interval)

    def stop_periodic(self) -> None:
        """Stop periodic scanning."""
        self._running = False
        if self._watchdog:
            self._watchdog.stop()
        self._logger.info("Stopped periodic scanning")

    def mark_as_read(self, message_id: str) -> None:
        """Mark a message as read."""
        self._client.modify_message(message_id, remove_labels=["UNREAD"])

    def mark_as_processed(self, message_id: str, label: str = "PROCESSED") -> None:
        """Mark a message as processed with custom label."""
        self._client.modify_message(message_id, add_labels=[label])
