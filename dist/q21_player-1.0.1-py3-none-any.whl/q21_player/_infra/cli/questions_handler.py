"""Questions Handler for Q21_QUESTIONS_CALL messages."""

from typing import Any

from q21_player._infra.cli.handlers.base_game_handler import BaseGameHandler
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository
from q21_player._infra.strategy.strategy_factory import get_strategy


class QuestionsHandler(BaseGameHandler):
    """Handles Q21_QUESTIONS_CALL message processing."""

    def __init__(
        self,
        state_repo: GameStateRepository | None = None,
        game_repo: GameRepository | None = None,
    ):
        super().__init__(state_repo=state_repo, game_repo=game_repo)
        self._strategy = get_strategy()

    def process(self, payload: dict[str, Any]) -> dict[str, Any]:
        """Process Q21_QUESTIONS_CALL message.

        Args:
            payload: Questions call payload with match_id and deadline

        Returns:
            dict with match_id and generated questions
        """
        match_id = payload.get("match_id", "")
        deadline_str = payload.get("deadline", "")

        # Store deadline using helper
        deadline = self._parse_deadline(deadline_str)
        if deadline:
            self._state_repo.set_questions_deadline(match_id, deadline)

        # Get game context using helper
        context = self._get_game_context(match_id)

        # Generate questions using strategy
        result = self._strategy.generate_questions(context)
        if not result.success:
            self._logger.error(f"Question generation failed: {result.error}")
            return {"match_id": match_id, "error": result.error}

        # Convert to storage format
        questions_data = []
        for q in result.data.questions:
            questions_data.append({
                "question_number": q.number,
                "question_text": q.text,
                "options": q.options.model_dump() if q.options else None,
            })

        # Store questions
        self._game_repo.save_questions(match_id, questions_data)

        # Update phase
        self._state_repo.update_phase(match_id, "QUESTIONS_SENT")

        self._logger.info(f"Generated {len(questions_data)} questions for match {match_id}")
        return {"match_id": match_id, "questions": questions_data}
