"""Scan result dataclass for tracking scan operations."""

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class ScanResult:
    """Result of a scan operation."""
    started_at: datetime = field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None
    emails_found: int = 0
    emails_processed: int = 0
    emails_skipped: int = 0
    emails_rejected: int = 0
    responses_sent: int = 0
    errors: list[str] = field(default_factory=list)
    status: str = "PENDING"

    def complete(self, status: str = "COMPLETED") -> None:
        self.completed_at = datetime.utcnow()
        self.status = status

    @property
    def duration_ms(self) -> float:
        if not self.completed_at:
            return 0
        return (self.completed_at - self.started_at).total_seconds() * 1000

    @property
    def summary(self) -> str:
        return (f"Scan {self.status}: found={self.emails_found}, processed={self.emails_processed}, "
                f"responses={self.responses_sent}, skipped={self.emails_skipped}, rejected={self.emails_rejected}, "
                f"errors={len(self.errors)}, duration={self.duration_ms:.0f}ms")
