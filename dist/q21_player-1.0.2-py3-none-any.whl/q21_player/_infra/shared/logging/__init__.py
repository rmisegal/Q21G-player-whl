"""
Logging module for GmailAsPlayer.

Provides:
- StandardLogger: Main application logger with JSON config
- BatchLogger: Game progress tracking
- PerformanceLogger: Metrics and timing
- SensitiveFilter: Mask auth tokens in logs
- ProtocolLogger: Protocol-aware colored output
"""

from q21_player._infra.shared.logging.batch_logger import BatchLogger
from q21_player._infra.shared.logging.logger import StandardLogger, get_logger
from q21_player._infra.shared.logging.performance_logger import PerformanceLogger
from q21_player._infra.shared.logging.protocol_logger import (
    ProtocolLogger,
    log_received,
    log_sent,
    log_rejected,
    log_error,
    log_callback_call,
    log_callback_response,
    set_season_context,
    set_round_context,
    set_game_context,
)
from q21_player._infra.shared.logging.sensitive_filter import SensitiveFilter

__all__ = [
    "StandardLogger",
    "get_logger",
    "BatchLogger",
    "PerformanceLogger",
    "SensitiveFilter",
    "ProtocolLogger",
    "log_received",
    "log_sent",
    "log_rejected",
    "log_error",
    "log_callback_call",
    "log_callback_response",
    "set_season_context",
    "set_round_context",
    "set_game_context",
]
