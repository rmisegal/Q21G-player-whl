"""Message context model for shared header fields."""
from typing import Any

from pydantic import BaseModel, Field


class MessageContext(BaseModel):
    """Context fields shared across protocol messages.

    Contains league, season, round, and game identifiers that provide
    context for message routing and correlation.
    """

    league_id: str | None = Field(default=None, description="League identifier")
    season_id: str | None = Field(default=None, description="Season identifier")
    round_id: str | None = Field(default=None, description="Round identifier")
    game_id: str | None = Field(default=None, description="Game/match identifier")

    def is_empty(self) -> bool:
        """Check if all context fields are None."""
        return all(
            v is None for v in [self.league_id, self.season_id, self.round_id, self.game_id]
        )

    def to_dict(self) -> dict[str, str | None]:
        """Convert to dictionary for JSON serialization."""
        return {
            "league_id": self.league_id,
            "season_id": self.season_id,
            "round_id": self.round_id,
            "game_id": self.game_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MessageContext":
        """Create from dictionary."""
        return cls(
            league_id=data.get("league_id"),
            season_id=data.get("season_id"),
            round_id=data.get("round_id"),
            game_id=data.get("game_id"),
        )
