"""ORM models for messaging, logging, and state tracking."""
from datetime import UTC, datetime
from sqlalchemy import Boolean, Column, DateTime, Integer, JSON, String, Text

from q21_player._infra.repository.orm_core_models import Base

def _now() -> datetime: return datetime.now(UTC)


class AttachmentModel(Base):
    __tablename__ = "attachments"
    id = Column(Integer, primary_key=True, autoincrement=True)
    internal_filename = Column(String(255), unique=True, nullable=False, index=True)
    original_filename, message_id = Column(String(255), nullable=False, index=True), Column(String(100), nullable=False, index=True)
    mime_type, size_bytes, checksum = Column(String(100), nullable=True), Column(Integer, default=0), Column(String(64), nullable=True)
    created_at = Column(DateTime, default=_now)


class MessageLogModel(Base):
    __tablename__ = "message_logs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    gmail_id = Column(String(100), unique=True, nullable=False, index=True)
    thread_id, direction = Column(String(100), nullable=True, index=True), Column(String(10), nullable=False)
    message_type, transaction_id = Column(String(100), nullable=False, index=True), Column(String(100), nullable=True, index=True)
    sender_email, recipient_email = Column(String(255), nullable=False), Column(String(255), nullable=False)
    subject, payload, game_id = Column(Text, nullable=True), Column(JSON, nullable=True), Column(String(100), nullable=True, index=True)
    league_id = Column(String(100), nullable=True, index=True)
    round_id = Column(String(100), nullable=True)
    processed, error_message = Column(Boolean, default=False), Column(Text, nullable=True)
    created_at, processed_at = Column(DateTime, default=_now), Column(DateTime, nullable=True)


class BroadcastReceivedModel(Base):
    __tablename__ = "broadcasts_received"
    id = Column(Integer, primary_key=True, autoincrement=True)
    broadcast_id = Column(String(100), unique=True, nullable=False, index=True)
    message_type, league_id = Column(String(100), nullable=False, index=True), Column(String(100), nullable=True, index=True)
    round_id, payload, message_text = Column(String(100), nullable=True), Column(JSON, nullable=True), Column(String(500), nullable=True)
    response_required, response_sent = Column(Boolean, default=False), Column(Boolean, default=False)
    response_txid, received_at = Column(String(100), nullable=True), Column(DateTime, default=_now)
    responded_at = Column(DateTime, nullable=True)


class PauseStateModel(Base):
    __tablename__ = "pause_state"
    id = Column(Integer, primary_key=True, autoincrement=True)
    broadcast_id, previous_state = Column(String(100), nullable=False, index=True), Column(String(50), nullable=False)
    previous_match_id, saved_context = Column(String(100), nullable=True), Column(JSON, nullable=True)
    paused_at, resumed_at = Column(DateTime, default=_now), Column(DateTime, nullable=True)
    resume_broadcast_id = Column(String(100), nullable=True)


class StateTransitionModel(Base):
    __tablename__ = "state_transitions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    player_email = Column(String(255), nullable=False, index=True)
    from_state, to_state = Column(String(50), nullable=False), Column(String(50), nullable=False)
    event, transition_metadata = Column(String(50), nullable=False, index=True), Column(JSON, nullable=True)
    created_at = Column(DateTime, default=_now, index=True)


class MessageCorrelationModel(Base):
    __tablename__ = "message_correlations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    request_type = Column(String(100), nullable=False)
    request_id = Column(String(100), nullable=False, index=True)
    request_gmail_id = Column(String(100), nullable=True)
    response_type = Column(String(100), nullable=True)
    response_id = Column(String(100), nullable=True, index=True)
    response_gmail_id = Column(String(100), nullable=True)
    correlated_at = Column(DateTime, default=_now)


class ErrorLogModel(Base):
    __tablename__ = "error_logs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    error_type = Column(String(50), nullable=False, index=True)
    error_code = Column(String(50), nullable=True)
    error_message = Column(Text, nullable=False)
    context = Column(JSON, nullable=True)
    stack_trace = Column(Text, nullable=True)
    created_at = Column(DateTime, default=_now)
    resolved_at = Column(DateTime, nullable=True)
    resolution_notes = Column(Text, nullable=True)
