"""
Gmail-related exceptions for GmailAsPlayer.

Covers Gmail API errors, authentication, and rate limiting.
"""

from typing import Any

from q21_player._infra.shared.exceptions.base import PlayerError


class GmailError(PlayerError):
    """Base exception for Gmail-related errors."""

    def __init__(
        self,
        message: str,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, code or "GMAIL_ERROR", details)


class GmailConnectionError(GmailError):
    """Error connecting to Gmail API."""

    def __init__(
        self,
        message: str = "Failed to connect to Gmail API",
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, "GMAIL_CONNECTION_ERROR", details)


class GmailAuthenticationError(GmailError):
    """Gmail authentication/authorization error."""

    def __init__(
        self,
        message: str = "Gmail authentication failed",
        details: dict[str, Any] | None = None,
    ) -> None:
        super().__init__(message, "GMAIL_AUTH_ERROR", details)


class GmailRateLimitError(GmailError):
    """Gmail API rate limit exceeded."""

    def __init__(
        self,
        message: str = "Gmail API rate limit exceeded",
        retry_after: int | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        details = details or {}
        if retry_after:
            details["retry_after_seconds"] = retry_after
        super().__init__(message, "GMAIL_RATE_LIMIT", details)
        self.retry_after = retry_after


class GmailSendError(GmailError):
    """Error sending email via Gmail."""

    def __init__(
        self,
        message: str = "Failed to send email",
        recipient: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        details = details or {}
        if recipient:
            details["recipient"] = recipient
        super().__init__(message, "GMAIL_SEND_ERROR", details)


class GmailAttachmentError(GmailError):
    """Error processing email attachment."""

    def __init__(
        self,
        message: str = "Failed to process attachment",
        filename: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        details = details or {}
        if filename:
            details["filename"] = filename
        super().__init__(message, "GMAIL_ATTACHMENT_ERROR", details)
