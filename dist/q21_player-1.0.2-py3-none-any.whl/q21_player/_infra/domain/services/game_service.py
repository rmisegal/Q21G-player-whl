"""Game service for match-specific operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from q21_player._infra.domain.models.answer import AnswerBatch
from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.domain.models.guess import Guess, GuessResult
from q21_player._infra.domain.models.question import QuestionBatch
from q21_player._infra.shared.config.constants import PlayerState
from q21_player._infra.shared.logging.logger import get_logger

if TYPE_CHECKING:
    from q21_player._infra.repository.game_repository import GameRepository


@dataclass
class GameSession:
    game_id: str
    book_name: str
    description: str
    domain: str
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    questions_sent: QuestionBatch | None = None
    answers_received: AnswerBatch | None = None
    guess_sent: Guess | None = None
    result: GuessResult | None = None
    ended_at: datetime | None = None


class GameService:
    def __init__(self, player_email: str, repository: GameRepository | None = None):
        self._logger = get_logger("game_service")
        self._player_email = player_email
        self._repository = repository
        self._current_session: GameSession | None = None

    @property
    def current_session(self) -> GameSession | None: return self._current_session
    @property
    def is_in_game(self) -> bool: return self._current_session is not None
    @property
    def completed_games(self) -> int:
        return self._repository.get_statistics(self._player_email).get("completed", 0) if self._repository else 0

    def start_game(self, game_id: str, book_name: str, description: str, domain: str) -> GameSession:
        if self._current_session:
            self._logger.warning(f"Ending previous session: {self._current_session.game_id}")
            self.end_game(abandoned=True)
        self._current_session = GameSession(game_id=game_id, book_name=book_name, description=description, domain=domain)
        if self._repository:
            from q21_player._infra.repository.orm_models import GameSessionModel
            self._repository.create(GameSessionModel(game_id=game_id, player_email=self._player_email,
                book_name=book_name, description=description, domain=domain))
        self._logger.info(f"Started game: {game_id} - {book_name}")
        return self._current_session

    def record_questions(self, batch: QuestionBatch) -> None:
        if self._current_session:
            self._current_session.questions_sent = batch
            if self._repository and batch.questions:
                questions = [{"question_number": q.question_number, "question_text": q.question_text,
                    "options": getattr(q, "options", None)} for q in batch.questions]
                self._repository.save_questions(self._current_session.game_id, questions)

    def record_answers(self, batch: AnswerBatch) -> None:
        if self._current_session:
            self._current_session.answers_received = batch
            if self._repository and batch.answers:
                answers = [{"question_number": a.question_number, "selected_option": a.selected_option}
                    for a in batch.answers]
                self._repository.save_answers(self._current_session.game_id, answers)

    def record_guess(self, guess: Guess) -> None:
        if self._current_session:
            self._current_session.guess_sent = guess
            if self._repository:
                self._repository.save_guess(self._current_session.game_id, {
                    "opening_sentence": guess.opening_sentence,
                    "sentence_justification": getattr(guess, "sentence_justification", None),
                    "associative_word": getattr(guess, "associative_word", None),
                    "word_justification": getattr(guess, "word_justification", None),
                    "confidence": getattr(guess, "confidence", None),
                    "strategy_used": getattr(guess, "strategy_used", None),
                })

    def record_result(self, result: GuessResult) -> None:
        if self._current_session:
            self._current_session.result = result
            self._logger.info(f"Game result: correct={result.is_correct}")

    def get_qa_history(self) -> list[dict]:
        if not self._current_session or not self._current_session.questions_sent or not self._current_session.answers_received:
            return []
        answer_map = {a.question_number: a for a in self._current_session.answers_received.answers}
        return [{"number": q.question_number, "question": q.question_text,
            "answer": answer_map.get(q.question_number).selected_option if answer_map.get(q.question_number) else None}
            for q in self._current_session.questions_sent.questions]

    def build_context(self) -> GameContext | None:
        if not (s := self._current_session):
            return None
        return GameContext(game_id=s.game_id, player_email=self._player_email, player_name="",
            current_state=PlayerState.IN_MATCH, book_name=s.book_name,
            general_description=s.description, associative_domain=s.domain, question_history=self.get_qa_history())

    def end_game(self, abandoned: bool = False) -> GameSession | None:
        if not (session := self._current_session):
            return None
        session.ended_at = datetime.now(UTC)
        if self._repository:
            if abandoned:
                self._repository.abandon_game(session.game_id)
            else:
                is_correct = session.result.is_correct if session.result else False
                score = session.result.score if session.result and hasattr(session.result, "score") else 0.0
                self._repository.complete_game(session.game_id, is_correct, score)
        self._current_session = None
        self._logger.info(f"Game {'abandoned' if abandoned else 'completed'}: {session.game_id}")
        return session

    def get_statistics(self) -> dict:
        if self._repository:
            stats = self._repository.get_statistics(self._player_email)
            stats["in_progress"] = self._current_session is not None
            return stats
        return {"total_games": 0, "wins": 0, "losses": 0, "win_rate": 0.0,
                "in_progress": self._current_session is not None}

    def reset(self) -> None:
        if self._current_session:
            self.end_game(abandoned=True)
        self._logger.info("Game service reset")
