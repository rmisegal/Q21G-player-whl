"""
Shared Layer - Common utilities and configuration for GmailAsPlayer.

This module provides:
- Configuration management (settings, constants)
- Logging utilities
- Common exceptions
- Threading and synchronization primitives
- Dependency injection container
"""

from q21_player._infra.shared.config.constants import (
    MessageType,
    PlayerState,
    UserRole,
)
from q21_player._infra.shared.config.settings import Config

__all__ = [
    "Config",
    "MessageType",
    "PlayerState",
    "UserRole",
]
