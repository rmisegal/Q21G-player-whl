"""
Message models for GmailAsPlayer.

Incoming and outgoing message structures.
"""

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

from q21_player._infra.domain.models.envelope import Envelope
from q21_player._infra.shared.config.constants import DEFAULT_ATTACHMENT_NAME, MessageType


class IncomingMessage(BaseModel):
    """Represents an incoming email message from Gmail."""

    gmail_id: str = Field(..., description="Gmail message ID")
    thread_id: str = Field(..., description="Gmail thread ID")
    envelope: Envelope = Field(..., description="Parsed protocol envelope")
    payload: dict[str, Any] = Field(
        default_factory=dict,
        description="JSON payload from attachment"
    )
    received_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When message was received"
    )
    raw_subject: str = Field(default="", description="Original subject line")
    processed: bool = Field(default=False, description="Whether message was processed")

    @property
    def message_type(self) -> MessageType:
        return self.envelope.message_type

    @property
    def sender(self) -> str:
        return self.envelope.sender_email

    @property
    def transaction_id(self) -> str:
        return self.envelope.transaction_id

    def mark_processed(self) -> "IncomingMessage":
        """Return copy marked as processed."""
        return self.model_copy(update={"processed": True})

    def get_payload_field(self, field: str, default: Any = None) -> Any:
        """Get a field from the payload."""
        return self.payload.get(field, default)


class OutgoingMessage(BaseModel):
    """Represents an outgoing email message."""

    envelope: Envelope = Field(..., description="Protocol envelope")
    payload: dict[str, Any] = Field(
        default_factory=dict,
        description="JSON payload for attachment"
    )
    body_text: str = Field(
        default="",
        description="Plain text email body"
    )
    attachment_name: str = Field(
        default=DEFAULT_ATTACHMENT_NAME,
        description="Attachment filename"
    )
    created_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    sent_at: datetime | None = Field(default=None)
    gmail_id: str | None = Field(default=None, description="Gmail ID after sending")

    @property
    def recipient(self) -> str:
        return self.envelope.recipient_email

    @property
    def subject(self) -> str:
        return self.envelope.to_subject_line()

    @property
    def message_type(self) -> MessageType:
        return self.envelope.message_type

    def mark_sent(self, gmail_id: str) -> "OutgoingMessage":
        """Return copy marked as sent."""
        return self.model_copy(update={
            "sent_at": datetime.now(UTC),
            "gmail_id": gmail_id,
        })

    @classmethod
    def create_reply(
        cls,
        original: IncomingMessage,
        reply_type: MessageType,
        sender_email: str,
        transaction_id: str,
        payload: dict[str, Any],
        body_text: str = "",
    ) -> "OutgoingMessage":
        """Create a reply to an incoming message."""
        reply_envelope = original.envelope.create_reply(
            reply_type=reply_type,
            new_sender=sender_email,
            new_txid=transaction_id,
        )
        return cls(
            envelope=reply_envelope,
            payload=payload,
            body_text=body_text,
        )
