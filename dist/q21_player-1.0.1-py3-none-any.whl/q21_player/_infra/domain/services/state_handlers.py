"""State handlers for GmailAsPlayer - per-state action handlers."""

from abc import ABC, abstractmethod
from typing import Any

from q21_player._infra.domain.models.game_context import GameContext
from q21_player._infra.domain.models.messages import IncomingMessage
from q21_player._infra.shared.config.constants import PlayerState
from q21_player._infra.shared.logging.logger import get_logger


class StateHandler(ABC):
    def __init__(self):
        self._logger = get_logger(f"handler.{self.state.value.lower()}")

    @property
    @abstractmethod
    def state(self) -> PlayerState:
        pass

    @abstractmethod
    def handle(self, message: IncomingMessage, context: GameContext | None) -> dict[str, Any]:
        pass

    def on_enter(self, context: GameContext | None) -> None:
        self._logger.debug(f"Entered state: {self.state.value}")

    def on_exit(self, context: GameContext | None) -> None:
        self._logger.debug(f"Exiting state: {self.state.value}")


class IdleHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.INIT_START_STATE
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "none", "message": "Player is idle"}


class RegisteringHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.REGISTERING
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "await_registration_response"}


class RegisteredHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.REGISTERED
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "check_for_invitations"}


class InvitedHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.INVITED
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "process_invitation", "should_accept": True}


class InMatchHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.IN_MATCH
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "prepare_questions", "game_id": ctx.game_id if ctx else None}


class QuestioningHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.QUESTIONING
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "generate_and_submit_questions"}


class AwaitingAnswersHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.AWAITING_ANSWERS
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "process_answers", "answers_in_message": True}


class GuessingHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.GUESSING
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "generate_and_submit_guess"}


class MatchCompleteHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.MATCH_COMPLETE
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "process_result", "return_to_registered": True}


class ErrorHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.ERROR
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "await_reset", "error_state": True}


class WarmupHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.WARMUP
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "process_warmup", "game_id": ctx.game_id if ctx else None}


class PausedHandler(StateHandler):
    @property
    def state(self) -> PlayerState: return PlayerState.PAUSED
    def handle(self, msg: IncomingMessage, ctx: GameContext | None) -> dict[str, Any]:
        return {"action": "await_continue", "paused": True, "ignore_non_manager": True}
    def on_enter(self, context: GameContext | None) -> None:
        self._logger.info("Agent PAUSED - only accepting League Manager messages")
    def on_exit(self, context: GameContext | None) -> None:
        self._logger.info("Agent resuming from PAUSED state")


_HANDLERS: dict[PlayerState, type[StateHandler]] = {
    PlayerState.INIT_START_STATE: IdleHandler, PlayerState.REGISTERING: RegisteringHandler,
    PlayerState.REGISTERED: RegisteredHandler, PlayerState.INVITED: InvitedHandler,
    PlayerState.IN_MATCH: InMatchHandler, PlayerState.WARMUP: WarmupHandler,
    PlayerState.QUESTIONING: QuestioningHandler, PlayerState.AWAITING_ANSWERS: AwaitingAnswersHandler,
    PlayerState.GUESSING: GuessingHandler, PlayerState.MATCH_COMPLETE: MatchCompleteHandler,
    PlayerState.PAUSED: PausedHandler, PlayerState.ERROR: ErrorHandler,
}
_handler_instances: dict[PlayerState, StateHandler] = {}


def get_handler(state: PlayerState) -> StateHandler:
    if state not in _handler_instances:
        if (handler_class := _HANDLERS.get(state)) is None:
            raise ValueError(f"No handler for state: {state}")
        _handler_instances[state] = handler_class()
    return _handler_instances[state]
