"""Protocol configuration dataclass for loading protocol definitions from JSON."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class SubjectFormat:
    """Subject line format configuration."""

    delimiter: str
    parts: list[str]
    min_parts: int
    max_parts: int
    context_parts: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SubjectFormat:
        """Create SubjectFormat from dictionary."""
        return cls(
            delimiter=data.get("delimiter", "::"),
            parts=data.get("parts", []),
            min_parts=data.get("min_parts", 5),
            max_parts=data.get("max_parts", 5),
            context_parts=data.get("context_parts", []),
        )


@dataclass
class ProtocolConfig:
    """Protocol configuration loaded from JSON file."""

    protocol_id: str
    subject_format: SubjectFormat
    roles: list[str]
    message_types: dict[str, list[str]]
    handler_mapping: dict[str, str]
    description: str = ""
    type_aliases: dict[str, str] = field(default_factory=dict)
    broadcast_types: list[str] = field(default_factory=list)
    response_types: dict[str, str] = field(default_factory=dict)
    response_required_broadcasts: list[str] = field(default_factory=list)

    @classmethod
    def from_json_file(cls, file_path: Path | str) -> ProtocolConfig:
        """Load protocol config from JSON file."""
        path = Path(file_path)
        with path.open() as f:
            data = json.load(f)
        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ProtocolConfig:
        """Create ProtocolConfig from dictionary."""
        return cls(
            protocol_id=data.get("protocol_id", ""),
            description=data.get("description", ""),
            subject_format=SubjectFormat.from_dict(data.get("subject_format", {})),
            roles=data.get("roles", []),
            message_types=data.get("message_types", {}),
            handler_mapping=data.get("handler_mapping", {}),
            type_aliases=data.get("type_aliases", {}),
            broadcast_types=data.get("broadcast_types", []),
            response_types=data.get("response_types", {}),
            response_required_broadcasts=data.get("response_required_broadcasts", []),
        )

    def get_handler_name(self, message_type: str) -> str | None:
        """Get handler name for a message type."""
        return self.handler_mapping.get(message_type)

    def normalize_message_type(self, message_type: str) -> str:
        """Normalize message type using aliases (e.g., Q21WARMUPCALL -> Q21_WARMUP_CALL)."""
        return self.type_aliases.get(message_type, message_type)

    def get_all_message_types(self) -> list[str]:
        """Get flattened list of all message types across all categories."""
        result = []
        for types in self.message_types.values():
            result.extend(types)
        return result

    def is_broadcast_type(self, message_type: str) -> bool:
        """Check if message type is a broadcast type."""
        return message_type in self.broadcast_types

    def get_response_type(self, message_type: str) -> str | None:
        """Get the expected response type for a message type."""
        return self.response_types.get(message_type)

    def requires_broadcast_response(self, message_type: str) -> bool:
        """Check if broadcast type requires a response."""
        return message_type in self.response_required_broadcasts
