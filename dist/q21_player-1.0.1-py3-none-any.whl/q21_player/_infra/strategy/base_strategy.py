"""Base strategy interface for GmailAsPlayer."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

from q21_player._infra.domain.models.game_context import GameContext


@dataclass
class StrategyResult:
    """Result from a strategy operation."""
    success: bool
    data: Any = None
    error: str | None = None
    confidence: float = 0.5
    metadata: dict[str, Any] = field(default_factory=dict)


class IGameStrategy(ABC):
    """Abstract base class for game strategies.

    Implementations must provide:
    - name: Strategy identifier
    - generate_questions: Create 20 questions for the game
    - formulate_guess: Make final guess based on answers
    - get_warmup_answer: Answer the warmup math question
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Strategy name identifier."""
        pass

    @abstractmethod
    def generate_questions(self, context: GameContext) -> StrategyResult:
        """
        Generate 20 questions based on game context.

        Args:
            context: Game context with book info and description

        Returns:
            StrategyResult containing QuestionBatch
        """
        pass

    @abstractmethod
    def formulate_guess(self, context: GameContext) -> StrategyResult:
        """
        Formulate final guess based on Q&A history.

        Args:
            context: Game context with question/answer history

        Returns:
            StrategyResult containing Guess
        """
        pass

    @abstractmethod
    def get_warmup_answer(self, question: str) -> str:
        """
        Answer the warmup question.

        Args:
            question: The warmup question (usually math)

        Returns:
            Answer string
        """
        pass
