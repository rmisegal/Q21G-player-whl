"""Configuration management for GmailAsPlayer."""
import json
import os
from pathlib import Path
from typing import Any, Optional

from dotenv import load_dotenv


class DotDict(dict):
    def __getattr__(self, key: str) -> Any:
        try:
            value = self[key]
            return DotDict(value) if isinstance(value, dict) else value
        except KeyError:
            raise AttributeError(f"Config has no attribute '{key}'") from None

    def __setattr__(self, key: str, value: Any) -> None:
        self[key] = value

    def get_nested(self, path: str, default: Any = None) -> Any:
        keys, value = path.split("."), self
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        return value


class Config:
    _instance: Optional["Config"] = None
    _initialized: bool = False

    def __new__(cls) -> "Config":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self) -> None:
        if Config._initialized:
            return
        Config._initialized = True
        self._config = DotDict()
        self._project_root = self._find_project_root()
        self._load_env()
        self._load_json_config()

    def _find_project_root(self) -> Path:
        current = Path(__file__).resolve()
        for parent in current.parents:
            if (parent / "pyproject.toml").exists():
                return parent
        return Path.cwd()

    def _load_env(self) -> None:
        env_path = self._project_root / ".env"
        if env_path.exists():
            load_dotenv(env_path)
        self._config["gmail"] = DotDict({"credentials_path": os.getenv("GMAIL_CREDENTIALS_PATH", ""),
            "token_path": os.getenv("GMAIL_TOKEN_PATH", ""), "account": os.getenv("GMAIL_ACCOUNT", "")})
        self._config["database"] = DotDict({"host": os.getenv("GTAI_DB_HOST", ""),
            "port": int(os.getenv("GTAI_DB_PORT", "0")), "name": os.getenv("GTAI_DB_NAME", ""),
            "user": os.getenv("GTAI_DB_USER", ""), "password": os.getenv("GTAI_DB_PASSWORD", "")})
        self._config["app"] = DotDict({"run_mode": "test", "scan_mode": "single", "log_level": "INFO",
            "batch_size": 10, "poll_interval_sec": int(os.getenv("POLL_INTERVAL_SEC", "30")),
            "demo_mode": os.getenv("DEMO_MODE", "false").lower() == "true"})
        self._config["llm"] = DotDict({"method": os.getenv("LLM_METHOD", "cli"),
            "default_agent": os.getenv("LLM_DEFAULT_AGENT", "CLAUDE_STRATEGY"),
            "timeout_sec": int(os.getenv("LLM_TIMEOUT_SEC", "120")), "max_retries": int(os.getenv("LLM_MAX_RETRIES", "3")),
            "fallback_enabled": os.getenv("LLM_FALLBACK_ENABLED", "true").lower() == "true"})
        self._config["league"] = DotDict({"manager_email": "", "league_id": "LEAGUE001", "protocol_version": "league.v2"})

    def _load_json_config(self) -> None:
        config_path = self._project_root / "js" / "config.json"
        if not config_path.exists():
            return
        with open(config_path, encoding="utf-8") as f:
            json_config = json.load(f)
        for key, value in json_config.items():
            if key not in self._config:
                self._config[key] = DotDict(value) if isinstance(value, dict) else value
            elif isinstance(value, dict) and isinstance(self._config[key], dict):
                self._config[key].update(value)

    def __getattr__(self, key: str) -> Any:
        return object.__getattribute__(self, key) if key.startswith("_") else self._config.__getattr__(key)

    def get(self, path: str, default: Any = None) -> Any:
        return self._config.get_nested(path, default)

    def reload(self) -> None:
        self._config = DotDict()
        self._load_env()
        self._load_json_config()

    @property
    def project_root(self) -> Path:
        return self._project_root

    @property
    def database_url(self) -> str:
        db = self._config["database"]
        return f"postgresql://{db['user']}:{db['password']}@{db['host']}:{db['port']}/{db['name']}"

    def validate(self, require_gmail: bool = True, require_db: bool = False) -> list[str]:
        errors = []
        if require_gmail:
            gmail = self._config.get("gmail", {})
            if not gmail.get("account"):
                errors.append("GMAIL_ACCOUNT not set")
            if not gmail.get("credentials_path"):
                errors.append("GMAIL_CREDENTIALS_PATH not set")
            elif not Path(gmail["credentials_path"]).exists():
                errors.append(f"Gmail credentials file not found: {gmail['credentials_path']}")
        if require_db:
            db = self._config.get("database", {})
            if not db.get("host"):
                errors.append("GTAI_DB_HOST not set")
            if not db.get("name"):
                errors.append("GTAI_DB_NAME not set")
            if not db.get("user"):
                errors.append("GTAI_DB_USER not set")
        if not self._config.get("league", {}).get("manager_email"):
            errors.append("league.manager_email not set in js/config.json")
        return errors

    def validate_or_raise(self, require_gmail: bool = True, require_db: bool = False) -> None:
        if errors := self.validate(require_gmail, require_db):
            raise ConfigurationError("Configuration validation failed:\n" + "\n".join(f"  - {e}" for e in errors))

    def is_valid(self, require_gmail: bool = True, require_db: bool = False) -> bool:
        return len(self.validate(require_gmail, require_db)) == 0


class ConfigurationError(Exception):
    pass
