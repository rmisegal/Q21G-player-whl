"""
Custom exceptions for GmailAsPlayer.

Provides structured exception hierarchy:
- PlayerError: Base exception
- GmailError: Gmail API related errors
- RepositoryError: Database/persistence errors
- StateError: State machine errors
- ProtocolError: Protocol/message parsing errors
"""

from q21_player._infra.shared.exceptions.base import PlayerError
from q21_player._infra.shared.exceptions.gmail import (
    GmailAuthenticationError,
    GmailConnectionError,
    GmailError,
    GmailRateLimitError,
)
from q21_player._infra.shared.exceptions.protocol import (
    InvalidEnvelopeError,
    MessageParseError,
    ProtocolError,
    UnknownMessageTypeError,
)
from q21_player._infra.shared.exceptions.repository import (
    DuplicateRecordError,
    RecordNotFoundError,
    RepositoryError,
)
from q21_player._infra.shared.exceptions.state import (
    InvalidTransitionError,
    StateError,
    StateTimeoutError,
)

__all__ = [
    "PlayerError",
    "GmailError",
    "GmailConnectionError",
    "GmailRateLimitError",
    "GmailAuthenticationError",
    "RepositoryError",
    "RecordNotFoundError",
    "DuplicateRecordError",
    "StateError",
    "InvalidTransitionError",
    "StateTimeoutError",
    "ProtocolError",
    "MessageParseError",
    "InvalidEnvelopeError",
    "UnknownMessageTypeError",
]
