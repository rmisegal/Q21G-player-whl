"""Q21 Message Dispatcher - routes Q21 messages to appropriate handlers."""

from typing import Any

from q21_player._infra.cli.answers_handler import AnswersHandler
from q21_player._infra.cli.guess_handler import GuessHandler
from q21_player._infra.cli.hints_handler import HintsHandler
from q21_player._infra.cli.questions_handler import QuestionsHandler
from q21_player._infra.cli.result_handler import ResultHandler
from q21_player._infra.cli.score_feedback_handler import ScoreFeedbackHandler
from q21_player._infra.cli.warmup_handler import WarmupHandler
from q21_player._infra.domain.models.guess import Guess
from q21_player._infra.domain.models.messages import OutgoingMessage
from q21_player._infra.domain.models.question import Question, QuestionBatch, QuestionOptions
from q21_player._infra.domain.services.q21g_response_builder import Q21GResponseBuilder
from q21_player._infra.domain.services.response_builder import ResponseBuilder
from q21_player._infra.shared.logging.logger import get_logger

logger = get_logger("q21_dispatcher")


def _is_q21g_protocol(protocol: str | None) -> bool:
    """Check if protocol is Q21G.v1 or league.v2 (unified protocol)."""
    if protocol is None:
        return False
    upper = protocol.upper()
    return upper.startswith("Q21G") or upper == "LEAGUE.V2"


def handle_warmup_call(
    inner: dict[str, Any], manager_email: str, player_email: str, request_id: str | None,
    protocol: str | None = None
) -> OutgoingMessage | None:
    """Handle Q21_WARMUP_CALL message."""
    warmup_handler = WarmupHandler()
    result = warmup_handler.process(inner, player_email=player_email)
    match_id = result["match_id"]
    referee_email = inner.get("referee_email", manager_email)
    auth_token = inner.get("auth_token", "")
    if _is_q21g_protocol(protocol):
        correlation_id = inner.get("correlation_id") or request_id
        response = Q21GResponseBuilder().build_warmup_response(
            player_email, match_id, result["warmup_answer"], auth_token, referee_email,
            correlation_id=correlation_id)
    else:
        response = ResponseBuilder().build_warmup_response(
            referee_email=referee_email, match_id=match_id,
            auth_token=auth_token, answer=result["warmup_answer"], reply_to=request_id)
    logger.info(f"Warmup call: match={match_id}, answer={result['warmup_answer']}")
    return response


def handle_round_start(
    inner: dict[str, Any], manager_email: str, player_email: str, request_id: str | None,
    protocol: str | None = None
) -> OutgoingMessage | None:
    """Handle Q21_ROUND_START message - stores book info and triggers questions."""
    warmup_handler = WarmupHandler()
    result = warmup_handler.handle_round_start(inner)
    logger.info(f"Round start: match={result['match_id']}, book={result['book_name']}")
    # Per PRD: ROUND_START triggers question generation (combined with QUESTIONS_CALL flow)
    return handle_questions_call(inner, manager_email, player_email, request_id, protocol)


def handle_questions_call(
    inner: dict[str, Any], manager_email: str, player_email: str, request_id: str | None,
    protocol: str | None = None
) -> OutgoingMessage | None:
    """Handle Q21_QUESTIONS_CALL message."""
    questions_handler = QuestionsHandler()
    result = questions_handler.process(inner)
    match_id = result["match_id"]
    referee_email = inner.get("referee_email", manager_email)
    auth_token = inner.get("auth_token", "")
    if _is_q21g_protocol(protocol):
        mc_questions = [{"number": q["question_number"], "text": q["question_text"],
            "choices": q.get("options", {})} for q in result["questions"]]
        if len(mc_questions) != 20:
            logger.warning(f"Question count mismatch: expected 20, got {len(mc_questions)}")
        invalid = [q["number"] for q in mc_questions if not all(k in q.get("choices", {}) for k in "ABCD")]
        if invalid:
            logger.warning(f"Questions {invalid} missing ABCD choices")
        correlation_id = inner.get("correlation_id") or request_id
        response = Q21GResponseBuilder().build_questions_batch(
            player_email, match_id, mc_questions, auth_token, referee_email,
            correlation_id=correlation_id)
    else:
        questions = [
            Question(number=q["question_number"], text=q["question_text"],
                options=QuestionOptions(**q["options"]) if q.get("options") else None)
            for q in result["questions"]]
        batch = QuestionBatch(questions=questions, game_id=match_id, strategy_used="random")
        response = ResponseBuilder().build_questions_batch(
            referee_email=referee_email, questions=batch, auth_token=auth_token, match_id=match_id, reply_to=request_id)
    logger.info(f"Questions call: match={match_id}, count={len(result['questions'])}")
    return response


def handle_answers_batch(
    inner: dict[str, Any], manager_email: str, player_email: str, request_id: str | None,
    protocol: str | None = None
) -> OutgoingMessage | None:
    """Handle Q21_ANSWERS_BATCH - stores answers and auto-submits guess."""
    # Store answers
    answers_handler = AnswersHandler()
    result = answers_handler.process(inner, player_email)
    match_id = result["match_id"]
    logger.info(f"Answers batch: match={match_id}, count={result['answers_count']}")

    # Auto-generate and submit guess
    guess_handler = GuessHandler()
    guess_result = guess_handler.process(inner)
    referee_email = inner.get("referee_email", manager_email)
    auth_token = inner.get("auth_token", "")
    guess_data = guess_result["guess"]
    confidence = guess_data.get("confidence", 0.5)
    if _is_q21g_protocol(protocol):
        correlation_id = inner.get("correlation_id") or request_id
        response = Q21GResponseBuilder().build_guess_submission(
            player_email, match_id, guess_data["opening_sentence"], guess_data["sentence_justification"],
            guess_data["associative_word"], guess_data["word_justification"], auth_token, referee_email, confidence,
            correlation_id=correlation_id)
    else:
        guess = Guess(
            game_id=match_id, opening_sentence=guess_data["opening_sentence"],
            sentence_justification=guess_data["sentence_justification"], associative_word=guess_data["associative_word"],
            word_justification=guess_data["word_justification"],
            confidence=guess_data.get("confidence", 0.5), strategy_used=guess_data.get("strategy_used", "random"))
        response = ResponseBuilder().build_guess_submission(
            referee_email=referee_email, guess=guess, auth_token=auth_token, match_id=match_id, reply_to=request_id)
    logger.info(f"Auto-guess: match={match_id}, word={guess_data['associative_word']}")
    return response


def handle_guess_result(inner: dict[str, Any], player_email: str) -> None:
    """Handle Q21_GUESS_RESULT message."""
    result = ResultHandler().process(inner)
    logger.info(f"Guess result: match={result['match_id']}, score={result['total_score']}")


def handle_hints(inner: dict[str, Any], player_email: str) -> None:
    """Handle Q21_HINTS message."""
    result = HintsHandler().process(inner)
    logger.info(f"Hints: match={result['match_id']}, topic={result['association_topic']}")


def handle_score_feedback(inner: dict[str, Any], player_email: str) -> None:
    """Handle Q21_SCORE_FEEDBACK message."""
    result = ScoreFeedbackHandler().process(inner)
    logger.info(f"Score feedback: match={result['match_id']}, score={result['private_score']}")
