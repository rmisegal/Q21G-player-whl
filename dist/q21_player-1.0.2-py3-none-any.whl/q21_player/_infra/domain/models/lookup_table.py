"""Lookup table for bidirectional attachment filename mapping."""

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path
from threading import Lock

from q21_player._infra.domain.models.attachment_entry import AttachmentEntry
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.logging.logger import get_logger
from q21_player._infra.shared.utils.paths import get_data_folder


class LookupTable:
    """Bidirectional lookup between original and internal filenames."""

    def __init__(self, json_path: Path | None = None):
        self._logger = get_logger("lookup_table")
        config = Config()
        lookup_file = config.get("paths.attachment_lookup_file", "attachment_lookup.json")
        self._json_path = json_path or get_data_folder() / lookup_file
        self._entries: dict[str, AttachmentEntry] = {}
        self._reverse_index: dict[str, str] = {}
        self._lock = Lock()
        self._load()

    def _load(self) -> None:
        """Load lookup table from JSON file."""
        if not self._json_path.exists():
            self._logger.debug("No existing lookup table found")
            return
        try:
            data = json.loads(self._json_path.read_text(encoding="utf-8"))
            for internal, entry_data in data.get("entries", {}).items():
                entry = AttachmentEntry.from_dict(entry_data)
                self._entries[internal] = entry
                self._reverse_index[entry.original_filename] = internal
            self._logger.debug(f"Loaded {len(self._entries)} entries")
        except Exception as e:
            self._logger.error(f"Failed to load lookup table: {e}")

    def _save(self) -> None:
        """Save lookup table to JSON file."""
        try:
            self._json_path.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "version": "1.0",
                "updated_at": datetime.now(UTC).isoformat(),
                "entries": {k: v.to_dict() for k, v in self._entries.items()},
            }
            self._json_path.write_text(
                json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8"
            )
        except Exception as e:
            self._logger.error(f"Failed to save lookup table: {e}")

    def generate_internal_filename(
        self, original_filename: str, message_id: str
    ) -> str:
        """Generate internal filename: YYYYMMDD_HHMMSS_hash_name.ext"""
        now = datetime.now(UTC)
        timestamp = now.strftime("%Y%m%d_%H%M%S")
        hash_input = f"{message_id}:{original_filename}:{now.isoformat()}"
        file_hash = hashlib.sha256(hash_input.encode()).hexdigest()[:8]
        path = Path(original_filename)
        safe_name = "".join(c if c.isalnum() or c in ".-_" else "_" for c in path.stem)
        safe_name = safe_name[:32]
        ext = path.suffix.lower() if path.suffix else ""
        return f"{timestamp}_{file_hash}_{safe_name}{ext}"

    def add_entry(self, entry: AttachmentEntry) -> None:
        """Add new entry to lookup table."""
        with self._lock:
            self._entries[entry.internal_filename] = entry
            self._reverse_index[entry.original_filename] = entry.internal_filename
            self._save()
            self._logger.debug(f"Added entry: {entry.original_filename}")

    def register_attachment(
        self,
        original_filename: str,
        message_id: str,
        mime_type: str = "",
        size_bytes: int = 0,
        checksum: str = "",
    ) -> AttachmentEntry:
        """Register a new attachment and return its entry."""
        internal = self.generate_internal_filename(original_filename, message_id)
        entry = AttachmentEntry(
            original_filename=original_filename,
            internal_filename=internal,
            message_id=message_id,
            mime_type=mime_type,
            size_bytes=size_bytes,
            checksum=checksum,
        )
        self.add_entry(entry)
        return entry

    def get_internal_by_original(self, original_filename: str) -> str | None:
        """Get internal filename from original filename."""
        with self._lock:
            return self._reverse_index.get(original_filename)

    def get_original_by_internal(self, internal_filename: str) -> str | None:
        """Get original filename from internal filename."""
        with self._lock:
            entry = self._entries.get(internal_filename)
            return entry.original_filename if entry else None

    def get_entry_by_internal(self, internal_filename: str) -> AttachmentEntry | None:
        """Get full entry by internal filename."""
        with self._lock:
            return self._entries.get(internal_filename)

    def get_entry_by_original(self, original_filename: str) -> AttachmentEntry | None:
        """Get full entry by original filename."""
        with self._lock:
            internal = self._reverse_index.get(original_filename)
            return self._entries.get(internal) if internal else None

    def get_entries_by_message(self, message_id: str) -> list[AttachmentEntry]:
        """Get all entries for a specific message."""
        with self._lock:
            return [e for e in self._entries.values() if e.message_id == message_id]

    def remove_entry(self, internal_filename: str) -> bool:
        """Remove entry by internal filename."""
        with self._lock:
            entry = self._entries.pop(internal_filename, None)
            if entry:
                self._reverse_index.pop(entry.original_filename, None)
                self._save()
                return True
            return False

    def clear(self) -> None:
        """Clear all entries."""
        with self._lock:
            self._entries.clear()
            self._reverse_index.clear()
            self._save()

    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, internal_filename: str) -> bool:
        return internal_filename in self._entries
