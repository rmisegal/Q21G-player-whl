"""Gmail utility functions for message parsing."""

import base64
import json

from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.shared.logging.logger import get_logger

logger = get_logger("gmail_utils")


def get_header(msg: dict, name: str) -> str:
    """Get header value from message."""
    for header in msg.get("payload", {}).get("headers", []):
        if header["name"] == name:
            return header["value"]
    return ""


def get_payload(client: GmailClient, msg: dict) -> dict | None:
    """Extract JSON payload from message attachment."""
    msg_id = msg.get("id", "")
    payload_data = msg.get("payload", {})

    if "parts" not in payload_data:
        return None

    for part in payload_data["parts"]:
        if part.get("filename", "").endswith(".json"):
            att_id = part.get("body", {}).get("attachmentId")
            if att_id:
                try:
                    att = client.service.users().messages().attachments().get(
                        userId="me", messageId=msg_id, id=att_id
                    ).execute()
                    data = base64.urlsafe_b64decode(att["data"]).decode("utf-8")
                    return json.loads(data)
                except Exception as e:
                    logger.error(f"Failed to get attachment: {e}")
    return None
