"""Answers Handler for Q21_ANSWERS_BATCH messages."""

from typing import Any

from q21_player._infra.cli.handlers.base_game_handler import BaseGameHandler
from q21_player._infra.repository.game_repository import GameRepository
from q21_player._infra.repository.game_state_repository import GameStateRepository


class AnswersHandler(BaseGameHandler):
    """Handles Q21_ANSWERS_BATCH message processing."""

    def __init__(
        self,
        state_repo: GameStateRepository | None = None,
        game_repo: GameRepository | None = None,
    ):
        super().__init__(state_repo=state_repo, game_repo=game_repo)

    def process(self, payload: dict[str, Any], player_email: str = "unknown") -> dict[str, Any]:
        """Process Q21_ANSWERS_BATCH message.

        Args:
            payload: Answers batch payload with match_id, answers, deadline, auth_token
            player_email: Player's email for session creation if needed

        Returns:
            dict with match_id, answers_count, deadline, auth_token
        """
        match_id = payload.get("match_id") or payload.get("game_id", "")
        answers = payload.get("answers") or payload.get("opponent_answers") or []
        deadline = payload.get("deadline")  # Per UNIFIED_PROTOCOL.md Section 7.6
        auth_token = payload.get("auth_token")  # Per UNIFIED_PROTOCOL.md Section 7.6
        self._logger.warning(f"ANSWERS payload: keys={list(payload.keys())}, count={len(answers)}")
        if answers:
            self._logger.warning(f"ANSWERS first item: {answers[0]}")

        # Convert to storage format - handle various field name formats
        answers_data = []
        for i, a in enumerate(answers):
            if isinstance(a, dict):
                q_num = a.get("question_number") or a.get("question_id") or a.get("number") or (i + 1)
                option = a.get("answer") or a.get("selected_option") or a.get("choice") or a.get("selected")
            else:
                q_num, option = i + 1, str(a) if a else None
            # Default to "N/A" if no answer provided (db column is NOT NULL)
            answers_data.append({"question_number": q_num, "selected_option": option or "N/A"})

        # Store answers (ensures game session exists for FK constraint)
        self._game_repo.save_answers(match_id, answers_data, player_email)

        # Update phase (guess will be auto-submitted after this)
        self._state_repo.update_phase(match_id, "ANSWERS_RECEIVED")

        self._logger.info(f"Stored {len(answers_data)} answers for match {match_id}")
        return {"match_id": match_id, "answers_count": len(answers_data), "deadline": deadline, "auth_token": auth_token}
