"""Game repository for game session persistence."""
from datetime import UTC, datetime
from sqlalchemy.exc import SQLAlchemyError
from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import AnswerModel, GameSessionModel, GuessModel, QuestionModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class GameRepository(BaseRepository[GameSessionModel]):
    """Repository for game session operations."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(GameSessionModel, pool)

    def get_by_game_id(self, game_id: str) -> GameSessionModel | None:
        session = self._get_session()
        try: return session.query(GameSessionModel).filter_by(game_id=game_id).first()
        except SQLAlchemyError as e: self._logger.error(f"Get by game_id failed: {e}"); raise RepositoryError(f"Failed to get game: {e}") from e

    def create_session(self, game_id: str, player_email: str, book_name: str, **kwargs) -> GameSessionModel:
        session = self._get_session()
        try:
            existing = session.query(GameSessionModel).filter_by(game_id=game_id).first()
            if existing:
                self._logger.info(f"Session already exists for game {game_id}")
                return existing
            model = GameSessionModel(game_id=game_id, player_email=player_email, book_name=book_name,
                season_id=kwargs.get("season_id"), round_id=kwargs.get("round_id"), round_number=kwargs.get("round_number"),
                game_number=kwargs.get("game_number"), opponent_email=kwargs.get("opponent_email"), my_role=kwargs.get("my_role"))
            session.add(model); session.commit(); session.refresh(model); return model
        except SQLAlchemyError as e: session.rollback(); self._logger.error(f"Create session failed: {e}"); raise RepositoryError(f"Failed to create session: {e}") from e

    def get_by_player(self, player_email: str, limit: int = 50) -> list[GameSessionModel]:
        session = self._get_session()
        try: return session.query(GameSessionModel).filter_by(player_email=player_email).order_by(GameSessionModel.started_at.desc()).limit(limit).all()
        except SQLAlchemyError as e: self._logger.error(f"Get by player failed: {e}"); raise RepositoryError(f"Failed to get player games: {e}") from e

    def get_active_game(self, player_email: str) -> GameSessionModel | None:
        session = self._get_session()
        try: return session.query(GameSessionModel).filter_by(player_email=player_email, is_completed=False, is_abandoned=False).first()
        except SQLAlchemyError as e: self._logger.error(f"Get active game failed: {e}"); raise RepositoryError(f"Failed to get active game: {e}") from e

    def save_questions(self, game_id: str, questions: list[dict]) -> list[QuestionModel]:
        session = self._get_session()
        try:
            # Check if questions already exist for this game (idempotent)
            existing = session.query(QuestionModel).filter_by(game_id=game_id).first()
            if existing:
                self._logger.info(f"Questions already exist for game {game_id}, skipping")
                return session.query(QuestionModel).filter_by(game_id=game_id).all()
            models = [QuestionModel(game_id=game_id, question_number=q["question_number"], question_text=q["question_text"], options=q.get("options")) for q in questions]
            session.add_all(models); session.commit(); return models
        except SQLAlchemyError as e: session.rollback(); self._logger.error(f"Save questions failed: {e}"); raise RepositoryError(f"Failed to save questions: {e}") from e

    def ensure_session_exists(self, game_id: str, player_email: str = "unknown") -> GameSessionModel:
        """Ensure a game session exists, creating a placeholder if needed."""
        existing = self.get_by_game_id(game_id)
        if existing:
            return existing
        self._logger.info(f"Creating placeholder session for {game_id}")
        return self.create_session(game_id=game_id, player_email=player_email, book_name="Unknown")

    def save_answers(self, game_id: str, answers: list[dict], player_email: str = "unknown") -> list[AnswerModel]:
        session = self._get_session()
        try:
            # Ensure game session exists for FK constraint
            self.ensure_session_exists(game_id, player_email)
            existing = session.query(AnswerModel).filter_by(game_id=game_id).first()
            if existing:
                self._logger.info(f"Answers already exist for game {game_id}, skipping")
                return session.query(AnswerModel).filter_by(game_id=game_id).all()
            models = [AnswerModel(game_id=game_id, question_number=a["question_number"], selected_option=a["selected_option"]) for a in answers]
            session.add_all(models); session.commit(); return models
        except SQLAlchemyError as e: session.rollback(); self._logger.error(f"Save answers failed: {e}"); raise RepositoryError(f"Failed to save answers: {e}") from e

    def save_guess(self, game_id: str, guess: dict) -> GuessModel:
        session = self._get_session()
        try:
            existing = session.query(GuessModel).filter_by(game_id=game_id).first()
            if existing:
                self._logger.info(f"Guess already exists for game {game_id}, skipping")
                return existing
            model = GuessModel(game_id=game_id, opening_sentence=guess["opening_sentence"], sentence_justification=guess.get("sentence_justification"),
                associative_word=guess.get("associative_word"), word_justification=guess.get("word_justification"),
                confidence=guess.get("confidence"), strategy_used=guess.get("strategy_used"))
            session.add(model); session.commit(); return model
        except SQLAlchemyError as e: session.rollback(); self._logger.error(f"Save guess failed: {e}"); raise RepositoryError(f"Failed to save guess: {e}") from e

    def complete_game(self, game_id: str, is_correct: bool, score: float = 0.0) -> bool:
        game = self.get_by_game_id(game_id)
        if not game: return False
        game.is_completed, game.ended_at, game.result_correct, game.result_score = True, datetime.now(UTC), is_correct, score
        self.update(game); return True

    def abandon_game(self, game_id: str) -> bool:
        game = self.get_by_game_id(game_id)
        if not game: return False
        game.is_abandoned, game.ended_at = True, datetime.now(UTC)
        self.update(game); return True

    def get_statistics(self, player_email: str) -> dict:
        games = self.get_by_player(player_email, limit=1000)
        completed = [g for g in games if g.is_completed]
        wins = sum(1 for g in completed if g.result_correct)
        return {"total": len(games), "completed": len(completed), "wins": wins, "losses": len(completed) - wins,
                "win_rate": wins / len(completed) if completed else 0.0}
