"""Repository for attachment persistence."""

from datetime import datetime

from sqlalchemy.exc import SQLAlchemyError

from q21_player._infra.domain.models.attachment_entry import AttachmentEntry
from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.base_repository import BaseRepository
from q21_player._infra.repository.orm_models import AttachmentModel
from q21_player._infra.shared.exceptions.repository import RepositoryError


class AttachmentRepository(BaseRepository[AttachmentModel]):
    """Repository for attachment lookup table persistence."""

    def __init__(self, pool: ConnectionPool | None = None):
        super().__init__(AttachmentModel, pool)

    def create_from_entry(self, entry: AttachmentEntry) -> AttachmentModel:
        """Create attachment record from AttachmentEntry."""
        model = AttachmentModel(
            internal_filename=entry.internal_filename,
            original_filename=entry.original_filename,
            message_id=entry.message_id,
            mime_type=entry.mime_type,
            size_bytes=entry.size_bytes,
            checksum=entry.checksum,
            created_at=entry.created_at,
        )
        return self.create(model)

    def get_by_internal(self, internal_filename: str) -> AttachmentModel | None:
        """Get attachment by internal filename."""
        session = self._get_session()
        try:
            return session.query(AttachmentModel).filter_by(
                internal_filename=internal_filename
            ).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by internal failed: {e}")
            raise RepositoryError(f"Failed to get attachment: {e}") from e

    def get_by_original(self, original_filename: str) -> AttachmentModel | None:
        """Get attachment by original filename."""
        session = self._get_session()
        try:
            return session.query(AttachmentModel).filter_by(
                original_filename=original_filename
            ).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by original failed: {e}")
            raise RepositoryError(f"Failed to get attachment: {e}") from e

    def get_by_message_id(self, message_id: str) -> list[AttachmentModel]:
        """Get all attachments for a message."""
        session = self._get_session()
        try:
            return session.query(AttachmentModel).filter_by(
                message_id=message_id
            ).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by message failed: {e}")
            raise RepositoryError(f"Failed to get attachments: {e}") from e

    def delete_by_internal(self, internal_filename: str) -> bool:
        """Delete attachment by internal filename."""
        model = self.get_by_internal(internal_filename)
        if model:
            return self.delete(model)
        return False

    def delete_by_message_id(self, message_id: str) -> int:
        """Delete all attachments for a message."""
        session = self._get_session()
        try:
            count = session.query(AttachmentModel).filter_by(
                message_id=message_id
            ).delete()
            session.commit()
            return count
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Delete by message failed: {e}")
            raise RepositoryError(f"Failed to delete attachments: {e}") from e

    def cleanup_old(self, before: datetime) -> int:
        """Delete attachments older than the given date."""
        session = self._get_session()
        try:
            count = session.query(AttachmentModel).filter(
                AttachmentModel.created_at < before
            ).delete()
            session.commit()
            self._logger.info(f"Cleaned up {count} old attachments")
            return count
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Cleanup failed: {e}")
            raise RepositoryError(f"Failed to cleanup attachments: {e}") from e

    def to_entry(self, model: AttachmentModel) -> AttachmentEntry:
        """Convert ORM model to AttachmentEntry."""
        return AttachmentEntry(
            original_filename=model.original_filename,
            internal_filename=model.internal_filename,
            message_id=model.message_id,
            mime_type=model.mime_type or "",
            size_bytes=model.size_bytes or 0,
            checksum=model.checksum or "",
            created_at=model.created_at,
        )
