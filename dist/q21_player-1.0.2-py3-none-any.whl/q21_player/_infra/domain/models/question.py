"""
Question models for Q21 game.

Represents multiple-choice questions and batches.
"""


from pydantic import BaseModel, Field, field_validator

from q21_player._infra.shared.config.constants import MAX_QUESTIONS


class QuestionOptions(BaseModel):
    """Options for a multiple-choice question."""

    A: str = Field(..., description="Option A text")
    B: str = Field(..., description="Option B text")
    C: str = Field(..., description="Option C text")
    D: str = Field(..., description="Option D text")

    def to_dict(self) -> dict[str, str]:
        return {"A": self.A, "B": self.B, "C": self.C, "D": self.D}

    @classmethod
    def from_dict(cls, data: dict[str, str]) -> "QuestionOptions":
        return cls(A=data["A"], B=data["B"], C=data["C"], D=data["D"])


class Question(BaseModel):
    """A single multiple-choice question."""

    number: int = Field(..., ge=1, le=MAX_QUESTIONS, description="Question number (1-20)")
    text: str = Field(..., min_length=10, description="Question text")
    options: QuestionOptions = Field(..., description="Answer options A-D")
    rationale: str | None = Field(default=None, description="Why this question was asked")

    @field_validator("text")
    @classmethod
    def validate_ends_with_question(cls, v: str) -> str:
        """Ensure question text ends with question mark."""
        v = v.strip()
        if not v.endswith("?"):
            v = v + "?"
        return v

    def to_protocol_dict(self) -> dict:
        """Convert to protocol format (uses question_number per UNIFIED_PROTOCOL.md)."""
        return {
            "question_number": self.number,
            "question_text": self.text,
            "options": self.options.to_dict(),
        }


class QuestionBatch(BaseModel):
    """Batch of 20 questions for Q21 game."""

    questions: list[Question] = Field(..., min_length=MAX_QUESTIONS, max_length=MAX_QUESTIONS)
    game_id: str = Field(..., description="Associated game ID")
    strategy_used: str = Field(default="unknown", description="Strategy that generated questions")

    @field_validator("questions")
    @classmethod
    def validate_question_numbers(cls, v: list[Question]) -> list[Question]:
        """Ensure questions are numbered 1-20."""
        numbers = [q.number for q in v]
        expected = list(range(1, MAX_QUESTIONS + 1))
        if sorted(numbers) != expected:
            raise ValueError(f"Questions must be numbered 1-{MAX_QUESTIONS}")
        return sorted(v, key=lambda q: q.number)

    def to_protocol_payload(self) -> dict:
        """Convert to protocol payload format per UNIFIED_PROTOCOL.md."""
        return {
            "match_id": self.game_id,
            "questions": [q.to_protocol_dict() for q in self.questions],
            "total_questions": len(self.questions),
        }

    def get_question(self, number: int) -> Question | None:
        """Get question by number."""
        for q in self.questions:
            if q.number == number:
                return q
        return None

    @classmethod
    def create_empty(cls, game_id: str) -> "QuestionBatch":
        """Create batch with placeholder questions."""
        questions = [
            Question(
                number=i,
                text=f"Placeholder question {i}?",
                options=QuestionOptions(A="Yes", B="No", C="Maybe", D="Unknown"),
            )
            for i in range(1, MAX_QUESTIONS + 1)
        ]
        return cls(questions=questions, game_id=game_id)
