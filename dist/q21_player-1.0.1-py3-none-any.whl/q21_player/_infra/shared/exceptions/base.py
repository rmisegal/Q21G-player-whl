"""
Base exception class for GmailAsPlayer.

All custom exceptions inherit from PlayerError.
"""

from typing import Any


class PlayerError(Exception):
    """
    Base exception for all GmailAsPlayer errors.

    Attributes:
        message: Human-readable error message
        code: Error code for programmatic handling
        details: Additional error context
    """

    def __init__(
        self,
        message: str,
        code: str | None = None,
        details: dict[str, Any] | None = None,
    ) -> None:
        """
        Initialize the error.

        Args:
            message: Human-readable error message
            code: Error code for programmatic handling
            details: Additional error context
        """
        super().__init__(message)
        self.message = message
        self.code = code or self.__class__.__name__
        self.details = details or {}

    def __str__(self) -> str:
        """Return string representation."""
        if self.details:
            return f"[{self.code}] {self.message} - {self.details}"
        return f"[{self.code}] {self.message}"

    def to_dict(self) -> dict[str, Any]:
        """Convert exception to dictionary for logging/serialization."""
        return {
            "error_type": self.__class__.__name__,
            "code": self.code,
            "message": self.message,
            "details": self.details,
        }
