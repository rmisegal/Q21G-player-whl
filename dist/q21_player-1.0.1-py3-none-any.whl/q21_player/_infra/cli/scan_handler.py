"""Single scan handler - process messages once and exit."""
import time
from q21_player._infra.cli.extension_handler import ExtensionHandler
from q21_player._infra.cli.gmail_utils import get_header, get_payload
from q21_player._infra.cli.invitation_handler import InvitationHandler
from q21_player._infra.cli.message_processor import MessageProcessor
from q21_player._infra.cli.q21_dispatcher import (handle_answers_batch, handle_guess_result,
    handle_hints, handle_questions_call, handle_round_start, handle_score_feedback, handle_warmup_call)
from q21_player._infra.cli.rejection_handler import RejectionHandler
from q21_player._infra.cli.scan_logger import ScanLogger
from q21_player._infra.cli.scan_result import ScanResult
from q21_player._infra.cli.season_registration_handler import SeasonRegistrationHandler
from q21_player._infra.cli.standings_handler import StandingsHandler
from q21_player._infra.domain.services.player_gatekeeper import PlayerGatekeeper
from q21_player._infra.domain.services.player_gatekeeper_actions import ActionType
from q21_player._infra.domain.services.player_gatekeeper_executor import GatekeeperExecutor
from q21_player._infra.gmail.client import GmailClient
from q21_player._infra.gmail.sender import GmailSender
from q21_player._infra.repository.assignment_repository import AssignmentRepository
from q21_player._infra.repository.correlation_repository import CorrelationRepository
from q21_player._infra.repository.message_log_repository import MessageLogRepository
from q21_player._infra.repository.state_repository import StateRepository
from q21_player._infra.shared.config.settings import Config
from q21_player._infra.shared.logging.logger import get_logger
from q21_player._infra.shared.logging.protocol_logger import (
    log_received, log_sent, log_rejected, log_error, set_game_context
)

logger = get_logger("scan_handler")


def _handle_season_registration_response(payload: dict, state_repo: StateRepository, player_email: str):
    s, r = SeasonRegistrationHandler(state_repo=state_repo, player_email=player_email).process(payload)
    logger.info(f"Season registration: {'ACCEPTED' if s else f'REJECTED: {r}'}"); return s, r


def _dispatch_q21(msg_type: str, payload: dict, sender: str, player: str, req_id: str | None,
                   protocol: str | None = None, referee_email: str | None = None):
    p = payload.get("payload", {})
    normalized = msg_type.replace("_", "").upper()  # Normalize: Q21_WARMUP_CALL -> Q21WARMUPCALL
    ref = referee_email or sender  # Gatekeeper-resolved referee, fallback to sender
    if "WARMUP" in normalized: return handle_warmup_call(p, ref, player, req_id, protocol)
    if "ROUND" in normalized and "START" in normalized: return handle_round_start(p, ref, player, req_id, protocol)
    if "QUESTION" in normalized and "CALL" in normalized: return handle_questions_call(p, ref, player, req_id, protocol)
    if "ANSWERS" in normalized: return handle_answers_batch(p, ref, player, req_id, protocol)
    if "HINTS" in normalized: handle_hints(p, player); return None
    if "GUESSRESULT" in normalized: handle_guess_result(p, player)
    if "SCOREFEEDBACK" in normalized: handle_score_feedback(p, player)
    return None

def _dispatch_broadcast(msg_type: str, payload: dict, player_email: str):
    p = payload.get("payload", {})
    normalized = msg_type.replace("_", "").upper()
    if "ASSIGNMENTTABLE" in normalized: logger.info("Assignment table processed by gatekeeper")
    elif "ROUNDRESULTS" in normalized:
        r = StandingsHandler().process(p, group_id=player_email); logger.info(f"Results: rank={r['my_rank']}, score={r['my_score']}")


def run_scan(player_email: str, player_name: str, dry_run: bool = False) -> ScanResult:
    result, config = ScanResult(), Config()
    logger.info(f"Starting scan for {player_name} <{player_email}>")
    t0 = time.perf_counter()
    client = GmailClient()
    try: client.connect()
    except Exception as e:
        log_error(f"Gmail connection failed: {e}"); result.errors.append(f"Gmail: {e}"); result.complete("FAILED"); return result

    sender, correlation_repo, state_repo = GmailSender(client), CorrelationRepository(), StateRepository()
    assignment_repo = AssignmentRepository()
    manager_email = config.get("league.manager_email", "")
    manager_emails = [manager_email] if manager_email else []
    gatekeeper = PlayerGatekeeper(assignment_repo=assignment_repo, player_email=player_email, manager_emails=manager_emails)
    gk_executor = GatekeeperExecutor(assignment_repo=assignment_repo)
    scan_logger = ScanLogger(message_log_repo=MessageLogRepository())
    processor = MessageProcessor(correlation_repo=correlation_repo, state_repo=state_repo, player_email=player_email)
    # Note: from_clause not used in query - sender validation done by gatekeeper
    query = f"(subject:league.v2 OR subject:Q21G.v1) is:unread"
    logger.info(f"[TIMING] init: {(time.perf_counter()-t0)*1000:.1f}ms, Query: {query}")

    try:
        max_msgs = config.get("gmail.max_messages_per_scan", 20)
        messages = client.list_messages(query=query, max_results=max_msgs).get("messages", [])
        result.emails_found = len(messages); logger.info(f"Found {len(messages)} message(s)")
    except Exception as e:
        log_error(f"Failed to list messages: {e}"); result.errors.append(f"List: {e}"); result.complete("FAILED"); return result

    # Process oldest messages first (Gmail API returns newest first)
    for msg_ref in reversed(messages):
        msg_id = msg_ref["id"]
        try:
            msg = client.get_message(msg_id)
            subject, parts = get_header(msg, "Subject"), get_header(msg, "Subject").split("::")
            if len(parts) < 5: result.emails_skipped += 1; continue
            sender_email, msg_type, payload, response_msg = parts[2], parts[4], get_payload(client, msg), None
            request_id = payload.get("payload", {}).get("broadcast_id") if payload else None
            league_id = payload.get("leagueid") if payload else None
            if payload:
                # Extract game_id from payload - try game_id first, then match_id (Q21 messages use match_id)
                inner = payload.get("payload", {})
                game_id = inner.get("game_id") or inner.get("match_id") or payload.get("game_id") or payload.get("match_id") or ""
                deadline = inner.get("deadline") or payload.get("deadline", "")

                # Evaluate message first to get player activity status
                gk_action = gatekeeper.evaluate(msg_type, payload, sender_email)

                # Determine player activity status
                player_active = False

                # First check gatekeeper action params (for ASSIGNMENT-TABLE messages)
                if gk_action.params and gk_action.params.get("assignments"):
                    for a in gk_action.params["assignments"]:
                        if a.get("my_role"):
                            player_active = True
                            if not game_id:
                                game_id = a.get("game_id", "")
                            break

                # If not determined from params, query assignment table by game_id
                if not player_active and game_id:
                    assignment = assignment_repo.get_by_game_id(game_id)
                    if assignment and assignment.my_role:
                        player_active = True

                # Fallback: check gatekeeper state (for cases where gatekeeper processed assignment table in same scan)
                if not player_active and gatekeeper.current_season_id and gatekeeper.current_round:
                    assignments = assignment_repo.get_by_round(gatekeeper.current_season_id, gatekeeper.current_round)
                    if assignments:
                        player_active = any(a.my_role for a in assignments)
                        if not game_id:
                            game_id = assignments[0].game_id or ""

                # Set game context with activity status
                set_game_context(game_id, player_active)

                log_received(msg_type, sender_email, game_id, deadline)
                if gk_action.action_type == ActionType.REJECT:
                    log_rejected(msg_type, sender_email, "unauthorized sender")
                    client.modify_message(msg_id, remove_labels=["UNREAD"]); result.emails_rejected += 1; continue
                gk_executor.execute(gk_action)
                if not gk_action.should_process:
                    client.modify_message(msg_id, remove_labels=["UNREAD"]); result.emails_processed += 1; continue
                scan_logger.log_incoming(gmail_id=msg_id, thread_id=msg.get("threadId", ""), msg_type=msg_type,
                    transaction_id=request_id or msg_id, sender_email=sender_email, recipient_email=player_email, subject=subject, payload=payload, league_id=league_id)
            # Normalize msg_type for comparisons (remove underscores)
            normalized_type = msg_type.replace("_", "").upper()
            if processor.can_handle(msg_type) and payload:
                response_msg = processor.process(msg_type, payload, sender_email=sender_email)
                if "STARTSEASON" in normalized_type:
                    info = processor.extract_season_info(payload); processor.update_player_state(league_id=info["league_id"], season_id=info["season_id"], round_id=info["round_id"])
            elif normalized_type.startswith("Q21") and payload:
                ref_email = gatekeeper.get_current_referee()
                response_msg = _dispatch_q21(msg_type, payload, sender_email, player_email, request_id, parts[0], ref_email)
            elif "GAMEINVITATION" in normalized_type and payload: logger.info(f"Invitation: {InvitationHandler().process(payload.get('payload', {}), player_email)}")
            elif "RESPONSELEAGUEREGISTER" in normalized_type and payload: logger.info(f"Registration response: {payload.get('payload', {}).get('status', 'unknown')}")
            elif "SEASONREGISTRATIONRESPONSE" in normalized_type and payload: _handle_season_registration_response(payload, state_repo, player_email)
            elif "EXTENSIONRESPONSE" in normalized_type and payload: ExtensionHandler().process(payload)
            elif "REJECTIONNOTIFICATION" in normalized_type and payload: RejectionHandler().process(payload)
            elif "BROADCAST" in normalized_type and payload: _dispatch_broadcast(msg_type, payload, player_email)
            if response_msg and not dry_run:
                resp_type = response_msg.envelope.message_type.value if hasattr(response_msg.envelope.message_type, 'value') else response_msg.envelope.message_type
                log_sent(resp_type, response_msg.envelope.recipient_email, game_id, deadline)
                sender.send(to=response_msg.envelope.recipient_email, subject=response_msg.envelope.to_subject_line(),
                    body=response_msg.body_text, attachment=response_msg.payload, attachment_name=response_msg.attachment_name)
                result.responses_sent += 1
                scan_logger.log_outgoing(transaction_id=response_msg.envelope.transaction_id, msg_type=resp_type, sender_email=player_email,
                    recipient_email=response_msg.envelope.recipient_email, subject=response_msg.envelope.to_subject_line(), payload=response_msg.payload, league_id=league_id)
                if request_id: processor.save_correlation(request_type=msg_type, request_id=request_id, response_type=resp_type, response_id=response_msg.envelope.transaction_id, request_gmail_id=msg_id)
            client.modify_message(msg_id, remove_labels=["UNREAD"]); result.emails_processed += 1
        except Exception as e: log_error(f"Failed to process {msg_id}: {e}"); result.errors.append(f"Process {msg_id[:8]}: {e}")

    result.complete("COMPLETED" if not result.errors else "COMPLETED_WITH_ERRORS")
    logger.info(f"[TIMING] total: {(time.perf_counter()-t0)*1000:.1f}ms - {result.summary}"); return result
