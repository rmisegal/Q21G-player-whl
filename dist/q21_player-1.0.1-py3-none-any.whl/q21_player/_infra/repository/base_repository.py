"""Base repository with common CRUD operations."""

from typing import Generic, TypeVar

from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from q21_player._infra.database.pool import ConnectionPool
from q21_player._infra.repository.orm_models import Base
from q21_player._infra.shared.exceptions.repository import RepositoryError
from q21_player._infra.shared.logging.logger import get_logger

T = TypeVar("T", bound=Base)


class BaseRepository(Generic[T]):
    """Generic repository for CRUD operations."""

    def __init__(self, model_class: type[T], pool: ConnectionPool | None = None):
        self._logger = get_logger(f"repository.{model_class.__tablename__}")
        self._model_class = model_class
        self._pool = pool or ConnectionPool()

    def _get_session(self) -> Session:
        """Get database session from pool."""
        return self._pool.get_session()

    def create(self, entity: T) -> T:
        """Create a new entity."""
        session = self._get_session()
        try:
            session.add(entity)
            session.commit()
            session.refresh(entity)
            return entity
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Create failed: {e}")
            raise RepositoryError(f"Failed to create entity: {e}") from e

    def get_by_id(self, entity_id: int) -> T | None:
        """Get entity by primary key ID."""
        session = self._get_session()
        try:
            return session.query(self._model_class).filter_by(id=entity_id).first()
        except SQLAlchemyError as e:
            self._logger.error(f"Get by ID failed: {e}")
            raise RepositoryError(f"Failed to get entity: {e}") from e

    def get_all(self, limit: int = 100, offset: int = 0) -> list[T]:
        """Get all entities with pagination."""
        session = self._get_session()
        try:
            return session.query(self._model_class).offset(offset).limit(limit).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Get all failed: {e}")
            raise RepositoryError(f"Failed to get entities: {e}") from e

    def update(self, entity: T) -> T:
        """Update an existing entity."""
        session = self._get_session()
        try:
            session.merge(entity)
            session.commit()
            return entity
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Update failed: {e}")
            raise RepositoryError(f"Failed to update entity: {e}") from e

    def delete(self, entity: T) -> bool:
        """Delete an entity."""
        session = self._get_session()
        try:
            session.delete(entity)
            session.commit()
            return True
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"Delete failed: {e}")
            raise RepositoryError(f"Failed to delete entity: {e}") from e

    def delete_by_id(self, entity_id: int) -> bool:
        """Delete entity by ID."""
        entity = self.get_by_id(entity_id)
        if entity:
            return self.delete(entity)
        return False

    def count(self) -> int:
        """Count total entities."""
        session = self._get_session()
        try:
            return session.query(self._model_class).count()
        except SQLAlchemyError as e:
            self._logger.error(f"Count failed: {e}")
            raise RepositoryError(f"Failed to count entities: {e}") from e

    def exists(self, entity_id: int) -> bool:
        """Check if entity exists."""
        return self.get_by_id(entity_id) is not None

    def _query_one(self, filter_by: dict, operation: str = "query") -> T | None:
        """Query single entity by filter_by dict. Returns None if not found."""
        session = self._get_session()
        try:
            return session.query(self._model_class).filter_by(**filter_by).first()
        except SQLAlchemyError as e:
            self._logger.error(f"{operation} failed: {e}")
            raise RepositoryError(f"Failed to {operation}: {e}") from e

    def _query_many(self, filter_by: dict | None = None, order_by=None, limit: int = 100) -> list[T]:
        """Query multiple entities with optional filter, order, and limit."""
        session = self._get_session()
        try:
            query = session.query(self._model_class)
            if filter_by:
                query = query.filter_by(**filter_by)
            if order_by is not None:
                query = query.order_by(order_by)
            return query.limit(limit).all()
        except SQLAlchemyError as e:
            self._logger.error(f"Query failed: {e}")
            raise RepositoryError(f"Failed to query: {e}") from e

    def _update_fields(self, filter_by: dict, updates: dict, operation: str = "update") -> bool:
        """Update entity fields. Returns False if entity not found."""
        session = self._get_session()
        try:
            entity = session.query(self._model_class).filter_by(**filter_by).first()
            if not entity:
                return False
            for key, value in updates.items():
                setattr(entity, key, value)
            session.commit()
            return True
        except SQLAlchemyError as e:
            session.rollback()
            self._logger.error(f"{operation} failed: {e}")
            raise RepositoryError(f"Failed to {operation}: {e}") from e
