# Area: CLI Message Processing
# PRD: docs/prd-rlgm.md
"""Logging context setup based on message types."""
from q21_player._infra.repository.assignment_repository import AssignmentRepository
from q21_player._infra.shared.logging.protocol_logger import (
    set_season_context, set_round_context, set_game_context
)


def set_logging_context(
    normalized_type: str,
    game_id: str,
    inner: dict,
    payload: dict,
    assignment_repo: AssignmentRepository,
    gatekeeper_season_id: str | None
) -> None:
    """Set logging context based on message type.

    - Q21 messages (game-level): SSRRGGG, with ACTIVE/INACTIVE role
    - START-ROUND (round-level): SSRR999, with ACTIVE/INACTIVE role
    - Other messages (season-level): SS99999, no role
    """
    if normalized_type.startswith("Q21"):
        # Game-level: Q21 messages (SSRRGGG, with role)
        player_active = False
        if game_id:
            assignment = assignment_repo.get_by_game_id(game_id)
            if assignment and assignment.my_role:
                player_active = True
        set_game_context(game_id, player_active)
    elif "NEWLEAGUEROUND" in normalized_type or "STARTROUND" in normalized_type:
        # Round-level: START-ROUND (SSRR999, with role)
        round_number = inner.get("round_number") or payload.get("round_number") or 1
        player_active = False
        if gatekeeper_season_id:
            assignments = assignment_repo.get_by_round(gatekeeper_season_id, round_number)
            if assignments:
                player_active = any(a.my_role for a in assignments)
        set_round_context(round_number, player_active)
    else:
        # Season-level: START-SEASON, SIGNUP-RESPONSE, ASSIGNMENT-TABLE, etc. (SS99999, no role)
        set_season_context()
